<?php
/** @var string $viewFile */
$user = $user ?? null;
?>
<!doctype html>
<html lang="en" data-bs-theme="light">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Mana Pod Tournament Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <?php $cssVer = @filemtime(BASE_PATH . '/public/assets/app.css') ?: time(); ?>
  <link href="assets/app.css?v=<?php echo (int)$cssVer; ?>" rel="stylesheet">
</head>
<body class="min-vh-100">
  <?php require VIEW_PATH . '/partials/nav.php'; ?>
  <main class="container py-4">
    <?php if (empty($suppressFlash)): ?>
      <?php require VIEW_PATH . '/partials/flash.php'; ?>
    <?php endif; ?>
    <?php require $viewFile; ?>
  </main>
  <footer class="border-top py-3">
    <div class="container small text-muted text-center">
      <div>Mana Pod - Version 1.0 (initial)</div>
      © <?php echo date('Y'); ?> Bob Mathew Sunga. Licensed under Custom License.
      <div>All rights reserved.</div>
      <div class="mt-1">Free to use by Philippine local game stores.</div>
      <div class="mt-1">Distribution in any form is strictly prohibited.</div>
      <div class="mt-1">Kindly notify the original author of any changes.</div>
      <div>email: bobmathew.sunga@gmail.com</div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/theme.js"></script>
</body>
</html>
