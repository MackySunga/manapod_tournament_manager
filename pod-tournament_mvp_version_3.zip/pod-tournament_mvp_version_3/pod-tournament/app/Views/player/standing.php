<h3 class="mb-1"><?php echo e($game['name']); ?></h3>
<div class="small text-muted mb-3">Status: <?php echo e($game['status'] ?? ''); ?></div>

<?php if (($game['status'] ?? '') !== 'ended'): ?>
  <?php
    $dropped = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
    $rows = $standings['ranked'] ?? [];
    $activeRows = [];
    $droppedRows = [];
    foreach ($rows as $row) {
      if (in_array(strtolower((string)$row['email']), $dropped, true)) {
        $droppedRows[] = $row;
      } else {
        $activeRows[] = $row;
      }
    }
  ?>
  <div class="card mb-3">
    <div class="card-body">
      <div class="fw-semibold mb-2">Ranking</div>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>#</th>
              <th>Player</th>
              <th>Total Score</th>
              <th>Total Wins Points</th>
              <th>Match-win %</th>
              <th>Game-win %</th>
              <th>OWP</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($activeRows as $i => $r): ?>
            <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
            <tr class="<?php echo ($r['email'] === ($user['email'] ?? '')) ? 'table-info' : ''; ?>">
              <td><?php echo $i+1; ?></td>
              <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span></td>
              <td><?php echo (int)$r['total_score']; ?></td>
              <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
              <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['owp'], 3); ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($activeRows)): ?>
            <tr><td colspan="7" class="text-muted">No standings yet.</td></tr>
          <?php endif; ?>
          <?php if (!empty($droppedRows)): ?>
            <tr><td colspan="7" class="text-muted">Dropped Players</td></tr>
            <?php foreach ($droppedRows as $r): ?>
              <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
              <tr class="table-secondary">
                <td>-</td>
                <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span> <span class="badge text-bg-danger ms-1">DROPPED</span></td>
                <td><?php echo (int)$r['total_score']; ?></td>
                <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
                <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
                <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
                <td><?php echo number_format((float)$r['owp'], 3); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php else: ?>
  <ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item" role="presentation"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#ranked" type="button">Ranking</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#top20" type="button">Top 20</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#alpha" type="button">Alphabetical Standing</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#pods" type="button">Pod Records</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#stats" type="button">Game Stats</button></li>
  </ul>

  <div class="tab-content">
    <div class="tab-pane fade show active" id="ranked">
      <?php
        $dropped = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
        $rows = $standings['ranked'] ?? [];
        $activeRows = [];
        $droppedRows = [];
        foreach ($rows as $row) {
          if (in_array(strtolower((string)$row['email']), $dropped, true)) {
            $droppedRows[] = $row;
          } else {
            $activeRows[] = $row;
          }
        }
      ?>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>#</th><th>Player</th><th>Total Score</th><th>Total Wins Points</th><th>Total Loss</th>
              <th>Win Rate</th><th>Loss Rate</th><th>Match-win %</th><th>Game-win %</th><th>OWP</th><th>OGP</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($activeRows as $i => $r): ?>
            <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
            <tr class="<?php echo ($r['email'] === ($user['email'] ?? '')) ? 'table-info' : ''; ?>">
              <td><?php echo $i+1; ?></td>
              <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span></td>
              <td><?php echo (int)$r['total_score']; ?></td>
              <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
              <td><?php echo (int)$r['total_loss']; ?></td>
              <td><?php echo number_format((float)$r['win_rate'], 3); ?></td>
              <td><?php echo number_format((float)$r['loss_rate'], 3); ?></td>
              <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['owp'], 3); ?></td>
              <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($activeRows)): ?>
            <tr><td colspan="11" class="text-muted">No data yet.</td></tr>
          <?php endif; ?>
          <?php if (!empty($droppedRows)): ?>
            <tr><td colspan="11" class="text-muted">Dropped Players</td></tr>
            <?php foreach ($droppedRows as $r): ?>
              <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
              <tr class="table-secondary">
                <td>-</td>
                <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span> <span class="badge text-bg-danger ms-1">DROPPED</span></td>
                <td><?php echo (int)$r['total_score']; ?></td>
                <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
                <td><?php echo (int)$r['total_loss']; ?></td>
                <td><?php echo number_format((float)$r['win_rate'], 3); ?></td>
                <td><?php echo number_format((float)$r['loss_rate'], 3); ?></td>
                <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
                <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
                <td><?php echo number_format((float)$r['owp'], 3); ?></td>
                <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

    <div class="tab-pane fade" id="top20">
      <?php
        $rows = array_filter(($standings['ranked'] ?? []), function ($r) use ($dropped) {
          return !in_array(strtolower((string)$r['email']), $dropped, true);
        });
        $rows = array_values(array_slice($rows, 0, 20));
      ?>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>#</th><th>Player</th><th>Total Score</th><th>Total Wins Points</th><th>Total Loss</th>
              <th>Win Rate</th><th>Match-win %</th><th>Game-win %</th><th>OWP</th><th>OGP</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $i => $r): ?>
              <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
              <tr class="<?php echo ($i < 8) ? 'table-warning' : ''; ?>">
                <td><?php echo $i+1; ?></td>
                <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span></td>
                <td><?php echo (int)$r['total_score']; ?></td>
                <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
                <td><?php echo (int)$r['total_loss']; ?></td>
                <td><?php echo number_format((float)$r['win_rate'], 3); ?></td>
                <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
                <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
                <td><?php echo number_format((float)$r['owp'], 3); ?></td>
                <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($rows)): ?>
              <tr><td colspan="10" class="text-muted">No data yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="tab-pane fade" id="alpha">
      <?php
        $rows = $standings['alphabetical'] ?? [];
        $activeRows = [];
        $droppedRows = [];
        foreach ($rows as $row) {
          if (in_array(strtolower((string)$row['email']), $dropped, true)) {
            $droppedRows[] = $row;
          } else {
            $activeRows[] = $row;
          }
        }
      ?>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>Player (by email)</th><th>Total Score</th><th>Total Wins Points</th><th>Total Loss</th><th>OWP</th><th>OGP</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($activeRows as $r): ?>
            <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
            <tr>
                <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span></td>
                <td><?php echo (int)$r['total_score']; ?></td>
                <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
                <td><?php echo (int)$r['total_loss']; ?></td>
                <td><?php echo number_format((float)$r['owp'], 3); ?></td>
                <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
              </tr>
          <?php endforeach; ?>
          <?php if (empty($activeRows)): ?>
            <tr><td colspan="6" class="text-muted">No data yet.</td></tr>
          <?php endif; ?>
          <?php if (!empty($droppedRows)): ?>
            <tr><td colspan="6" class="text-muted">Dropped Players</td></tr>
            <?php foreach ($droppedRows as $r): ?>
              <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
              <tr class="table-secondary">
                <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span> <span class="badge text-bg-danger ms-1">DROPPED</span></td>
                <td><?php echo (int)$r['total_score']; ?></td>
                <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
                <td><?php echo (int)$r['total_loss']; ?></td>
                <td><?php echo number_format((float)$r['owp'], 3); ?></td>
                <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

    <div class="tab-pane fade" id="pods">
      <?php
      $rounds = (array)($game['rounds'] ?? []);
      $formatSeconds = function(int $sec): string {
        $sec = max(0, $sec);
        $h = intdiv($sec, 3600);
        $m = intdiv($sec % 3600, 60);
        $s = $sec % 60;
        if ($h > 0) return sprintf('%d:%02d:%02d', $h, $m, $s);
        return sprintf('%02d:%02d', $m, $s);
      };
      ?>
      <?php if (empty($rounds)): ?>
        <div class="text-muted">No rounds yet.</div>
      <?php else: ?>
        <?php foreach ($rounds as $round): ?>
          <div class="card mb-3">
            <div class="card-body">
              <?php
                $timeLimit = (int)($round['time_limit_minutes'] ?? 0);
                $timerStart = !empty($round['timer_start']) ? strtotime((string)$round['timer_start']) : null;
                $timerEnd = !empty($round['timer_end']) ? strtotime((string)$round['timer_end']) : null;
                $elapsed = $timerStart ? (($timerEnd ?? time()) - $timerStart) : 0;
                $limitSeconds = $timeLimit > 0 ? ($timeLimit * 60) : 0;
                $overtime = ($limitSeconds > 0) ? max(0, $elapsed - $limitSeconds) : 0;
              ?>
              <div class="fw-semibold">Round <?php echo (int)$round['number']; ?> <span class="small text-muted">Mode: <?php echo e($round['pairing_mode']); ?></span></div>
              <div class="small text-muted">
                Time limit: <?php echo $timeLimit > 0 ? (int)$timeLimit . ' min' : 'Not set'; ?> -
                Elapsed: <?php echo e($formatSeconds((int)$elapsed)); ?> -
                Overtime: <?php echo e($formatSeconds((int)$overtime)); ?>
              </div>
              <?php foreach ((array)($round['pods'] ?? []) as $podIndex => $pod): ?>
                <div class="mt-2 p-2 border rounded">
                  <div class="d-flex justify-content-between">
                    <div class="fw-semibold">Table <?php echo (int)($podIndex + 1); ?></div>
                    <div><?php echo !empty($pod['locked']) ? '<span class="badge text-bg-secondary">LOCKED</span>' : '<span class="badge text-bg-warning">UNLOCKED</span>'; ?></div>
                  </div>

                  <ul class="mb-0 mt-2">
                    <?php foreach ((array)($pod['players'] ?? []) as $email): ?>
                      <?php $meta = $playersMeta[$email] ?? ['name'=>$email]; ?>
                      <?php $score = $pod['scores'][$email] ?? null; ?>
                      <li>
                        <?php echo e($meta['name']); ?> (<?php echo e($email); ?>)
                        - Score: <strong><?php echo ($score === null) ? 'N/A' : (int)$score; ?></strong>
                        - Opponents:
                        <?php
                          $opps = array_values(array_filter((array)$pod['players'], fn($x) => $x !== $email));
                          $oppNames = array_map(fn($o) => e(($playersMeta[$o]['name'] ?? $o)), $opps);
                          echo implode(', ', $oppNames);
                        ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="tab-pane fade" id="stats">
      <?php
      $rounds = (array)($game['rounds'] ?? []);
      $podsCount = 0;
      $scoredPods = 0;
      $sumPodScores = 0;
      $sumScores = 0;
      $scoreCount = 0;
      $pairHistory = [];
      $repeatByPlayer = [];
      $oppCounts = [];

      foreach ($rounds as $round) {
        foreach ((array)($round['pods'] ?? []) as $pod) {
          $podsCount++;
          $players = array_values((array)($pod['players'] ?? []));
          $scores = (array)($pod['scores'] ?? []);
          $podSum = 0;
          $hasScore = false;

          foreach ($players as $p) {
            $s = $scores[$p] ?? null;
            if ($s !== null) {
              $hasScore = true;
              $sumScores += (int)$s;
              $scoreCount++;
              $podSum += (int)$s;
            }
          }

          if ($hasScore) {
            $sumPodScores += $podSum;
            $scoredPods++;
          }

          for ($i = 0; $i < count($players); $i++) {
            for ($j = $i + 1; $j < count($players); $j++) {
              $a = $players[$i];
              $b = $players[$j];
              $key = ($a < $b) ? ($a . '|' . $b) : ($b . '|' . $a);
              if (!empty($pairHistory[$key])) {
                $repeatByPlayer[$a] = (int)($repeatByPlayer[$a] ?? 0) + 1;
                $repeatByPlayer[$b] = (int)($repeatByPlayer[$b] ?? 0) + 1;
              }
              $pairHistory[$key] = (int)($pairHistory[$key] ?? 0) + 1;
            }
          }

          foreach ($players as $p) {
            foreach ($players as $opp) {
              if ($opp === $p) continue;
              $oppCounts[$p][$opp] = (int)($oppCounts[$p][$opp] ?? 0) + 1;
            }
          }
        }
      }

      $avgScorePerEntry = $scoreCount > 0 ? ($sumScores / $scoreCount) : 0;
      $avgPodTotal = $scoredPods > 0 ? ($sumPodScores / $scoredPods) : 0;

      $repeatRows = [];
      foreach ($repeatByPlayer as $email => $count) {
        $repeatRows[] = ['email' => $email, 'count' => $count];
      }
      usort($repeatRows, fn($a, $b) => $b['count'] <=> $a['count']);

      $winRates = $standings['ranked'] ?? [];
      $bucketCounts = [
        '0.00-0.25' => 0,
        '0.25-0.50' => 0,
        '0.50-0.75' => 0,
        '0.75-1.00' => 0,
      ];
      foreach ($winRates as $r) {
        $w = (float)($r['win_rate'] ?? 0);
        if ($w < 0.25) $bucketCounts['0.00-0.25']++;
        elseif ($w < 0.50) $bucketCounts['0.25-0.50']++;
        elseif ($w < 0.75) $bucketCounts['0.50-0.75']++;
        else $bucketCounts['0.75-1.00']++;
      }

      $topOpponents = [];
      foreach ($oppCounts as $email => $counts) {
        arsort($counts);
        $opp = key($counts);
        $cnt = $counts[$opp] ?? 0;
        if ($opp) {
          $topOpponents[] = ['email' => $email, 'opp' => $opp, 'count' => $cnt];
        }
      }
      usort($topOpponents, fn($a, $b) => $b['count'] <=> $a['count']);
      ?>

      <div class="row g-3">
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <div class="fw-semibold mb-2">Totals</div>
              <div>Games: 1</div>
              <div>Rounds: <?php echo count($rounds); ?></div>
              <div>Pods: <?php echo (int)$podsCount; ?></div>
              <div>Players: <?php echo count((array)($game['players'] ?? [])); ?></div>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <div class="fw-semibold mb-2">Averages</div>
              <div>Avg score per player entry: <?php echo number_format($avgScorePerEntry, 2); ?></div>
              <div>Avg total score per pod: <?php echo number_format($avgPodTotal, 2); ?></div>
            </div>
          </div>
        </div>

        <div class="col-md-12 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <div class="fw-semibold mb-2">Win Rate Distribution</div>
              <?php $totalPlayers = max(1, count($winRates)); ?>
              <?php foreach ($bucketCounts as $label => $count): ?>
                <?php $pct = ($count / $totalPlayers) * 100; ?>
                <div class="d-flex justify-content-between small">
                  <span><?php echo e($label); ?></span>
                  <span><?php echo (int)$count; ?></span>
                </div>
                <div class="stat-bar mb-2"><span style="width: <?php echo $pct; ?>%;"></span></div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>

      <div class="row g-3 mt-1">
        <div class="col-lg-6">
          <div class="card h-100">
            <div class="card-body">
              <div class="fw-semibold mb-2">Repeat Pair Count per Player (Top 10)</div>
              <div class="table-responsive">
                <table class="table table-sm align-middle">
                  <thead>
                    <tr><th>Player</th><th>Repeat Pairs</th></tr>
                  </thead>
                  <tbody>
                    <?php foreach (array_slice($repeatRows, 0, 10) as $row): ?>
                      <?php $meta = $playersMeta[$row['email']] ?? ['name' => $row['email']]; ?>
                      <tr>
                        <td><?php echo e($meta['name']); ?></td>
                        <td><?php echo (int)$row['count']; ?></td>
                      </tr>
                    <?php endforeach; ?>
                    <?php if (empty($repeatRows)): ?>
                      <tr><td colspan="2" class="text-muted">No repeats yet.</td></tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-6">
          <div class="card h-100">
            <div class="card-body">
              <div class="fw-semibold mb-2">Top Opponent Frequency (Top 10)</div>
              <div class="table-responsive">
                <table class="table table-sm align-middle">
                  <thead>
                    <tr><th>Player</th><th>Most Frequent Opponent</th><th>Times</th></tr>
                  </thead>
                  <tbody>
                    <?php foreach (array_slice($topOpponents, 0, 10) as $row): ?>
                      <?php
                        $meta = $playersMeta[$row['email']] ?? ['name' => $row['email']];
                        $oppMeta = $playersMeta[$row['opp']] ?? ['name' => $row['opp']];
                      ?>
                      <tr>
                        <td><?php echo e($meta['name']); ?></td>
                        <td><?php echo e($oppMeta['name']); ?></td>
                        <td><?php echo (int)$row['count']; ?></td>
                      </tr>
                    <?php endforeach; ?>
                    <?php if (empty($topOpponents)): ?>
                      <tr><td colspan="3" class="text-muted">No opponent data yet.</td></tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>
