<?php
use App\Core\Auth;

$u = Auth::user();
$isAdmin = $u && (($u['role'] ?? '') === 'admin');
?>
<nav class="navbar navbar-expand-lg border-bottom">
  <div class="container">
    <a class="navbar-brand fw-semibold d-inline-flex align-items-center gap-2" href="?r=<?php echo $isAdmin ? 'admin/dashboard' : 'player/home'; ?>">
      <img src="assets/manapodlogo.png" alt="Mana Pod logo" class="brand-logo">
      Mana Pod Tournament Manager
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <?php if ($u && $isAdmin): ?>
          <li class="nav-item"><a class="nav-link" href="?r=admin/dashboard">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=admin/users">Users</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=admin/players">Players</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=admin/games">Games</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=admin/deckTypes">Deck Types</a></li>
        <?php elseif ($u): ?>
          <li class="nav-item"><a class="nav-link" href="?r=player/home">My Games</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=player/myStats">MyStats</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=player/myDeck">My Deck</a></li>
        <?php endif; ?>
        <li class="nav-item"><a class="nav-link" href="?r=about/index">About</a></li>
      </ul>

      <div class="d-flex align-items-center gap-2">
        <button class="btn btn-outline-secondary btn-sm" type="button" id="themeToggle">Toggle theme</button>

        <?php if ($u): ?>
          <span class="small opacity-75"><?php echo e((string)($u['email'] ?? '')); ?></span>
          <a class="btn btn-outline-danger btn-sm" href="?r=auth/logout">Logout</a>
        <?php else: ?>
          <a class="btn btn-outline-primary btn-sm" href="?r=auth/login">Login</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
