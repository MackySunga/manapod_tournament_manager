<h3 class="mb-3">Players</h3>

<div class="d-flex flex-wrap gap-2 mb-3">
  <form method="post" action="?r=admin/seedPlayers">
    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
    <button class="btn btn-outline-success btn-sm">Add Sample Players Data</button>
  </form>
  <form method="post" action="?r=admin/seedPlayerUsers">
    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
    <button class="btn btn-outline-primary btn-sm">Create Logins for Players (user123456)</button>
  </form>

  <a class="btn btn-outline-secondary btn-sm" href="?r=admin/downloadTemplate">Download Blank CSV Template</a>
  <a class="btn btn-outline-secondary btn-sm" href="?r=admin/downloadGuide">Download CSV Guide</a>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="fw-semibold mb-2">Upload Players via CSV</div>
    <form method="post" action="?r=admin/uploadPlayersCsv" enctype="multipart/form-data" class="row g-2 align-items-end">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="col-md-6">
        <input class="form-control" type="file" name="csv_file" accept=".csv" required>
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary w-100">Import CSV</button>
      </div>
    </form>
    <div class="form-text mt-2">Required headers: <code>email,name</code>. Email is the Player ID.</div>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <div class="fw-semibold">Player List</div>
      <div class="small text-muted">Total: <?php echo (int)$playerCount; ?></div>
    </div>

    <div class="table-responsive">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>Email (ID)</th>
            <th>Name</th>
            <th>Created</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($players as $p): ?>
            <tr>
              <td><?php echo e($p['email']); ?></td>
              <td><?php echo e($p['name']); ?></td>
              <td class="small text-muted"><?php echo e($p['created_at'] ?? ''); ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($players)): ?>
            <tr><td colspan="3" class="text-muted">No players yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
