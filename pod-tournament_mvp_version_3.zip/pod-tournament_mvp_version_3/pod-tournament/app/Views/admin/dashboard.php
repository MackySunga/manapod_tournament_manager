<h3 class="mb-3">Admin Dashboard</h3>

<div class="row g-3">
  <div class="col-md-4">
    <div class="card">
      <div class="card-body">
        <div class="dashboard-title">Total Players</div>
        <hr class="mt-2 mb-3">
        <div class="display-6"><?php echo (int)$playerCount; ?></div>
        <a class="btn btn-sm btn-outline-primary mt-2" href="?r=admin/players">Manage Players</a>
      </div>
    </div>
  </div>

  <div class="col-md-8">
    <div class="card">
      <div class="card-body">
        <div class="dashboard-title mb-2">Games</div>
        <hr class="mt-2 mb-3">
        <?php if (empty($games)): ?>
          <div class="text-muted">No games yet.</div>
        <?php else: ?>
          <div class="list-group">
            <?php foreach ($games as $g): ?>
              <a class="list-group-item list-group-item-action"
                 href="?r=admin/viewGame&id=<?php echo e($g['id']); ?>">
                <div class="d-flex justify-content-between">
                  <div>
                    <div class="fw-semibold"><?php echo e($g['name']); ?></div>
                    <div class="small text-muted"><?php echo e($g['id']); ?> · Players: <?php echo count((array)$g['players']); ?></div>
                  </div>
                  <span class="badge text-bg-<?php echo (($g['status'] ?? '') === 'ended') ? 'secondary' : 'success'; ?>">
                    <?php echo e($g['status'] ?? ''); ?>
                  </span>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <a class="btn btn-sm btn-primary mt-3" href="?r=admin/games">Create New Game</a>
      </div>
    </div>
  </div>
</div>

<?php
$gameCount = count($games);
$activeCount = 0;
$endedCount = 0;
$inactiveCount = 0;
$roundCount = 0;
$completedRounds = 0;
$podCount = 0;
$totalPlayers = 0;
$modeCounts = [];

foreach ($games as $g) {
  $isActive = ($g['is_active'] ?? true);
  $status = (string)($g['status'] ?? '');
  if (!$isActive) {
    $inactiveCount++;
  } elseif ($status === 'ended') {
    $endedCount++;
  } else {
    $activeCount++;
  }

  $playersInGame = count((array)($g['players'] ?? []));
  $totalPlayers += $playersInGame;

  $rounds = (array)($g['rounds'] ?? []);
  $roundCount += count($rounds);
  foreach ($rounds as $r) {
    if (!empty($r['completed'])) $completedRounds++;
    $pods = (array)($r['pods'] ?? []);
    $podCount += count($pods);
    $mode = (string)($r['pairing_mode'] ?? '');
    if ($mode !== '') {
      $modeCounts[$mode] = (int)($modeCounts[$mode] ?? 0) + 1;
    }
  }
}

$avgPlayers = $gameCount > 0 ? ($totalPlayers / $gameCount) : 0;
$avgRounds = $gameCount > 0 ? ($roundCount / $gameCount) : 0;
$avgPodsPerRound = $roundCount > 0 ? ($podCount / $roundCount) : 0;
$completedRate = $roundCount > 0 ? ($completedRounds / $roundCount) : 0;
arsort($modeCounts);
?>

<div class="card mt-3">
  <div class="card-body">
    <div class="dashboard-title mb-2">All Games Stats</div>
    <hr class="mt-2 mb-3">

    <div class="row g-3">
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-semibold mb-2">Totals</div>
            <div>Games: <?php echo $gameCount; ?></div>
            <div>Players (sum): <?php echo $totalPlayers; ?></div>
            <div>Rounds: <?php echo $roundCount; ?></div>
            <div>Pods: <?php echo $podCount; ?></div>
          </div>
        </div>
      </div>

      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-semibold mb-2">Averages</div>
            <div>Avg players per game: <?php echo number_format($avgPlayers, 2); ?></div>
            <div>Avg rounds per game: <?php echo number_format($avgRounds, 2); ?></div>
            <div>Avg pods per round: <?php echo number_format($avgPodsPerRound, 2); ?></div>
            <div>Round completion rate: <?php echo number_format($completedRate * 100, 1); ?>%</div>
          </div>
        </div>
      </div>

      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-semibold mb-2">Game Status</div>
            <?php
              $totalForStatus = max(1, $gameCount);
              $statusRows = [
                'Active' => $activeCount,
                'Ended' => $endedCount,
                'Inactive' => $inactiveCount,
              ];
            ?>
            <?php foreach ($statusRows as $label => $count): ?>
              <?php $pct = ($count / $totalForStatus) * 100; ?>
              <div class="d-flex justify-content-between small">
                <span><?php echo e($label); ?></span>
                <span><?php echo $count; ?></span>
              </div>
              <div class="stat-bar mb-2"><span style="width: <?php echo $pct; ?>%;"></span></div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-3 mt-1">
      <div class="col-lg-6">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-semibold mb-2">Pairing Mode Usage (Top 6)</div>
            <?php if (empty($modeCounts)): ?>
              <div class="text-muted">No rounds yet.</div>
            <?php else: ?>
              <?php
                $topModes = array_slice($modeCounts, 0, 6, true);
                $totalModes = max(1, array_sum($modeCounts));
              ?>
              <?php foreach ($topModes as $mode => $count): ?>
                <?php $pct = ($count / $totalModes) * 100; ?>
                <div class="d-flex justify-content-between small">
                  <span><?php echo e($mode); ?></span>
                  <span><?php echo $count; ?></span>
                </div>
                <div class="stat-bar mb-2"><span style="width: <?php echo $pct; ?>%;"></span></div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-semibold mb-2">Round Progress</div>
            <?php
              $completedPct = $roundCount > 0 ? ($completedRounds / $roundCount) * 100 : 0;
              $remainingPct = 100 - $completedPct;
            ?>
            <div class="d-flex justify-content-between small">
              <span>Completed rounds</span>
              <span><?php echo $completedRounds; ?> / <?php echo $roundCount; ?></span>
            </div>
            <div class="stat-bar mb-2"><span style="width: <?php echo $completedPct; ?>%;"></span></div>
            <div class="d-flex justify-content-between small">
              <span>In-progress rounds</span>
              <span><?php echo max(0, $roundCount - $completedRounds); ?></span>
            </div>
            <div class="stat-bar mb-2"><span style="width: <?php echo $remainingPct; ?>%;"></span></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
