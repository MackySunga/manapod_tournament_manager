<?php
$players = (array)($game['players'] ?? []);
$rounds  = (array)($game['rounds'] ?? []);
$status  = (string)($game['status'] ?? 'active');
$droppedPlayers = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
$allPlayers = array_keys($playersMeta);
$playersLower = array_map('strtolower', $players);
$availablePlayers = array_values(array_filter($allPlayers, function ($email) use ($playersLower) {
  return !in_array(strtolower($email), $playersLower, true);
}));
?>
<div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
  <div>
    <h3 class="mb-1"><?php echo e($game['name']); ?></h3>
    <div class="small text-muted"><span class="fw-semibold">ID:</span> <?php echo e($game['id']); ?></div>
    <div class="small text-muted"><span class="fw-semibold">Status:</span> <span class="badge text-bg-<?php echo $status==='ended'?'secondary':'success'; ?>"><?php echo e($status); ?></span></div>
    <div class="small text-muted"><span class="fw-semibold">Date Created:</span> <?php echo e((string)($game['created_at'] ?? '')); ?></div>
    <div class="small text-muted"><span class="fw-semibold">Date Completed:</span> <?php echo e((string)($game['ended_at'] ?? '')); ?></div>
    <div class="small text-muted"><span class="fw-semibold">No. of Players:</span> <?php echo count($players); ?></div>
    <div class="small text-muted"><span class="fw-semibold">Rounds:</span> <?php echo count($rounds); ?></div>
  </div>

  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-lg fw-bold" href="?r=admin/reports&id=<?php echo e($game['id']); ?>">Reports</a>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Add Players to Game</div>
    <hr class="mt-0 mb-3">

    <?php if ($status !== 'active'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1">Game ended. Players cannot be added.</div>
    <?php elseif (empty($allPlayers)): ?>
      <div class="text-muted">No players yet. Add players in Admin &rarr; Players.</div>
    <?php elseif (empty($availablePlayers)): ?>
      <div class="text-muted">All players are already in this game.</div>
    <?php else: ?>
      <form method="post" action="?r=admin/addGamePlayers" class="row g-2 align-items-end">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">

        <div class="col-md-9">
          <label class="form-label">Select Players to Add</label>
          <select class="form-select" name="players[]" multiple size="8">
            <?php foreach ($availablePlayers as $email): ?>
              <?php $p = $playersMeta[$email] ?? ['name' => $email]; ?>
              <option value="<?php echo e($email); ?>"><?php echo e($p['name']); ?> (<?php echo e($email); ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3">
          <button class="btn btn-primary w-100">Add Players</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Display Background (Secondary Screen)</div>
    <hr class="mt-0 mb-3">
    <form method="post" action="?r=admin/uploadDisplayBackground" enctype="multipart/form-data" class="row g-2 align-items-end">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <div class="col-md-8">
        <label class="form-label">Upload Background (PNG/JPG/WEBP)</label>
        <input class="form-control" type="file" name="background_file" accept=".png,.jpg,.jpeg,.webp" required <?php echo $status === 'ended' ? 'disabled' : ''; ?>>
        <?php if (!empty($game['display_background'])): ?>
          <div class="small text-muted mt-1">Current: <?php echo e((string)$game['display_background']); ?></div>
        <?php endif; ?>
      </div>
      <div class="col-md-4">
        <button class="btn btn-outline-secondary w-100" <?php echo $status === 'ended' ? 'disabled' : ''; ?>>Upload Background</button>
      </div>
    </form>
    <?php if ($status === 'ended'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1 mt-2">GAME ENDED. NO MORE CHANGES.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Sponsor Banner (Display Only)</div>
    <hr class="mt-0 mb-3">
    <form method="post" action="?r=admin/uploadSponsorBanner" enctype="multipart/form-data" class="row g-2 align-items-end">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <div class="col-md-8">
        <label class="form-label">Upload Banner (PNG/JPG/WEBP)</label>
        <input class="form-control" type="file" name="sponsor_file" accept=".png,.jpg,.jpeg,.webp" required <?php echo $status === 'ended' ? 'disabled' : ''; ?>>
        <?php if (!empty($game['sponsor_banner'])): ?>
          <div class="small text-muted mt-1">Current: <?php echo e((string)$game['sponsor_banner']); ?></div>
        <?php endif; ?>
      </div>
      <div class="col-md-4">
        <button class="btn btn-outline-secondary w-100" <?php echo $status === 'ended' ? 'disabled' : ''; ?>>Upload Banner</button>
      </div>
    </form>
    <?php if ($status === 'ended'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1 mt-2">GAME ENDED. NO MORE CHANGES.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Create New Round</div>
    <hr class="mt-0 mb-3">

    <?php if ($status !== 'active'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1">Game ended. No more rounds can be created.</div>
    <?php else: ?>
      <form method="post" action="?r=admin/createRound" class="row g-2 align-items-end">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">

        <div class="col-md-6">
          <label class="form-label">Pairing Mode</label>
          <select class="form-select" name="pairing_mode">
            <option value="ranking_top4">A) Ranking: top 4 per pod (table order)</option>
            <option value="ranking_highlow">B) Ranking: 2 highest + 2 lowest per pod</option>
            <option value="swiss_pods">C) Swiss Pods (recommended)</option>
            <option value="true_swiss">D) True Swiss</option>
            <option value="power_pods">E) Power Pods</option>
            <option value="bubble_pods">F) Bubble Pods</option>
            <option value="random_pods">G) Random Pods (avoid repeats)</option>
            <option value="top1_low3">H) Highest 1 vs Lowest 3</option>
            <option value="alpha_no_repeat">I) Alphabetical (tries to avoid repeats)</option>
          </select>
          <div class="form-text">
            Note: “avoid repeats” is best-effort when later rounds make perfect avoidance impossible.
          </div>
        </div>

        <div class="col-md-3">
          <button class="btn btn-primary w-100">Create Round</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Current Ranking (Tie-break rules applied)</div>
    <hr class="mt-0 mb-3">

    <div class="d-flex flex-wrap justify-content-between gap-2 mb-2">
      <input class="form-control form-control-sm" id="rankingSearch" type="search" placeholder="Search ranking..." style="max-width: 280px;">
    </div>
    <div class="table-responsive ranking-scroll">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>Player</th>
            <th>Total Score</th>
            <th>Total Wins Points</th>
            <th>Win Rate</th>
            <th>Match-win %</th>
            <th>Game-win %</th>
            <th>OWP</th>
            <th>OGP</th>
            <th>Status</th>
          </tr>
          <tr>
            <th><input class="form-control form-control-sm ranking-filter" data-col="0" placeholder="#"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="1" placeholder="Player"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="2" placeholder="Score"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="3" placeholder="Win Pts"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="4" placeholder="Win %"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="5" placeholder="Match %"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="6" placeholder="Game %"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="7" placeholder="OWP"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="8" placeholder="OGP"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="9" placeholder="Status"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach (($standings['ranked'] ?? []) as $i => $r): ?>
            <?php
              $emailLower = strtolower((string)$r['email']);
              $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']];
              $isDropped = in_array($emailLower, $droppedPlayers, true);
            ?>
            <tr class="<?php echo $isDropped ? 'table-secondary' : ''; ?>">
              <td><?php echo $i+1; ?></td>
              <td>
                <?php echo e($meta['name']); ?>
                <span class="small text-muted">(<?php echo e($r['email']); ?>)</span>
                <?php if ($isDropped): ?>
                  <span class="badge text-bg-danger ms-1">DROPPED</span>
                <?php endif; ?>
              </td>
              <td><?php echo (int)$r['total_score']; ?></td>
              <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
              <td><?php echo number_format((float)$r['win_rate'], 3); ?></td>
              <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['owp'], 3); ?></td>
              <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
              <td>
                <form method="post" action="?r=admin/toggleDropPlayer" class="m-0">
                  <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                  <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
                  <input type="hidden" name="email" value="<?php echo e($r['email']); ?>">
                  <input type="hidden" name="drop" value="<?php echo $isDropped ? '0' : '1'; ?>">
                  <button class="btn btn-sm <?php echo $isDropped ? 'btn-outline-success' : 'btn-outline-danger'; ?>" <?php echo $status === 'ended' ? 'disabled' : ''; ?>>
                    <?php echo $isDropped ? 'Rejoin' : 'Drop'; ?>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($standings['ranked'])): ?>
            <tr><td colspan="10" class="text-muted">No standings yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php if ($status === 'ended'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1 mt-2">GAME ENDED. NO MORE CHANGES.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="section-title">Rounds</div>
    <hr class="mt-0 mb-3">

    <?php if (empty($rounds)): ?>
      <div class="text-muted">No rounds created yet.</div>
    <?php else: ?>
      <div class="list-group">
        <?php $lastRoundNum = count($rounds); ?>
        <?php foreach ($rounds as $r): ?>
          <?php
            $roundStatus = 'PREPARING';
            if (!empty($r['completed'])) {
              $roundStatus = 'COMPLETED';
            } elseif (!empty($r['timer_running'])) {
              $roundStatus = 'IN PROGRESS';
            } elseif (!empty($r['timer_start'])) {
              $roundStatus = 'TIMER STOPPED';
            } elseif (!empty($r['pairing_locked'])) {
              $roundStatus = 'PAIRINGS LOCKED';
            }
            $statusClass = 'text-bg-secondary';
            if ($roundStatus === 'COMPLETED') $statusClass = 'text-bg-success';
            elseif ($roundStatus === 'IN PROGRESS') $statusClass = 'text-bg-primary';
            elseif ($roundStatus === 'PAIRINGS LOCKED') $statusClass = 'text-bg-warning';
          ?>
          <a class="list-group-item list-group-item-action"
             href="<?php echo $status === 'ended' ? ('?r=admin/reports&id=' . e($game['id'])) : ('?r=admin/viewRound&id=' . e($game['id']) . '&round=' . (int)$r['number']); ?>">
            <div class="d-flex justify-content-between">
              <div>
                <div class="fw-semibold">Round <?php echo (int)$r['number']; ?></div>
                <div class="small text-muted">Pods: <?php echo count((array)$r['pods']); ?></div>
              </div>
              <div class="d-flex align-items-center gap-2">
                <span class="badge <?php echo $statusClass; ?>"><?php echo e($roundStatus); ?></span>
                <div class="small text-muted"><?php echo e($r['created_at'] ?? ''); ?></div>
                <?php if ((int)$r['number'] === $lastRoundNum && empty($r['timer_start']) && empty($r['completed'])): ?>
                  <form method="post" action="?r=admin/deleteRound" onsubmit="return confirm('Delete this round?');">
                    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                    <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
                    <input type="hidden" name="round" value="<?php echo (int)$r['number']; ?>">
                    <button class="btn btn-outline-danger btn-sm">Delete</button>
                  </form>
                <?php endif; ?>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="card mt-3">
  <div class="card-body">
    <div class="section-title">AUDIT LOGS</div>
    <hr class="mt-0 mb-3">
    <?php
      $formatAuditTime = function ($ts): string {
        if (!$ts) return '';
        try {
          $dt = new DateTime((string)$ts);
          return $dt->format('y-m-d h:i A');
        } catch (Exception $e) {
          return (string)$ts;
        }
      };
      $sortAudit = function (array $rows): array {
        usort($rows, function ($a, $b) {
          $ta = strtotime((string)($a['time'] ?? '')) ?: 0;
          $tb = strtotime((string)($b['time'] ?? '')) ?: 0;
          return $tb <=> $ta;
        });
        return $rows;
      };
      $gameAudit = $sortAudit((array)($game['audit'] ?? []));
    ?>

    <?php if (empty($gameAudit) && empty($rounds)): ?>
      <div class="text-muted text-center">No audit entries yet.</div>
    <?php else: ?>
      <?php if (!empty($gameAudit)): ?>
        <div class="fw-semibold mb-2">Game Actions</div>
        <div class="table-responsive audit-scroll mb-3">
          <table class="table table-sm align-middle">
            <thead>
              <tr>
                <th>Game</th>
                <th>Time</th>
                <th>User</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($gameAudit as $entry): ?>
                <tr>
                  <td><?php echo e((string)($game['name'] ?? '')); ?></td>
                  <td><?php echo e($formatAuditTime($entry['time'] ?? '')); ?></td>
                  <td><?php echo e((string)($entry['user'] ?? '')); ?></td>
                  <td><?php echo e((string)($entry['message'] ?? '')); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

      <?php foreach ($rounds as $r): ?>
        <?php $roundAudit = $sortAudit((array)($r['audit'] ?? [])); ?>
        <div class="fw-semibold mb-2">Round <?php echo (int)($r['number'] ?? 0); ?></div>
        <?php if (empty($roundAudit)): ?>
          <div class="text-muted mb-3">No audit entries for this round.</div>
        <?php else: ?>
          <div class="table-responsive audit-scroll mb-3">
            <table class="table table-sm align-middle">
              <thead>
                <tr>
                  <th>Game</th>
                  <th>Round</th>
                  <th>Time</th>
                  <th>User</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($roundAudit as $entry): ?>
                  <tr>
                    <td><?php echo e((string)($game['name'] ?? '')); ?></td>
                    <td><?php echo (int)($r['number'] ?? 0); ?></td>
                    <td><?php echo e($formatAuditTime($entry['time'] ?? '')); ?></td>
                    <td><?php echo e((string)($entry['user'] ?? '')); ?></td>
                    <td><?php echo e((string)($entry['message'] ?? '')); ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<script>
(() => {
  const table = document.querySelector(".ranking-scroll table");
  if (!table) return;
  const rows = Array.from(table.querySelectorAll("tbody tr"));
  const search = document.getElementById("rankingSearch");
  const filters = Array.from(document.querySelectorAll(".ranking-filter"));

  function matches(row) {
    const text = row.textContent.toLowerCase();
    if (search && search.value.trim() !== "") {
      if (!text.includes(search.value.toLowerCase().trim())) return false;
    }
    for (const input of filters) {
      const val = input.value.toLowerCase().trim();
      if (!val) continue;
      const col = Number(input.dataset.col || 0);
      const cell = row.children[col];
      if (!cell || !cell.textContent.toLowerCase().includes(val)) return false;
    }
    return true;
  }

  function applyFilters() {
    rows.forEach((row) => {
      row.style.display = matches(row) ? "" : "none";
    });
  }

  if (search) search.addEventListener("input", applyFilters);
  filters.forEach((input) => input.addEventListener("input", applyFilters));
})();
</script>

<?php if ($status === 'ended'): ?>
  <div class="d-flex justify-content-start mt-3">
    <form method="post" action="?r=admin/reopenGame" onsubmit="return confirm('Reopen this game? This will allow changes again.');">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <button class="btn btn-success btn-lg fw-bold">Reopen Game</button>
    </form>
  </div>
<?php endif; ?>
