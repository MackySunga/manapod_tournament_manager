<h3 class="mb-3">Deck Types</h3>

<div class="card mb-3">
  <div class="card-body">
    <div class="fw-semibold mb-2">Add Deck Type</div>
    <form method="post" action="?r=admin/addDeckType" class="row g-2 align-items-end">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="col-md-6">
        <label class="form-label">Type Name</label>
        <input class="form-control" name="type_name" placeholder="e.g. Modern" required>
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary w-100">Add Type</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="fw-semibold mb-2">Available Types</div>
    <ul class="mb-0">
      <?php foreach ($types as $t): ?>
        <li><?php echo e($t); ?></li>
      <?php endforeach; ?>
      <?php if (empty($types)): ?>
        <li class="text-muted">No types yet.</li>
      <?php endif; ?>
    </ul>
  </div>
</div>
