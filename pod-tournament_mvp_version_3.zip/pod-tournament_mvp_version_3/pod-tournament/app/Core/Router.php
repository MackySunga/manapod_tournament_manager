<?php
declare(strict_types=1);

namespace App\Core;

final class Router
{
    public function dispatch(string $route): void
    {
        $route = trim($route, '/');
        if ($route === '') $route = 'auth/login';

        [$group, $action] = array_pad(explode('/', $route, 2), 2, 'index');

        $map = [
            'auth'   => \App\Controllers\AuthController::class,
            'admin'  => \App\Controllers\AdminController::class,
            'player' => \App\Controllers\PlayerController::class,
            'display' => \App\Controllers\DisplayController::class,
            'about' => \App\Controllers\AboutController::class,
        ];

        $controllerClass = $map[$group] ?? null;
        if (!$controllerClass || !class_exists($controllerClass)) {
            http_response_code(404);
            echo "Route not found.";
            return;
        }

        $controller = new $controllerClass();

        if (!method_exists($controller, $action)) {
            http_response_code(404);
            echo "Action not found.";
            return;
        }

        $controller->$action();
    }
}
