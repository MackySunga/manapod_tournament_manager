<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\DataStore;

final class DeckTypeModel
{
    private DataStore $ds;
    private string $file = 'deck_types.json';

    private array $defaults = [
        'Commander',
        'Duel Commander',
        'Standard',
        'Pioneer',
    ];

    public function __construct()
    {
        $this->ds = new DataStore();
    }

    public function all(): array
    {
        $data = $this->ds->load($this->file, ['types' => []]);
        $types = array_values(array_filter(array_map('strval', (array)($data['types'] ?? []))));
        if (empty($types)) {
            $types = $this->defaults;
            $this->saveAll($types);
        }
        return $types;
    }

    public function add(string $type): bool
    {
        $type = trim($type);
        if ($type === '') return false;

        $types = $this->all();
        $lower = array_map('strtolower', $types);
        if (in_array(strtolower($type), $lower, true)) {
            return false;
        }
        $types[] = $type;
        $this->saveAll($types);
        return true;
    }

    public function saveAll(array $types): void
    {
        $types = array_values(array_filter(array_map('strval', $types)));
        $this->ds->save($this->file, ['types' => $types]);
    }
}
