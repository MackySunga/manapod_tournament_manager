<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\DataStore;

final class DeckModel
{
    private DataStore $ds;
    private string $file = 'decks.json';

    public function __construct()
    {
        $this->ds = new DataStore();
    }

    public function all(): array
    {
        $data = $this->ds->load($this->file, ['decks' => []]);
        return (array)($data['decks'] ?? []);
    }

    public function listByUser(string $email): array
    {
        $email = strtolower(trim($email));
        $rows = [];
        foreach ($this->all() as $deck) {
            if (($deck['user_email'] ?? '') === $email) {
                $rows[] = $deck;
            }
        }
        usort($rows, fn($a, $b) => strcmp((string)($b['created_at'] ?? ''), (string)($a['created_at'] ?? '')));
        return $rows;
    }

    public function add(array $deck): void
    {
        $decks = $this->all();
        $deck['id'] = $deck['id'] ?? ('d_' . bin2hex(random_bytes(6)));
        $decks[] = $deck;
        $this->ds->save($this->file, ['decks' => $decks]);
    }
}
