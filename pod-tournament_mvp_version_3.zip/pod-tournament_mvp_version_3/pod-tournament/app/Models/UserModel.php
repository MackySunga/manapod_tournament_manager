<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\DataStore;

final class UserModel
{
    private DataStore $ds;
    private string $file = 'users.json';

    public function __construct()
    {
        $this->ds = new DataStore();
        $this->seedAdminIfEmpty();
    }

    public function all(): array
    {
        $data = $this->ds->load($this->file, ['users' => []]);
        return (array)($data['users'] ?? []);
    }

    public function saveAll(array $usersByEmail): void
    {
        $this->ds->save($this->file, ['users' => $usersByEmail]);
    }

    public function find(string $email): ?array
    {
        $email = strtolower(trim($email));
        $all = $this->all();
        return $all[$email] ?? null;
    }

    public function upsert(array $user): void
    {
        $email = strtolower(trim((string)($user['email'] ?? '')));
        if ($email === '') return;

        $all = $this->all();

        $prev = $all[$email] ?? [];

        // Keep created_at if already exists
        $user['created_at'] = $prev['created_at'] ?? ($user['created_at'] ?? date('c'));

        // Default disabled
        if (!array_key_exists('disabled', $user)) {
            $user['disabled'] = (bool)($prev['disabled'] ?? false);
        }

        $all[$email] = $user;
        $this->saveAll($all);
    }

    public function countAdmins(): int
    {
        $all = $this->all();
        $c = 0;
        foreach ($all as $u) {
            if (($u['role'] ?? '') === 'admin' && empty($u['disabled'])) $c++;
        }
        return $c;
    }

    private function seedAdminIfEmpty(): void
    {
        $data = $this->ds->load($this->file, ['users' => []]);
        $users = (array)($data['users'] ?? []);

        if (!isset($users['admin@example.com'])) {
            $users['admin@example.com'] = [
                'email' => 'admin@example.com',
                'name' => 'Administrator',
                'role' => 'admin',
                'password_hash' => password_hash('admin123', PASSWORD_DEFAULT),
                'disabled' => false,
                'created_at' => date('c'),
            ];
            $this->ds->save($this->file, ['users' => $users]);
        } else {
            // Ensure disabled exists
            if (!array_key_exists('disabled', $users['admin@example.com'])) {
                $users['admin@example.com']['disabled'] = false;
                $this->ds->save($this->file, ['users' => $users]);
            }
        }
    }
}
