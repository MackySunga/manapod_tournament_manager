<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Csrf;
use App\Models\PlayerModel;
use App\Models\GameModel;
use App\Models\DeckTypeModel;
use App\Models\GameModeModel;
use App\Models\ScoreSystemModel;
use App\Services\CsvService;
use App\Services\PodBuilder;
use App\Services\StandingsService;
use App\Services\DataStore;

use App\Models\UserModel;


final class AdminController extends Controller
{
    public function dashboard(): void
    {
        Auth::requireAdmin();

        $players = new PlayerModel();
        $games = (new GameModel())->all();

        $this->render('admin/dashboard', [
            'csrf' => Csrf::token(),
            'user' => Auth::user(),
            'playerCount' => $players->count(),
            'games' => $games,
        ]);
    }

    public function players(): void
    {
        Auth::requireAdmin();

        redirect('admin/users');
    }

    public function deckTypes(): void
    {
        Auth::requireAdmin();
        $types = (new DeckTypeModel())->all();
        $gameModes = (new GameModeModel())->all();
        $scoreSystems = (new ScoreSystemModel())->all();

        $this->render('admin/deck_types', [
            'csrf' => Csrf::token(),
            'user' => Auth::user(),
            'types' => $types,
            'gameModes' => $gameModes,
            'scoreSystems' => $scoreSystems,
        ]);
    }

    public function addDeckType(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $type = (string)($_POST['type_name'] ?? '');
        $added = (new DeckTypeModel())->add($type);
        if ($added) {
            flash_set('success', 'Deck type added.');
        } else {
            flash_set('error', 'Deck type already exists or is invalid.');
        }
        redirect('admin/deckTypes');
    }

    public function addGameMode(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $mode = (string)($_POST['mode_name'] ?? '');
        $added = (new GameModeModel())->add($mode);
        if ($added) {
            flash_set('success', 'Game mode added.');
        } else {
            flash_set('error', 'Game mode already exists or is invalid.');
        }
        redirect('admin/deckTypes');
    }

public function addScoreSystem(): void
{
    Auth::requireAdmin();
    Csrf::check();

        $system = (string)($_POST['system_name'] ?? '');
        $added = (new ScoreSystemModel())->add($system);
        if ($added) {
            flash_set('success', 'Score system added.');
        } else {
            flash_set('error', 'Score system already exists or is invalid.');
        }
    redirect('admin/deckTypes');
}

public function downloadUsersTemplate(): void
{
    Auth::requireAdmin();

    $csv = "email,name,role,password\n";
    $csv .= "player1@example.com,Player One,player,user123456\n";
    $csv .= "admin2@example.com,Admin Two,admin,admin123\n";

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=\"users_template.csv\"');
    echo $csv;
    exit;
}

public function uploadUsersCsv(): void
{
    Auth::requireAdmin();
    Csrf::check();

    if (empty($_FILES['csv_file']) || !is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
        flash_set('error', 'Please upload a CSV file.');
        redirect('admin/users');
    }

    $rows = (new CsvService())->read($_FILES['csv_file']['tmp_name']);
    if (empty($rows)) {
        flash_set('error', 'CSV is empty.');
        redirect('admin/users');
    }

    $um = new UserModel();
    $pm = new PlayerModel();

    $created = 0;
    $skipped = 0;

    foreach ($rows as $row) {
        $email = strtolower(trim((string)($row['email'] ?? '')));
        $name = trim((string)($row['name'] ?? ''));
        $role = strtolower(trim((string)($row['role'] ?? 'player')));
        $pass = (string)($row['password'] ?? '');

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $skipped++;
            continue;
        }
        if (!in_array($role, ['admin', 'player'], true)) {
            $role = 'player';
        }
        if (strlen($pass) < 6) {
            $skipped++;
            continue;
        }
        if ($um->find($email)) {
            $skipped++;
            continue;
        }
        if ($name === '') $name = $email;

        $um->upsert([
            'email' => $email,
            'name' => $name,
            'role' => $role,
            'password_hash' => password_hash($pass, PASSWORD_DEFAULT),
            'disabled' => false,
            'created_at' => date('c'),
        ]);
        if ($role === 'player') {
            $pm->upsert($email, $name);
        }
        $this->addUserAudit('User created (CSV): ' . $email . '.');
        $created++;
    }

    flash_set('success', "Imported {$created} users. Skipped {$skipped}.");
    redirect('admin/users');
}

    public function seedPlayers(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $added = (new PlayerModel())->seedSample();
        flash_set('success', "Seeded $added sample players.");
        redirect('admin/users');
    }

    public function seedPlayerUsers(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $pm = new PlayerModel();
        $players = $pm->all();

        $um = new UserModel();
        $created = 0;
        $skipped = 0;
        $defaultPassword = 'user123456';

        foreach ($players as $email => $p) {
            if ($um->find($email)) {
                $skipped++;
                continue;
            }

            $name = (string)($p['name'] ?? $email);
            $um->upsert([
                'email' => $email,
                'name' => $name,
                'role' => 'player',
                'password_hash' => password_hash($defaultPassword, PASSWORD_DEFAULT),
                'disabled' => false,
                'created_at' => date('c'),
            ]);
            $created++;
        }

        flash_set('success', "Created $created player login(s). Skipped $skipped existing user(s). Password: $defaultPassword");
        redirect('admin/users');
    }

    public function uploadPlayersCsv(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        if (empty($_FILES['csv_file']['tmp_name'])) {
            flash_set('error', 'No CSV uploaded.');
            redirect('admin/users');
        }

        $csv = new CsvService();
        $rows = $csv->parsePlayersCsv((string)$_FILES['csv_file']['tmp_name']);

        $pm = new PlayerModel();
        foreach ($rows as $r) {
            $pm->upsert($r['email'], $r['name']);
        }

        flash_set('success', 'CSV import complete. Imported: ' . count($rows));
        redirect('admin/users');
    }

    public function downloadTemplate(): void
    {
        Auth::requireAdmin();
        $csv = (new CsvService())->blankTemplateCsv();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="players_template.csv"');
        echo $csv;
    }

    public function downloadGuide(): void
    {
        Auth::requireAdmin();
        $txt = (new CsvService())->templateGuideText();

        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="players_upload_guide.txt"');
        echo $txt;
    }

    public function games(): void
    {
        Auth::requireAdmin();

        $pm = new PlayerModel();
        $players = $pm->all();

        $gm = new GameModel();
        $games = $gm->all();
        $gameModes = (new GameModeModel())->all();
        $scoreSystems = (new ScoreSystemModel())->all();

        $this->render('admin/games', [
            'csrf' => Csrf::token(),
            'user' => Auth::user(),
            'players' => $players,
            'games' => $games,
            'gameModes' => $gameModes,
            'scoreSystems' => $scoreSystems,
        ]);
    }

    public function createGame(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $name = trim((string)($_POST['name'] ?? ''));
        $gameMode = trim((string)($_POST['game_mode'] ?? ''));
        $scoreSystem = trim((string)($_POST['score_system'] ?? ''));
        $description = trim((string)($_POST['description'] ?? ''));
        $selected = (array)($_POST['players'] ?? []);

        $selected = array_values(array_unique(array_map('strtolower', $selected)));

        $gameModeModel = new GameModeModel();
        $scoreSystemModel = new ScoreSystemModel();
        $modes = $gameModeModel->all();
        $systems = $scoreSystemModel->all();

        if ($gameMode === '' || !in_array($gameMode, $modes, true)) {
            $gameMode = $modes[0] ?? '';
        }
        if ($scoreSystem === '' || !in_array($scoreSystem, $systems, true)) {
            $scoreSystem = $systems[0] ?? '';
        }

        $gm = new GameModel();
        if ($name !== '') {
            $nameNormalized = strtolower($name);
            foreach ($gm->all() as $g) {
                if (strtolower((string)($g['name'] ?? '')) === $nameNormalized) {
                    flash_set('error', 'Game name already exists.');
                    redirect('admin/games');
                }
            }
        }

        $id = $gm->create($name, $selected, $gameMode, $description, $scoreSystem);
        flash_set('success', 'Game created.');
        redirect('admin/viewGame&id=' . urlencode($id));
    }

    public function deleteGame(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $id = (string)($_POST['id'] ?? '');
        if ($id === '') {
            flash_set('error', 'Game id missing.');
            redirect('admin/games');
        }

        $gm = new GameModel();
        if (!$gm->find($id)) {
            flash_set('error', 'Game not found.');
            redirect('admin/games');
        }

        $gm->delete($id);
        flash_set('success', 'Game deleted.');
        redirect('admin/games');
    }

    public function setGameActive(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $id = (string)($_POST['id'] ?? '');
        $active = (string)($_POST['active'] ?? '');
        if ($id === '') {
            flash_set('error', 'Game id missing.');
            redirect('admin/games');
        }

        $gm = new GameModel();
        $game = $gm->find($id);
        if (!$game) {
            flash_set('error', 'Game not found.');
            redirect('admin/games');
        }

        $game['is_active'] = ($active === '1');
        $gm->update($id, $game);

        flash_set('success', ($game['is_active'] ? 'Game activated.' : 'Game deactivated.'));
        redirect('admin/games');
    }

    public function viewGame(): void
    {
        Auth::requireAdmin();

        $id = (string)($_GET['id'] ?? '');
        $gm = new GameModel();
        $game = $gm->find($id);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $standings = (new StandingsService())->compute($game);

        $this->render('admin/game_view', [
            'csrf' => Csrf::token(),
            'user' => Auth::user(),
            'game' => $game,
            'playersMeta' => $playersMeta,
            'standings' => $standings,
        ]);
    }

    public function addGamePlayers(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $id = (string)($_POST['game_id'] ?? '');
        $selected = (array)($_POST['players'] ?? []);
        if ($id === '') {
            flash_set('error', 'Game id missing.');
            redirect('admin/games');
        }

        $gm = new GameModel();
        $game = $gm->find($id);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        if (($game['status'] ?? '') !== 'active') {
            flash_set('error', 'Cannot add players to an ended game.');
            redirect('admin/viewGame&id=' . urlencode($id));
        }

        $selected = array_values(array_unique(array_map('strtolower', $selected)));
        if (empty($selected)) {
            flash_set('error', 'Select at least one player to add.');
            redirect('admin/viewGame&id=' . urlencode($id));
        }

        $existing = array_values(array_unique(array_map('strtolower', (array)($game['players'] ?? []))));
        $game['players'] = array_values(array_unique(array_merge($existing, $selected)));
        $this->addGameAudit($game, 'Players added to game: ' . count($selected) . '.');
        $gm->update($id, $game);

        flash_set('success', 'Players added to game.');
        redirect('admin/viewGame&id=' . urlencode($id));
    }

    public function toggleDropPlayer(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $drop = (string)($_POST['drop'] ?? '') === '1';

        if ($gameId === '' || $email === '') {
            flash_set('error', 'Missing game or player.');
            redirect('admin/games');
        }

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) {
            flash_set('error', 'Game not found.');
            redirect('admin/games');
        }

        if (($game['status'] ?? '') !== 'active') {
            flash_set('error', 'Cannot change player status for an ended game.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $players = array_values(array_unique(array_map('strtolower', (array)($game['players'] ?? []))));
        if (!in_array($email, $players, true)) {
            flash_set('error', 'Player not found in this game.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $dropped = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
        if ($drop) {
            if (!in_array($email, $dropped, true)) {
                $dropped[] = $email;
            }
        } else {
            $dropped = array_values(array_filter($dropped, fn($p) => $p !== $email));
        }

        $game['dropped_players'] = $dropped;
        $this->addGameAudit($game, $drop ? ('Player dropped: ' . $email . '.') : ('Player rejoined: ' . $email . '.'));
        $gm->update($gameId, $game);

        flash_set('success', $drop ? 'Player marked as dropped.' : 'Player rejoined the game.');
        redirect('admin/viewGame&id=' . urlencode($gameId));
    }

    public function createRound(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $id = (string)($_POST['game_id'] ?? '');
        $mode = (string)($_POST['pairing_mode'] ?? 'ranking_top4');

        $gm = new GameModel();
        $game = $gm->find($id);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        if (($game['status'] ?? '') !== 'active') {
            flash_set('error', 'Game already ended.');
            redirect('admin/viewGame&id=' . urlencode($id));
        }

        $rounds = (array)($game['rounds'] ?? []);
        foreach ($rounds as $r) {
            if (empty($r['completed'])) {
                flash_set('error', 'Cannot create a new round while another round is still active.');
                redirect('admin/viewGame&id=' . urlencode($id));
            }
        }

        // Ensure previous round fully locked before making next
        if (count($rounds) > 0) {
            $last = $rounds[count($rounds)-1];
            foreach ((array)($last['pods'] ?? []) as $pod) {
                if (empty($pod['locked'])) {
                    flash_set('error', 'Cannot create next round: previous round has unlocked pods.');
                    redirect('admin/viewGame&id=' . urlencode($id));
                }
            }
        }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $ss = new StandingsService();
        $standings = $ss->compute($game);
        $rankingOrder = array_map(fn($r) => $r['email'], $standings['ranked']);
        $historyPairs = $ss->buildPairHistory($game);

        $builder = new PodBuilder();
        $dropped = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
        $activePlayers = array_values(array_filter(
            array_map('strtolower', (array)($game['players'] ?? [])),
            fn($p) => !in_array($p, $dropped, true)
        ));
        if (empty($activePlayers)) {
            flash_set('error', 'Cannot re-pair: all players are marked as dropped.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $pods = $builder->buildPods(
            $activePlayers,
            $mode,
            $playersMeta,
            $rankingOrder,
            $historyPairs,
            (array)($standings['by_email'] ?? [])
        );

        $roundNum = count($rounds) + 1;

        $round = [
            'number' => $roundNum,
            'created_at' => date('c'),
            'pairing_mode' => $mode,
            'pairing_locked' => false,
            'time_limit_minutes' => null,
            'timer_locked' => false,
            'timer_start' => null,
            'timer_end' => null,
            'timer_running' => false,
            'completed' => false,
            'completed_at' => null,
            'display_show_pods' => false,
            'display_show_results' => false,
            'pods' => [],
        ];

        foreach ($pods as $idx => $pList) {
            $podId = 'r' . $roundNum . '_p' . ($idx+1);
            $scores = [];
            foreach ($pList as $p) $scores[$p] = null;

            $round['pods'][] = [
                'id' => $podId,
                'players' => $pList,
                'scores' => $scores,
                'locked' => false,
                'saved' => false,
            ];
        }

        $game['rounds'][] = $round;
        $this->addRoundAudit($game, $roundNum - 1, 'Round created.');
        $this->addGameAudit($game, 'Round ' . $roundNum . ' created.');
        $gm->update($id, $game);

        flash_set('success', "Round $roundNum created.");
        redirect('admin/viewRound&id=' . urlencode($id) . '&round=' . $roundNum);
    }

    public function viewRound(): void
    {
        Auth::requireAdmin();

        $id = (string)($_GET['id'] ?? '');
        $roundNum = (int)($_GET['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($id);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $round = $rounds[$roundNum - 1] ?? null;
        if (!$round) { flash_set('error','Round not found.'); redirect('admin/viewGame&id=' . urlencode($id)); }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $gameForStandings = $game;
        $gameForStandings['rounds'] = array_slice($rounds, 0, $roundNum);
        $standings = (new StandingsService())->compute($gameForStandings);

        $this->render('admin/round_view', [
            'csrf' => Csrf::token(),
            'user' => Auth::user(),
            'game' => $game,
            'round' => $round,
            'roundNum' => $roundNum,
            'playersMeta' => $playersMeta,
            'roundStandings' => $standings,
            'suppressFlash' => true,
        ]);
    }

    public function completeRound(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (!empty($rounds[$roundIndex]['completed'])) {
            flash_set('error','Round already completed.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }
        if (!empty($rounds[$roundIndex]['timer_running'])) {
            flash_set('error','Stop the round timer before completing.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        foreach ((array)($rounds[$roundIndex]['pods'] ?? []) as $pod) {
            if (empty($pod['locked'])) {
                flash_set('error','All tables must be locked before completing the round.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
        }

        $rounds[$roundIndex]['completed'] = true;
        $rounds[$roundIndex]['completed_at'] = date('c');
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, 'Round completed.');
        $gm->update($gameId, $game);

        flash_set('success','Round completed.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function setDisplayPods(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);
        $show = (string)($_POST['show'] ?? '0') === '1';

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (!empty($rounds[$roundIndex]['completed'])) {
            flash_set('error','Cannot change display pods after the round is completed.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $rounds[$roundIndex]['display_show_pods'] = $show;
        if ($show) {
            $game['display_round'] = $roundNum;
        }
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, $show ? 'Display pods enabled.' : 'Display pods disabled.');
        $gm->update($gameId, $game);

        flash_set('success', $show ? 'Pod list shown on display.' : 'Pod list hidden on display.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function setDisplayResults(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);
        $show = (string)($_POST['show'] ?? '0') === '1';

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (empty($rounds[$roundIndex]['completed'])) {
            flash_set('error','Complete the round before showing results.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $rounds[$roundIndex]['display_show_results'] = $show;
        if ($show) {
            $game['display_round'] = $roundNum;
        }
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, $show ? 'Display results enabled.' : 'Display results disabled.');
        $gm->update($gameId, $game);

        flash_set('success', $show ? 'Results table shown on display.' : 'Results table hidden on display.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function setDisplayBackground(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);
        $background = trim((string)($_POST['background'] ?? ''));

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) {
            flash_set('error', 'Game not found.');
            redirect('admin/games');
        }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error', 'Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $rounds[$roundIndex]['display_background'] = $background;
        $game['rounds'] = $rounds;
        $gm->update($gameId, $game);

        flash_set('success', $background === '' ? 'Display background reset.' : 'Display background updated.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function uploadDisplayBackground(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');

        if (empty($_FILES['background_file']['tmp_name'])) {
            flash_set('error', 'No background file uploaded.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $tmp = (string)$_FILES['background_file']['tmp_name'];
        $orig = (string)($_FILES['background_file']['name'] ?? '');
        $size = (int)($_FILES['background_file']['size'] ?? 0);
        if ($size <= 0 || $size > 5 * 1024 * 1024) {
            flash_set('error', 'Background must be under 5MB.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $info = @getimagesize($tmp);
        if (!$info || empty($info['mime'])) {
            flash_set('error', 'Invalid image file.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $ext = '';
        switch ($info['mime']) {
            case 'image/png': $ext = 'png'; break;
            case 'image/jpeg': $ext = 'jpg'; break;
            case 'image/webp': $ext = 'webp'; break;
        }
        if ($ext === '') {
            flash_set('error', 'Only PNG, JPG, or WEBP images are allowed.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $dir = BASE_PATH . '/public/assets/display-bg';
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        $name = 'bg_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $dest = $dir . '/' . $name;
        if (!move_uploaded_file($tmp, $dest)) {
            flash_set('error', 'Failed to save background.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) {
            flash_set('error', 'Game not found.');
            redirect('admin/games');
        }
        $game['display_background'] = 'assets/display-bg/' . $name;
        $this->addGameAudit($game, 'Display background uploaded.');
        $gm->update($gameId, $game);

        flash_set('success', 'Display background uploaded.');
        redirect('admin/viewGame&id=' . urlencode($gameId));
    }

    public function uploadSponsorBanner(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');

        if (empty($_FILES['sponsor_file']['tmp_name'])) {
            flash_set('error', 'No sponsor banner uploaded.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $tmp = (string)$_FILES['sponsor_file']['tmp_name'];
        $size = (int)($_FILES['sponsor_file']['size'] ?? 0);
        if ($size <= 0 || $size > 5 * 1024 * 1024) {
            flash_set('error', 'Banner must be under 5MB.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $info = @getimagesize($tmp);
        if (!$info || empty($info['mime'])) {
            flash_set('error', 'Invalid image file.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $ext = '';
        switch ($info['mime']) {
            case 'image/png': $ext = 'png'; break;
            case 'image/jpeg': $ext = 'jpg'; break;
            case 'image/webp': $ext = 'webp'; break;
        }
        if ($ext === '') {
            flash_set('error', 'Only PNG, JPG, or WEBP images are allowed.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $dir = BASE_PATH . '/public/assets/sponsors';
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        $name = 'sponsor_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $dest = $dir . '/' . $name;
        if (!move_uploaded_file($tmp, $dest)) {
            flash_set('error', 'Failed to save sponsor banner.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) {
            flash_set('error', 'Game not found.');
            redirect('admin/games');
        }

        $game['sponsor_banner'] = 'assets/sponsors/' . $name;
        $this->addGameAudit($game, 'Sponsor banner uploaded.');
        $gm->update($gameId, $game);

        flash_set('success', 'Sponsor banner uploaded.');
        redirect('admin/viewGame&id=' . urlencode($gameId));
    }

    public function printRoundReportPdf(): void
    {
        Auth::requireAdmin();

        $gameId = (string)($_GET['id'] ?? '');
        $roundNum = (int)($_GET['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (empty($rounds[$roundIndex]['completed'])) {
            flash_set('error','Complete the round before printing.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $gameForStandings = $game;
        $gameForStandings['rounds'] = array_slice($rounds, 0, $roundNum);
        $standings = (new StandingsService())->compute($gameForStandings);
        $rows = $standings['ranked'] ?? [];

        $pdf = $this->newReportPdf('P', 'mm', 'Letter');
        $pdf->SetAutoPageBreak(false);
        $pdf->AddPage();
        $pdf->SetFont('Times', 'B', 16);
        $pdf->Cell(0, 8, (string)($game['name'] ?? 'Tournament'), 0, 1);
        $pdf->SetFont('Times', '', 11);
        $pdf->Cell(0, 7, 'Round ' . $roundNum . ' Standings · ' . date('Y-m-d H:i'), 0, 1);
        $pdf->Ln(2);

        $lineHeight = 5;
        $bottomMargin = 15;
        $ensureSpace = function(\FPDF $pdf, float $needed) use ($bottomMargin): void {
            if ($pdf->GetY() + $needed > ($pdf->GetPageHeight() - $bottomMargin)) {
                $pdf->AddPage();
            }
        };
        $fitText = function(\FPDF $pdf, float $w, string $text): string {
            $text = trim($text);
            if ($text === '') return '';
            if ($pdf->GetStringWidth($text) <= $w) return $text;
            $ellipsis = '...';
            $max = max(0.0, $w - $pdf->GetStringWidth($ellipsis));
            $out = '';
            $chars = preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [];
            foreach ($chars as $ch) {
                if ($pdf->GetStringWidth($out . $ch) > $max) break;
                $out .= $ch;
            }
            return rtrim($out) . $ellipsis;
        };
        $row = function(\FPDF $pdf, array $widths, array $cells, int $lineHeight) use ($fitText, $ensureSpace): void {
            $startX = $pdf->GetX();
            $x = $startX;
            $ensureSpace($pdf, $lineHeight);
            $y = $pdf->GetY();
            foreach ($cells as $i => $txt) {
                $w = $widths[$i];
                $pdf->Rect($x, $y, $w, $lineHeight);
                $pdf->SetXY($x, $y);
                $pdf->Cell($w, $lineHeight, $fitText($pdf, $w, (string)$txt), 0, 0);
                $x += $w;
                $pdf->SetXY($x, $y);
            }
            $pdf->SetXY($startX, $y + $lineHeight);
        };

        $pdf->SetFont('Times', 'B', 12);
        $pdf->Cell(0, 7, 'Ranking', 0, 1);
        $colWidths = [8, 50, 14, 16, 12, 14, 14, 14, 12, 12];
        $headers = ['#', 'Player', 'Score', 'Win Pts', 'Loss', 'Win %', 'Match %', 'Game %', 'OWP', 'OGP'];
        $pdf->SetFont('Times', 'B', 9);
        $row($pdf, $colWidths, $headers, $lineHeight);

        $pdf->SetFont('Times', '', 9);
        foreach ($rows as $i => $r) {
            $meta = $playersMeta[$r['email']] ?? ['name' => $r['email']];
            $row($pdf, $colWidths, [
                (string)($i + 1),
                (string)($meta['name'] ?? $r['email']),
                (string)((int)$r['total_score']),
                number_format((float)$r['total_wins_points'], 2),
                (string)((int)$r['total_loss']),
                number_format((float)$r['win_rate'], 3),
                number_format((float)$r['match_win_pct'], 3),
                number_format((float)$r['game_win_pct'], 3),
                number_format((float)$r['owp'], 3),
                number_format((float)$r['ogp'], 3),
            ], $lineHeight);
        }

        $audit = (array)($rounds[$roundIndex]['audit'] ?? []);
        $pdf->AddPage();
        $pdf->SetFont('Times', 'B', 12);
        $pdf->Cell(0, 7, 'Audit Logs', 0, 1);

        $auditWidths = [30, 35, 125];
        $pdf->SetFont('Times', 'B', 9);
        $row($pdf, $auditWidths, ['Time', 'User', 'Action'], $lineHeight);

        $pdf->SetFont('Times', '', 9);
        if (empty($audit)) {
            $row($pdf, [190], ['No audit entries.'], $lineHeight);
        } else {
            foreach ($audit as $entry) {
                $timeRaw = (string)($entry['time'] ?? '');
                $timeFmt = $timeRaw;
                if ($timeRaw !== '') {
                    $ts = strtotime($timeRaw);
                    if ($ts !== false) {
                        $timeFmt = date('y-m-d h:i A', $ts);
                    }
                }
                $row($pdf, $auditWidths, [
                    $timeFmt,
                    (string)($entry['user'] ?? ''),
                    (string)($entry['message'] ?? ''),
                ], $lineHeight);
            }
        }

        $fileName = 'round_' . $roundNum . '_standings.pdf';
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $fileName . '"');
        $pdf->Output('I', $fileName);
        exit;
    }

    public function deleteRound(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if ($roundIndex !== (count($rounds) - 1)) {
            flash_set('error','Only the latest round can be deleted.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (!empty($rounds[$roundIndex]['timer_start'])) {
            flash_set('error','Cannot delete a round after the timer has started.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }
        if (!empty($rounds[$roundIndex]['completed'])) {
            flash_set('error','Cannot delete a completed round.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        array_splice($rounds, $roundIndex, 1);
        $game['rounds'] = $rounds;
        $this->addGameAudit($game, 'Round ' . $roundNum . ' deleted.');
        $gm->update($gameId, $game);

        flash_set('success','Round deleted.');
        redirect('admin/viewGame&id=' . urlencode($gameId));
    }

    public function repodRound(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        if (($game['status'] ?? '') !== 'active') {
            flash_set('error', 'Cannot re-pair pods for an ended game.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (!empty($rounds[$roundIndex]['pairing_locked'])) {
            flash_set('error','Pairings are locked for this round.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        foreach ((array)($rounds[$roundIndex]['pods'] ?? []) as $pod) {
            if (!empty($pod['locked'])) {
                flash_set('error','Cannot re-pair: one or more pods are locked.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
        }

        $gameForStandings = $game;
        $roundsForStandings = (array)($gameForStandings['rounds'] ?? []);
        unset($roundsForStandings[$roundIndex]);
        $gameForStandings['rounds'] = array_values($roundsForStandings);

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $ss = new StandingsService();
        $standings = $ss->compute($gameForStandings);
        $rankingOrder = array_map(fn($r) => $r['email'], $standings['ranked']);
        $historyPairs = $ss->buildPairHistory($gameForStandings);

        $mode = (string)($_POST['pairing_mode'] ?? ($rounds[$roundIndex]['pairing_mode'] ?? 'ranking_top4'));
        $dropped = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
        $activePlayers = array_values(array_filter(
            array_map('strtolower', (array)($game['players'] ?? [])),
            fn($p) => !in_array($p, $dropped, true)
        ));
        if (empty($activePlayers)) {
            flash_set('error', 'Cannot create round: all players are marked as dropped.');
            redirect('admin/viewGame&id=' . urlencode($id));
        }

        $builder = new PodBuilder();
        $pods = $builder->buildPods(
            $activePlayers,
            $mode,
            $playersMeta,
            $rankingOrder,
            $historyPairs,
            (array)($standings['by_email'] ?? [])
        );

        $newPods = [];
        foreach ($pods as $idx => $pList) {
            $podId = 'r' . $roundNum . '_p' . ($idx + 1);
            $scores = [];
            foreach ($pList as $p) $scores[$p] = null;
            $newPods[] = [
                'id' => $podId,
                'players' => $pList,
                'scores' => $scores,
                'locked' => false,
                'saved' => false,
            ];
        }

        $rounds[$roundIndex]['pods'] = $newPods;
        $rounds[$roundIndex]['pairing_mode'] = $mode;
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, 'Pods re-paired (mode: ' . $mode . ').');
        $gm->update($gameId, $game);

        flash_set('success','Pods re-paired for this round.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function savePodScores(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);
        $podId = (string)($_POST['pod_id'] ?? '');

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;

        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        foreach ($rounds[$roundIndex]['pods'] as &$pod) {
            if ($pod['id'] !== $podId) continue;

            if (!empty($pod['locked'])) {
                flash_set('error','Pod is locked. Cannot edit.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }

            $scoresIn = (array)($_POST['scores'] ?? []);
            // Update scores (0..4)
            $podTotal = 0;
            $fourCount = 0;
            $threeCount = 0;
            foreach ($pod['players'] as $p) {
                $raw = $scoresIn[$p] ?? '';
                if ($raw === '') {
                    flash_set('error', 'All players must have a numeric score before saving.');
                    redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
                }

                $val = (int)$raw;
                if ($val < 0 || $val > 4) {
                    flash_set('error', 'Scores must be between 0 and 4.');
                    redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
                }
                $pod['scores'][$p] = $val;
                $podTotal += $val;
                if ($val === 4) {
                    $fourCount += 1;
                }
                if ($val === 3) {
                    $threeCount += 1;
                }
            }

            if ($fourCount > 1) {
                flash_set('error', 'A pod cannot have more than one score of 4.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
            if ($threeCount > 1) {
                flash_set('error', 'A pod cannot have more than one score of 3.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
            if ($podTotal > 9) {
                flash_set('error', 'Pod total score cannot exceed 9.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }

            $pod['saved'] = true;
        }
        unset($pod);

        $game['rounds'] = $rounds;
        $tableNum = (int)preg_replace('/^r\\d+_p/', '', $podId);
        $this->addRoundAudit($game, $roundIndex, 'Scores saved for Round ' . $roundNum . ' Pod Table ' . $tableNum . '.');
        $gm->update($gameId, $game);

        flash_set('success','Scores saved (not locked).');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function swapPodPlayers(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);
        $playerA = (string)($_POST['player_a'] ?? '');
        $playerB = (string)($_POST['player_b'] ?? '');

        if ($gameId === '' || $playerA === '' || $playerB === '') {
            flash_set('error', 'Select two players to swap.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }
        if ($playerA === $playerB) {
            flash_set('error', 'Select two different players to swap.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }
        if (!empty($rounds[$roundIndex]['pairing_locked'])) {
            flash_set('error','Pairings are locked for this round.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $pods = (array)($rounds[$roundIndex]['pods'] ?? []);
        $podAIndex = null;
        $podBIndex = null;

        foreach ($pods as $idx => $pod) {
            if (in_array($playerA, (array)($pod['players'] ?? []), true)) $podAIndex = $idx;
            if (in_array($playerB, (array)($pod['players'] ?? []), true)) $podBIndex = $idx;
        }

        if ($podAIndex === null || $podBIndex === null || $podAIndex === $podBIndex) {
            flash_set('error','Players must be in different pods to swap.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        if (!empty($pods[$podAIndex]['locked']) || !empty($pods[$podBIndex]['locked'])) {
            flash_set('error','Cannot swap: one or more pods are locked.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $pods[$podAIndex]['players'] = array_values(array_map(
            fn($p) => ($p === $playerA ? $playerB : $p),
            (array)($pods[$podAIndex]['players'] ?? [])
        ));
        $pods[$podBIndex]['players'] = array_values(array_map(
            fn($p) => ($p === $playerB ? $playerA : $p),
            (array)($pods[$podBIndex]['players'] ?? [])
        ));

        foreach ([$podAIndex, $podBIndex] as $idx) {
            $scores = [];
            foreach ((array)($pods[$idx]['players'] ?? []) as $p) {
                $scores[$p] = null;
            }
            $pods[$idx]['scores'] = $scores;
            $pods[$idx]['saved'] = false;
            $pods[$idx]['locked'] = false;
        }

        $rounds[$roundIndex]['pods'] = $pods;
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, 'Swapped players: ' . $playerA . ' <-> ' . $playerB . '.');
        $gm->update($gameId, $game);

        flash_set('success','Players swapped. Scores reset for those pods.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function autoSwapPods(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }
        if (!empty($rounds[$roundIndex]['pairing_locked'])) {
            flash_set('error','Pairings are locked for this round.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        foreach ((array)($rounds[$roundIndex]['pods'] ?? []) as $pod) {
            if (!empty($pod['locked'])) {
                flash_set('error','Cannot auto-swap: one or more pods are locked.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
        }

        $priorPairs = [];
        foreach ((array)($game['rounds'] ?? []) as $r) {
            if (($r['number'] ?? 0) >= $roundNum) continue;
            foreach ((array)($r['pods'] ?? []) as $p) {
                $plist = array_values((array)($p['players'] ?? []));
                for ($i = 0; $i < count($plist); $i++) {
                    for ($j = $i + 1; $j < count($plist); $j++) {
                        $a = $plist[$i];
                        $b = $plist[$j];
                        $key = ($a < $b) ? ($a . '|' . $b) : ($b . '|' . $a);
                        $priorPairs[$key] = true;
                    }
                }
            }
        }

        $pods = (array)($rounds[$roundIndex]['pods'] ?? []);
        $bestPods = $pods;
        $bestRepeat = $this->countRepeatPairs($pods, $priorPairs);

        for ($i = 0; $i < count($pods); $i++) {
            for ($j = $i + 1; $j < count($pods); $j++) {
                $pA = (array)($pods[$i]['players'] ?? []);
                $pB = (array)($pods[$j]['players'] ?? []);
                for ($a = 0; $a < count($pA); $a++) {
                    for ($b = 0; $b < count($pB); $b++) {
                        $candidate = $pods;
                        $candidate[$i]['players'][$a] = $pB[$b];
                        $candidate[$j]['players'][$b] = $pA[$a];
                        $repeat = $this->countRepeatPairs($candidate, $priorPairs);
                        if ($repeat < $bestRepeat) {
                            $bestRepeat = $repeat;
                            $bestPods = $candidate;
                        }
                    }
                }
            }
        }

        if ($bestRepeat >= $this->countRepeatPairs($pods, $priorPairs)) {
            flash_set('success','Auto-swap did not find a better pairing.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        foreach ($bestPods as &$pod) {
            $players = array_values((array)($pod['players'] ?? []));
            if (count($players) > 1) {
                shuffle($players);
            }
            $pod['players'] = $players;

            $scores = [];
            foreach ($players as $p) {
                $scores[$p] = null;
            }
            $pod['scores'] = $scores;
            $pod['saved'] = false;
            $pod['locked'] = false;
        }
        unset($pod);

        $rounds[$roundIndex]['pods'] = $bestPods;
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, 'Auto-swap applied to reduce repeats.');
        $gm->update($gameId, $game);

        flash_set('success','Auto-swap applied. Scores reset for all pods.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function lockPairings(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $rounds[$roundIndex]['pairing_locked'] = true;
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, 'Pairings locked.');
        $gm->update($gameId, $game);

        flash_set('success','Pairings locked for this round.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    private function countRepeatPairs(array $pods, array $priorPairs): int
    {
        $count = 0;
        foreach ($pods as $pod) {
            $plist = array_values((array)($pod['players'] ?? []));
            for ($i = 0; $i < count($plist); $i++) {
                for ($j = $i + 1; $j < count($plist); $j++) {
                    $a = $plist[$i];
                    $b = $plist[$j];
                    $key = ($a < $b) ? ($a . '|' . $b) : ($b . '|' . $a);
                    if (!empty($priorPairs[$key])) $count++;
                }
            }
        }
        return $count;
    }

    public function lockPod(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);
        $podId = (string)($_POST['pod_id'] ?? '');

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $roundIndex = $roundNum - 1;
        $rounds = (array)($game['rounds'] ?? []);
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        foreach ($rounds[$roundIndex]['pods'] as &$pod) {
            if ($pod['id'] !== $podId) continue;

            if (!empty($pod['locked'])) {
                flash_set('error','Already locked.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
            if (empty($pod['saved'])) {
                flash_set('error','Save scores before locking this pod.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }

            // Validate: all players have score 0..4, total <= 9, and only one 4/3
            $podTotal = 0;
            $fourCount = 0;
            $threeCount = 0;
            foreach ($pod['players'] as $p) {
                $s = $pod['scores'][$p] ?? null;
                if ($s === null || !is_int($s) || $s < 0 || $s > 4) {
                    flash_set('error','Cannot lock: all players must have a score (0 to 4).');
                    redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
                }
                $podTotal += $s;
                if ($s === 4) {
                    $fourCount += 1;
                }
                if ($s === 3) {
                    $threeCount += 1;
                }
            }
            if ($fourCount > 1) {
                flash_set('error','Cannot lock: a pod cannot have more than one score of 4.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
            if ($threeCount > 1) {
                flash_set('error','Cannot lock: a pod cannot have more than one score of 3.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
            if ($podTotal > 9) {
                flash_set('error','Cannot lock: pod total score cannot exceed 9.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }

            $pod['saved'] = true;
            $pod['locked'] = true;
        }
        unset($pod);

        $allLocked = true;
        foreach ($rounds[$roundIndex]['pods'] as $p) {
            if (empty($p['locked'])) { $allLocked = false; break; }
        }
        $timerStoppedByLock = false;
        if ($allLocked && !empty($rounds[$roundIndex]['timer_running'])) {
            $rounds[$roundIndex]['timer_end'] = date('c');
            $rounds[$roundIndex]['timer_running'] = false;
            $timerStoppedByLock = true;
        }

        $game['rounds'] = $rounds;
        if ($allLocked) {
            $this->addRoundAudit($game, $roundIndex, 'All pods locked.');
        }
        if ($timerStoppedByLock) {
            $this->addRoundAudit($game, $roundIndex, 'Round timer stopped (all pods locked).');
        }
        $tableNum = (int)preg_replace('/^r\\d+_p/', '', $podId);
        $this->addRoundAudit($game, $roundIndex, 'Pod locked: Round ' . $roundNum . ' Pod Table ' . $tableNum . '.');
        $gm->update($gameId, $game);

        flash_set('success','Pod locked permanently.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function endGame(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $id = (string)($_POST['game_id'] ?? '');
        $gm = new GameModel();
        $game = $gm->find($id);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        // Can only end if last round fully locked (or no rounds)
        $rounds = (array)($game['rounds'] ?? []);
        if (count($rounds) > 0) {
            $last = $rounds[count($rounds)-1];
            if (empty($last['completed'])) {
                flash_set('error','Cannot end game: latest round is not completed.');
                redirect('admin/viewGame&id=' . urlencode($id));
            }
            foreach ((array)($last['pods'] ?? []) as $pod) {
                if (empty($pod['locked'])) {
                    flash_set('error','Cannot end game: there are unlocked pods.');
                    redirect('admin/viewGame&id=' . urlencode($id));
                }
            }
        }

        $game['status'] = 'ended';
        $game['ended_at'] = date('c');
        $this->addGameAudit($game, 'Game finalized.');
        $gm->update($id, $game);

        flash_set('success','Game ended. Final standings posted.');
        redirect('admin/reports&id=' . urlencode($id));
    }

    public function reopenGame(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $id = (string)($_POST['game_id'] ?? '');
        $gm = new GameModel();
        $game = $gm->find($id);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $game['status'] = 'active';
        $game['ended_at'] = null;
        $this->addGameAudit($game, 'Game reopened.');
        $gm->update($id, $game);

        flash_set('success','Game reopened.');
        redirect('admin/viewGame&id=' . urlencode($id));
    }

    public function setRoundTimer(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);
        $minutes = (int)($_POST['minutes'] ?? 0);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (!empty($rounds[$roundIndex]['timer_locked'])) {
            flash_set('error','Round timer is already locked.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }
        if (empty($rounds[$roundIndex]['pairing_locked'])) {
            flash_set('error','Lock pairings before setting the round time.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }
        if ($minutes <= 0) {
            flash_set('error','Enter a valid time in minutes.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $rounds[$roundIndex]['time_limit_minutes'] = $minutes;
        $rounds[$roundIndex]['timer_locked'] = true;
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, 'Round time set to ' . $minutes . ' minutes.');
        $gm->update($gameId, $game);

        flash_set('success','Round timer set and locked.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function startRoundTimer(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (empty($rounds[$roundIndex]['timer_locked']) || empty($rounds[$roundIndex]['time_limit_minutes'])) {
            flash_set('error','Set and lock the round time before starting the timer.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }
        if (!empty($rounds[$roundIndex]['timer_running'])) {
            flash_set('error','Timer is already running.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }
        if (!empty($rounds[$roundIndex]['timer_start'])) {
            flash_set('error','Timer already started for this round.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $rounds[$roundIndex]['timer_start'] = date('c');
        $rounds[$roundIndex]['timer_running'] = true;
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, 'Round timer started.');
        $gm->update($gameId, $game);

        flash_set('success','Round timer started.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function stopRoundTimer(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $gameId = (string)($_POST['game_id'] ?? '');
        $roundNum = (int)($_POST['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        if (empty($rounds[$roundIndex]['timer_running'])) {
            flash_set('error','Timer is not running.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        foreach ((array)($rounds[$roundIndex]['pods'] ?? []) as $pod) {
            if (empty($pod['locked'])) {
                flash_set('error','All tables must be locked before stopping the timer.');
                redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
            }
        }

        $rounds[$roundIndex]['timer_end'] = date('c');
        $rounds[$roundIndex]['timer_running'] = false;
        $game['rounds'] = $rounds;
        $this->addRoundAudit($game, $roundIndex, 'Round timer stopped.');
        $gm->update($gameId, $game);

        flash_set('success','Round timer stopped.');
        redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
    }

    public function reports(): void
    {
        Auth::requireAdmin();

        $id = (string)($_GET['id'] ?? '');
        $game = (new GameModel())->find($id);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $ss = new StandingsService();
        $standings = $ss->compute($game);

        $this->render('admin/reports', [
            'csrf' => Csrf::token(),
            'user' => Auth::user(),
            'game' => $game,
            'playersMeta' => $playersMeta,
            'standings' => $standings,
        ]);
    }

    public function printFinalReportPdf(): void
    {
        Auth::requireAdmin();

        $gameId = (string)($_GET['id'] ?? '');
        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        if (($game['status'] ?? '') !== 'ended') {
            flash_set('error','Game must be finalized before printing.');
            redirect('admin/reports&id=' . urlencode($gameId));
        }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $ss = new StandingsService();
        $standings = $ss->compute($game);
        $rankedRows = $standings['ranked'] ?? [];
        $alphaRows = $standings['alphabetical'] ?? [];

        $pdf = $this->newReportPdf('P', 'mm', 'Letter');
        $pdf->SetAutoPageBreak(false);
        $pdf->AddPage();
        $pdf->SetFont('Times', 'B', 16);
        $pdf->Cell(0, 8, (string)($game['name'] ?? 'Tournament'), 0, 1);
        $pdf->SetFont('Times', '', 11);
        $pdf->Cell(0, 7, 'Final Results · ' . date('Y-m-d H:i'), 0, 1);
        $pdf->Ln(2);

        $lineHeight = 5;
        $bottomMargin = 15;
        $ensureSpace = function(\FPDF $pdf, float $needed) use ($bottomMargin): void {
            if ($pdf->GetY() + $needed > ($pdf->GetPageHeight() - $bottomMargin)) {
                $pdf->AddPage();
            }
        };
        $fitText = function(\FPDF $pdf, float $w, string $text): string {
            $text = trim($text);
            if ($text === '') return '';
            if ($pdf->GetStringWidth($text) <= $w) return $text;
            $ellipsis = '...';
            $max = max(0.0, $w - $pdf->GetStringWidth($ellipsis));
            $out = '';
            $chars = preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [];
            foreach ($chars as $ch) {
                if ($pdf->GetStringWidth($out . $ch) > $max) break;
                $out .= $ch;
            }
            return rtrim($out) . $ellipsis;
        };
        $row = function(\FPDF $pdf, array $widths, array $cells, int $lineHeight, bool $fill = false) use ($fitText, $ensureSpace): void {
            $startX = $pdf->GetX();
            $x = $startX;
            $y = $pdf->GetY();
            $h = $lineHeight;
            $ensureSpace($pdf, $h);
            $y = $pdf->GetY();

            foreach ($cells as $i => $txt) {
                $w = $widths[$i];
                $pdf->Rect($x, $y, $w, $h);
                $pdf->SetXY($x, $y);
                $pdf->Cell($w, $h, $fitText($pdf, $w, (string)$txt), 0, 0, 'L', $fill);
                $x += $w;
                $pdf->SetXY($x, $y);
            }
            $pdf->SetXY($startX, $y + $h);
        };

        // Ranking table
        $ensureSpace($pdf, 10);
        $pdf->SetFont('Times', 'B', 12);
        $pdf->Cell(0, 7, 'Ranking', 0, 1);
        $colWidths = [8, 50, 14, 16, 12, 14, 14, 14, 12, 12];
        $headers = ['#', 'Player', 'Score', 'Win Pts', 'Loss', 'Win %', 'Match %', 'Game %', 'OWP', 'OGP'];

        $ensureSpace($pdf, 7);
        $pdf->SetFont('Times', 'B', 9);
        $row($pdf, $colWidths, $headers, $lineHeight);

        $pdf->SetFont('Times', '', 9);
        foreach ($rankedRows as $i => $r) {
            $meta = $playersMeta[$r['email']] ?? ['name' => $r['email']];
            $isTop8 = $i < 8;
            if ($isTop8) {
                $pdf->SetFillColor(255, 243, 205);
            }
            $row($pdf, $colWidths, [
                (string)($i + 1),
                (string)($meta['name'] ?? $r['email']),
                (string)((int)$r['total_score']),
                number_format((float)$r['total_wins_points'], 2),
                (string)((int)$r['total_loss']),
                number_format((float)$r['win_rate'], 3),
                number_format((float)$r['match_win_pct'], 3),
                number_format((float)$r['game_win_pct'], 3),
                number_format((float)$r['owp'], 3),
                number_format((float)$r['ogp'], 3),
            ], $lineHeight, $isTop8);
            if ($isTop8) {
                $pdf->SetFillColor(255, 255, 255);
            }
        }

        $pdf->AddPage();

        // Alphabetical standing table
        $ensureSpace($pdf, 10);
        $pdf->SetFont('Times', 'B', 12);
        $pdf->Cell(0, 7, 'Alphabetical Standing', 0, 1);
        $colWidthsAlpha = [70, 14, 16, 12, 16, 16];
        $headersAlpha = ['Player', 'Score', 'Win Pts', 'Loss', 'OWP', 'OGP'];

        $ensureSpace($pdf, 7);
        $pdf->SetFont('Times', 'B', 9);
        $row($pdf, $colWidthsAlpha, $headersAlpha, $lineHeight);

        $pdf->SetFont('Times', '', 9);
        foreach ($alphaRows as $r) {
            $meta = $playersMeta[$r['email']] ?? ['name' => $r['email']];
            $row($pdf, $colWidthsAlpha, [
                (string)($meta['name'] ?? $r['email']),
                (string)((int)$r['total_score']),
                number_format((float)$r['total_wins_points'], 2),
                (string)((int)$r['total_loss']),
                number_format((float)$r['owp'], 3),
                number_format((float)$r['ogp'], 3),
            ], $lineHeight);
        }

        $pdf->AddPage();

        // Pod records and opponents
        $pdf->SetFont('Times', 'B', 12);
        $pdf->Cell(0, 7, 'Pod Records & Opponents', 0, 1);
        $pdf->Ln(1);

        $rounds = (array)($game['rounds'] ?? []);
        $pdf->SetFont('Times', '', 10);
        foreach ($rounds as $round) {
            $ensureSpace($pdf, 8);
            $pdf->SetFont('Times', 'B', 11);
            $pdf->Cell(0, 6, 'Round ' . (int)($round['number'] ?? 0) . ' · ' . (string)($round['pairing_mode'] ?? ''), 0, 1);
            $pdf->SetFont('Times', '', 9);

            foreach ((array)($round['pods'] ?? []) as $podIndex => $pod) {
                $ensureSpace($pdf, 12);
                $pdf->SetFont('Times', 'B', 9);
                $pdf->Cell(0, 5, 'Table ' . ($podIndex + 1), 0, 1);
                $pdf->SetFont('Times', '', 9);

                $headersPod = ['Player', 'Score', 'Opponents'];
                $colWidthsPod = [55, 12, 120];
                $row($pdf, $colWidthsPod, $headersPod, $lineHeight);

                $players = (array)($pod['players'] ?? []);
                foreach ($players as $email) {
                    $meta = $playersMeta[$email] ?? ['name' => $email];
                    $score = $pod['scores'][$email] ?? null;
                    $opps = array_values(array_filter($players, fn($x) => $x !== $email));
                    $oppNames = array_map(fn($o) => (string)($playersMeta[$o]['name'] ?? $o), $opps);
                    $maxOpps = 6;
                    $shown = array_slice($oppNames, 0, $maxOpps);
                    $extra = count($oppNames) - count($shown);
                    $oppText = implode(', ', $shown);
                    if ($extra > 0) {
                        $oppText .= ' +' . $extra;
                    }

                    $row($pdf, $colWidthsPod, [
                        (string)($meta['name'] ?? $email),
                        ($score === null) ? 'N/A' : (string)((int)$score),
                        $oppText,
                    ], $lineHeight);
                }
                $pdf->Ln(2);
            }
            $pdf->Ln(2);
        }

        $pdf->AddPage();
        $pdf->SetFont('Times', 'B', 12);
        $pdf->Cell(0, 7, 'Game Stats', 0, 1);
        $pdf->Ln(1);

        $podsCount = 0;
        $scoredPods = 0;
        $sumPodScores = 0;
        $sumScores = 0;
        $scoreCount = 0;
        $pairHistory = [];
        $repeatByPlayer = [];
        $oppCounts = [];

        foreach ($rounds as $round) {
            foreach ((array)($round['pods'] ?? []) as $pod) {
                $podsCount++;
                $players = array_values((array)($pod['players'] ?? []));
                $scores = (array)($pod['scores'] ?? []);
                $podSum = 0;
                $hasScore = false;

                foreach ($players as $p) {
                    $s = $scores[$p] ?? null;
                    if ($s !== null) {
                        $hasScore = true;
                        $sumScores += (int)$s;
                        $scoreCount++;
                        $podSum += (int)$s;
                    }
                }

                if ($hasScore) {
                    $sumPodScores += $podSum;
                    $scoredPods++;
                }

                for ($i = 0; $i < count($players); $i++) {
                    for ($j = $i + 1; $j < count($players); $j++) {
                        $a = $players[$i];
                        $b = $players[$j];
                        $key = ($a < $b) ? ($a . '|' . $b) : ($b . '|' . $a);
                        if (!empty($pairHistory[$key])) {
                            $repeatByPlayer[$a] = (int)($repeatByPlayer[$a] ?? 0) + 1;
                            $repeatByPlayer[$b] = (int)($repeatByPlayer[$b] ?? 0) + 1;
                        }
                        $pairHistory[$key] = (int)($pairHistory[$key] ?? 0) + 1;
                    }
                }

                foreach ($players as $p) {
                    foreach ($players as $opp) {
                        if ($opp === $p) continue;
                        $oppCounts[$p][$opp] = (int)($oppCounts[$p][$opp] ?? 0) + 1;
                    }
                }
            }
        }

        $avgScorePerEntry = $scoreCount > 0 ? ($sumScores / $scoreCount) : 0;
        $avgPodTotal = $scoredPods > 0 ? ($sumPodScores / $scoredPods) : 0;

        $repeatRows = [];
        foreach ($repeatByPlayer as $email => $count) {
            $repeatRows[] = ['email' => $email, 'count' => $count];
        }
        usort($repeatRows, fn($a, $b) => $b['count'] <=> $a['count']);

        $winRates = $standings['ranked'] ?? [];
        $bucketCounts = [
            '0.00-0.25' => 0,
            '0.25-0.50' => 0,
            '0.50-0.75' => 0,
            '0.75-1.00' => 0,
        ];
        foreach ($winRates as $r) {
            $w = (float)($r['win_rate'] ?? 0);
            if ($w < 0.25) $bucketCounts['0.00-0.25']++;
            elseif ($w < 0.50) $bucketCounts['0.25-0.50']++;
            elseif ($w < 0.75) $bucketCounts['0.50-0.75']++;
            else $bucketCounts['0.75-1.00']++;
        }

        $topOpponents = [];
        foreach ($oppCounts as $email => $counts) {
            arsort($counts);
            $opp = key($counts);
            $cnt = $counts[$opp] ?? 0;
            if ($opp) {
                $topOpponents[] = ['email' => $email, 'opp' => $opp, 'count' => $cnt];
            }
        }
        usort($topOpponents, fn($a, $b) => $b['count'] <=> $a['count']);

        $pdf->SetFont('Times', '', 10);
        $pdf->Cell(0, 6, 'Totals', 0, 1);
        $pdf->SetFont('Times', '', 9);
        $pdf->Cell(0, 5, 'Games: 1', 0, 1);
        $pdf->Cell(0, 5, 'Rounds: ' . count($rounds), 0, 1);
        $pdf->Cell(0, 5, 'Pods: ' . (int)$podsCount, 0, 1);
        $pdf->Cell(0, 5, 'Players: ' . count((array)($game['players'] ?? [])), 0, 1);
        $pdf->Ln(2);

        $pdf->SetFont('Times', '', 10);
        $pdf->Cell(0, 6, 'Averages', 0, 1);
        $pdf->SetFont('Times', '', 9);
        $pdf->Cell(0, 5, 'Avg score per player entry: ' . number_format($avgScorePerEntry, 2), 0, 1);
        $pdf->Cell(0, 5, 'Avg total score per pod: ' . number_format($avgPodTotal, 2), 0, 1);
        $pdf->Ln(2);

        $pdf->SetFont('Times', '', 10);
        $pdf->Cell(0, 6, 'Win Rate Distribution', 0, 1);
        $pdf->SetFont('Times', '', 9);
        foreach ($bucketCounts as $label => $count) {
            $pdf->Cell(0, 5, $label . ': ' . $count, 0, 1);
        }
        $pdf->Ln(2);

        $pdf->SetFont('Times', '', 10);
        $pdf->Cell(0, 6, 'Repeat Pair Count per Player (Top 10)', 0, 1);
        $pdf->SetFont('Times', '', 9);
        $row($pdf, [80, 30], ['Player', 'Repeats'], $lineHeight);
        foreach (array_slice($repeatRows, 0, 10) as $rowData) {
            $meta = $playersMeta[$rowData['email']] ?? ['name' => $rowData['email']];
            $row($pdf, [80, 30], [(string)($meta['name'] ?? $rowData['email']), (string)($rowData['count'])], $lineHeight);
        }
        if (empty($repeatRows)) {
            $row($pdf, [110], ['No repeats yet.'], $lineHeight);
        }
        $pdf->Ln(2);

        $pdf->SetFont('Times', '', 10);
        $pdf->Cell(0, 6, 'Top Opponent Frequency (Top 10)', 0, 1);
        $pdf->SetFont('Times', '', 9);
        $row($pdf, [60, 60, 20], ['Player', 'Opponent', 'Times'], $lineHeight);
        foreach (array_slice($topOpponents, 0, 10) as $rowData) {
            $meta = $playersMeta[$rowData['email']] ?? ['name' => $rowData['email']];
            $oppMeta = $playersMeta[$rowData['opp']] ?? ['name' => $rowData['opp']];
            $row($pdf, [60, 60, 20], [(string)($meta['name'] ?? $rowData['email']), (string)($oppMeta['name'] ?? $rowData['opp']), (string)($rowData['count'])], $lineHeight);
        }
        if (empty($topOpponents)) {
            $row($pdf, [140], ['No opponent data yet.'], $lineHeight);
        }

        $gameAudit = (array)($game['audit'] ?? []);
        $roundAuditRows = [];
        foreach ($rounds as $r) {
            $roundAuditRows[] = [
                'number' => (int)($r['number'] ?? 0),
                'rows' => (array)($r['audit'] ?? []),
            ];
        }

        $hasAudit = !empty($gameAudit);
        if (!$hasAudit) {
            foreach ($roundAuditRows as $r) {
                if (!empty($r['rows'])) {
                    $hasAudit = true;
                    break;
                }
            }
        }

        if ($hasAudit) {
            $formatAuditTime = function (string $ts): string {
                if ($ts === '') return '';
                $parsed = strtotime($ts);
                if ($parsed === false) return $ts;
                return date('y-m-d h:i A', $parsed);
            };
            $sortAudit = function (array $rows): array {
                usort($rows, function ($a, $b) {
                    $ta = strtotime((string)($a['time'] ?? '')) ?: 0;
                    $tb = strtotime((string)($b['time'] ?? '')) ?: 0;
                    return $tb <=> $ta;
                });
                return $rows;
            };

            $pdf->AddPage();
            $pdf->SetFont('Times', 'B', 12);
            $pdf->Cell(0, 7, 'Audit Logs', 0, 1);
            $pdf->Ln(1);

            if (!empty($gameAudit)) {
                $pdf->SetFont('Times', 'B', 11);
                $pdf->Cell(0, 6, 'Game Actions', 0, 1);

                $pdf->SetFont('Times', 'B', 9);
                $auditWidths = [35, 35, 115];
                $headersAudit = ['Time', 'User', 'Action'];
                $row($pdf, $auditWidths, $headersAudit, $lineHeight);

                $pdf->SetFont('Times', '', 9);
                foreach ($sortAudit($gameAudit) as $entry) {
                    $row($pdf, $auditWidths, [
                        $formatAuditTime((string)($entry['time'] ?? '')),
                        (string)($entry['user'] ?? ''),
                        (string)($entry['message'] ?? ''),
                    ], $lineHeight);
                }
                $pdf->Ln(2);
            }

            foreach ($roundAuditRows as $r) {
                $entries = $sortAudit((array)($r['rows'] ?? []));
                if (empty($entries)) {
                    continue;
                }
                $pdf->SetFont('Times', 'B', 11);
                $pdf->Cell(0, 6, 'Round ' . (int)$r['number'], 0, 1);

                $pdf->SetFont('Times', 'B', 9);
                $auditWidths = [35, 35, 115];
                $headersAudit = ['Time', 'User', 'Action'];
                $row($pdf, $auditWidths, $headersAudit, $lineHeight);

                $pdf->SetFont('Times', '', 9);
                foreach ($entries as $entry) {
                    $row($pdf, $auditWidths, [
                        $formatAuditTime((string)($entry['time'] ?? '')),
                        (string)($entry['user'] ?? ''),
                        (string)($entry['message'] ?? ''),
                    ], $lineHeight);
                }
                $pdf->Ln(2);
            }
        }

        $fileName = 'final_results.pdf';
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $fileName . '"');
        $pdf->Output('I', $fileName);
        exit;
    }

    public function printPairingsPdf(): void
    {
        Auth::requireAdmin();

        $gameId = (string)($_GET['id'] ?? '');
        $roundNum = (int)($_GET['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $round = $rounds[$roundIndex];
        if (empty($round['pairing_locked'])) {
            flash_set('error','Pairings must be locked before printing.');
            redirect('admin/viewRound&id=' . urlencode($gameId) . '&round=' . $roundNum);
        }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $pdf = $this->newReportPdf();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(0, 8, (string)($game['name'] ?? 'Tournament'), 0, 1);
        $pdf->SetFont('Arial', '', 11);
        $pdf->Cell(0, 7, 'Round ' . $roundNum . ' · ' . date('Y-m-d H:i'), 0, 1);
        $pdf->Ln(2);

        $pdf->SetFont('Arial', 'B', 10);
        $colWidths = [25, 41, 41, 41, 41];
        $headers = ['Pod', 'Player 1', 'Player 2', 'Player 3', 'Player 4'];
        foreach ($headers as $i => $h) {
            $pdf->Cell($colWidths[$i], 7, $h, 1, 0);
        }
        $pdf->Ln();

        $pdf->SetFont('Arial', '', 10);
        $pods = (array)($round['pods'] ?? []);
        foreach ($pods as $idx => $pod) {
            $players = array_values((array)($pod['players'] ?? []));
            $names = [];
            for ($i = 0; $i < 4; $i++) {
                if (isset($players[$i])) {
                    $meta = $playersMeta[$players[$i]] ?? ['name' => $players[$i]];
                    $names[] = (string)($meta['name'] ?? $players[$i]);
                } else {
                    $names[] = '';
                }
            }

            $pdf->Cell($colWidths[0], 7, 'Table ' . ($idx + 1), 1, 0);
            $pdf->Cell($colWidths[1], 7, $names[0], 1, 0);
            $pdf->Cell($colWidths[2], 7, $names[1], 1, 0);
            $pdf->Cell($colWidths[3], 7, $names[2], 1, 0);
            $pdf->Cell($colWidths[4], 7, $names[3], 1, 0);
            $pdf->Ln();
        }

        $audit = (array)($round['audit'] ?? []);
        if (!empty($audit)) {
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 7, 'Audit Logs', 0, 1);

            $pdf->SetFont('Arial', 'B', 9);
            $auditWidths = [40, 40, 110];
            $headersAudit = ['Time', 'User', 'Action'];
            foreach ($headersAudit as $i => $h) {
                $pdf->Cell($auditWidths[$i], 7, $h, 1, 0);
            }
            $pdf->Ln();

            $pdf->SetFont('Arial', '', 9);
            foreach ($audit as $entry) {
                $timeRaw = (string)($entry['time'] ?? '');
                $timeFmt = $timeRaw;
                if ($timeRaw !== '') {
                    $ts = strtotime($timeRaw);
                    if ($ts !== false) {
                        $timeFmt = date('y-m-d h:i A', $ts);
                    }
                }
                $pdf->Cell($auditWidths[0], 6, $timeFmt, 1, 0);
                $pdf->Cell($auditWidths[1], 6, (string)($entry['user'] ?? ''), 1, 0);
                $pdf->Cell($auditWidths[2], 6, (string)($entry['message'] ?? ''), 1, 0);
                $pdf->Ln();
            }
        }

        $fileName = 'pairings_round_' . $roundNum . '.pdf';
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $fileName . '"');
        $pdf->Output('I', $fileName);
        exit;
    }

    public function printRoundAuditPdf(): void
    {
        Auth::requireAdmin();

        $gameId = (string)($_GET['id'] ?? '');
        $roundNum = (int)($_GET['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) { flash_set('error','Game not found.'); redirect('admin/games'); }

        $rounds = (array)($game['rounds'] ?? []);
        $roundIndex = $roundNum - 1;
        if (!isset($rounds[$roundIndex])) {
            flash_set('error','Round not found.');
            redirect('admin/viewGame&id=' . urlencode($gameId));
        }

        $round = $rounds[$roundIndex];
        $audit = (array)($round['audit'] ?? []);

        $pdf = $this->newReportPdf('P', 'mm', 'Letter');
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(0, 8, (string)($game['name'] ?? 'Tournament'), 0, 1);
        $pdf->SetFont('Arial', '', 11);
        $pdf->Cell(0, 6, 'Round ' . $roundNum . ' Audit Logs', 0, 1);
        $pdf->Cell(0, 6, date('Y-m-d h:i A'), 0, 1);
        $pdf->Ln(2);

        $pdf->SetFont('Arial', 'B', 9);
        $colWidths = [35, 45, 110];
        $headers = ['Time', 'User', 'Action'];
        foreach ($headers as $i => $h) {
            $pdf->Cell($colWidths[$i], 7, $h, 1, 0);
        }
        $pdf->Ln();

        $pdf->SetFont('Arial', '', 9);
        foreach ($audit as $entry) {
            $timeRaw = (string)($entry['time'] ?? '');
            $timeFmt = $timeRaw;
            if ($timeRaw !== '') {
                $ts = strtotime($timeRaw);
                if ($ts !== false) {
                    $timeFmt = date('y-m-d h:i A', $ts);
                }
            }
            $user = (string)($entry['user'] ?? '');
            $action = (string)($entry['message'] ?? '');
            if (strlen($action) > 120) {
                $action = substr($action, 0, 117) . '...';
            }

            $pdf->Cell($colWidths[0], 6, $timeFmt, 1, 0);
            $pdf->Cell($colWidths[1], 6, $user, 1, 0);
            $pdf->Cell($colWidths[2], 6, $action, 1, 0);
            $pdf->Ln();
        }

        if (empty($audit)) {
            $pdf->Cell(array_sum($colWidths), 6, 'No audit entries.', 1, 0, 'C');
        }

        $fileName = 'round_' . $roundNum . '_audit_logs.pdf';
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $fileName . '"');
        $pdf->Output('I', $fileName);
        exit;
    }

    private function addRoundAudit(array &$game, int $roundIndex, string $message): void
    {
        $user = Auth::user();
        $who = (string)($user['name'] ?? $user['email'] ?? 'admin');

        if (!isset($game['rounds'][$roundIndex]['audit']) || !is_array($game['rounds'][$roundIndex]['audit'])) {
            $game['rounds'][$roundIndex]['audit'] = [];
        }

        $game['rounds'][$roundIndex]['audit'][] = [
            'time' => date('c'),
            'user' => $who,
            'message' => $message,
        ];
    }

    private function addGameAudit(array &$game, string $message): void
    {
        $user = Auth::user();
        $who = (string)($user['name'] ?? $user['email'] ?? 'admin');

        if (!isset($game['audit']) || !is_array($game['audit'])) {
            $game['audit'] = [];
        }

        $game['audit'][] = [
            'time' => date('c'),
            'user' => $who,
            'message' => $message,
        ];
    }

    private function newReportPdf(string $orientation = 'P', string $unit = 'mm', $size = 'Letter'): \FPDF
    {
        if (!defined('FPDF_FONTPATH')) {
            define('FPDF_FONTPATH', APP_PATH . '/ThirdParty/font/');
        }
        require_once APP_PATH . '/ThirdParty/fpdf.php';

        $logoPath = BASE_PATH . '/public/assets/manapodlogo.png';
        if (!is_file($logoPath)) {
            $logoPath = '';
        }
        $watermarkPath = BASE_PATH . '/public/assets/manapodlogo-watermark.png';
        if (!is_file($watermarkPath)) {
            $watermarkPath = '';
        }

        $generatedBy = 'GENERATED BY: MANA POD Tournament Manager, PH';
        $createdBy = 'Created by Bob Mathew Sunga';

        $pdf = new class($orientation, $unit, $size, $logoPath, $watermarkPath, $generatedBy, $createdBy) extends \FPDF {
            private string $logoPath;
            private string $watermarkPath;
            private string $generatedBy;
            private string $createdBy;

            public function __construct($orientation, $unit, $size, string $logoPath, string $watermarkPath, string $generatedBy, string $createdBy)
            {
                parent::__construct($orientation, $unit, $size);
                $this->logoPath = $logoPath;
                $this->watermarkPath = $watermarkPath;
                $this->generatedBy = $generatedBy;
                $this->createdBy = $createdBy;
            }

            public function Header(): void
            {
                if ($this->watermarkPath !== '') {
                    $wmSize = min($this->GetPageWidth(), $this->GetPageHeight()) * 0.6;
                    $x = ($this->GetPageWidth() - $wmSize) / 2;
                    $y = ($this->GetPageHeight() - $wmSize) / 2;
                    $this->Image($this->watermarkPath, $x, $y, $wmSize);
                }
                $this->SetFont('Arial', '', 9);
                if ($this->logoPath !== '') {
                    $this->Image($this->logoPath, $this->lMargin, 8, 8);
                    $this->SetXY($this->lMargin + 12, 8);
                } else {
                    $this->SetXY($this->lMargin, 8);
                }
                $this->Cell(0, 6, $this->generatedBy, 0, 1, 'L');
                $this->Ln(6);
            }

            public function Footer(): void
            {
                $this->SetY(-12);
                $this->SetFont('Arial', '', 8);
                $this->Cell(0, 5, 'Page ' . $this->PageNo() . ' of {nb}', 0, 0, 'L');
                $this->SetX(0);
                $this->Cell($this->GetPageWidth(), 5, date('Y-m-d H:i'), 0, 0, 'C');
                $this->SetX(-$this->rMargin);
                $this->Cell(0, 5, $this->createdBy, 0, 0, 'R');
            }

        };

        $pdf->AliasNbPages();
        return $pdf;
    }

    public function users(): void
{
    Auth::requireAdmin();

    $um = new UserModel();
    $users = $um->all();

    // Sort: admins first, then players; then email
    uasort($users, function($a, $b) {
        $ra = (string)($a['role'] ?? '');
        $rb = (string)($b['role'] ?? '');
        if ($ra !== $rb) {
            return ($ra === 'admin') ? -1 : 1;
        }
        return strcmp((string)($a['email'] ?? ''), (string)($b['email'] ?? ''));
    });

    $pm = new PlayerModel();
    $players = $pm->all();

    // Players that exist but no user account yet
    $playersWithoutAccounts = [];
    foreach ($players as $email => $p) {
        if (!isset($users[$email])) {
            $playersWithoutAccounts[$email] = $p;
        }
    }

    $this->render('admin/users', [
        'csrf' => Csrf::token(),
        'user' => Auth::user(),
        'users' => $users,
        'playersWithoutAccounts' => $playersWithoutAccounts,
        'userAudit' => $this->getUserAudit(),
    ]);
}

public function createUser(): void
{
    Auth::requireAdmin();
    Csrf::check();

    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $name  = trim((string)($_POST['name'] ?? ''));
    $role  = (string)($_POST['role'] ?? 'player');
    $pass  = (string)($_POST['password'] ?? '');
    $addToPlayers = !empty($_POST['add_to_players']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash_set('error', 'Invalid email.');
        redirect('admin/users');
    }

    if (!in_array($role, ['admin', 'player'], true)) {
        flash_set('error', 'Invalid role.');
        redirect('admin/users');
    }

    if (strlen($pass) < 6) {
        flash_set('error', 'Password must be at least 6 characters.');
        redirect('admin/users');
    }

    $um = new UserModel();
    if ($um->find($email)) {
        flash_set('error', 'User already exists.');
        redirect('admin/users');
    }

    if ($name === '') $name = $email;

    $um->upsert([
        'email' => $email,
        'name' => $name,
        'role' => $role,
        'password_hash' => password_hash($pass, PASSWORD_DEFAULT),
        'disabled' => false,
        'created_at' => date('c'),
    ]);
    $this->addUserAudit('User created: ' . $email . '.');

    // If player role, ensure exists in players.json
    if ($role === 'player' || $addToPlayers) {
        (new PlayerModel())->upsert($email, $name);
    }

    flash_set('success', 'User created.');
    redirect('admin/users');
}

public function bulkCreatePlayerUsers(): void
{
    Auth::requireAdmin();
    Csrf::check();

    $password = (string)($_POST['password'] ?? '');
    $selected = (array)($_POST['players'] ?? []);
    $selected = array_values(array_unique(array_map('strtolower', $selected)));

    if (strlen($password) < 6) {
        flash_set('error', 'Password must be at least 6 characters.');
        redirect('admin/users');
    }
    if (empty($selected)) {
        flash_set('error', 'Please select at least one player.');
        redirect('admin/users');
    }

    $pm = new PlayerModel();
    $players = $pm->all();
    $um = new UserModel();

    $created = 0;
    $skipped = 0;

    foreach ($selected as $email) {
        if (!isset($players[$email])) {
            $skipped++;
            continue;
        }
        if ($um->find($email)) {
            $skipped++;
            continue;
        }
        $name = (string)($players[$email]['name'] ?? $email);
        $um->upsert([
            'email' => $email,
            'name' => $name,
            'role' => 'player',
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'disabled' => false,
            'created_at' => date('c'),
        ]);
        $created++;
        $this->addUserAudit('Player account created (bulk): ' . $email . '.');
    }

    flash_set('success', "Created {$created} accounts. Skipped {$skipped}.");
    redirect('admin/users');
}

public function deletePlayerRecord(): void
{
    Auth::requireAdmin();
    Csrf::check();

    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash_set('error', 'Invalid player email.');
        redirect('admin/users');
    }

    $pm = new PlayerModel();
    $deleted = $pm->delete($email);

    $um = new UserModel();
    $user = $um->find($email);
    if ($user) {
        if (($user['role'] ?? '') === 'admin') {
            flash_set('error', 'Cannot delete an admin user.');
            redirect('admin/users');
        }
        $um->delete($email);
    }

    $gm = new GameModel();
    $games = $gm->all();
    foreach ($games as $id => $game) {
        $players = array_values(array_filter((array)($game['players'] ?? []), fn($p) => strtolower((string)$p) !== $email));
        $game['players'] = $players;
        if (!empty($game['dropped_players'])) {
            $game['dropped_players'] = array_values(array_filter((array)$game['dropped_players'], fn($p) => strtolower((string)$p) !== $email));
        }

        $rounds = (array)($game['rounds'] ?? []);
        foreach ($rounds as $rIndex => $round) {
            $pods = (array)($round['pods'] ?? []);
            foreach ($pods as $pIndex => $pod) {
                $podPlayers = array_values(array_filter((array)($pod['players'] ?? []), fn($p) => strtolower((string)$p) !== $email));
                $pod['players'] = $podPlayers;
                if (!empty($pod['scores'])) {
                    foreach ((array)$pod['scores'] as $key => $_) {
                        if (strtolower((string)$key) === $email) {
                            unset($pod['scores'][$key]);
                        }
                    }
                }
                $pods[$pIndex] = $pod;
            }
            $round['pods'] = $pods;
            $rounds[$rIndex] = $round;
        }
        $game['rounds'] = $rounds;
        $games[$id] = $game;
    }
    $gm->saveAll($games);

    if ($deleted || $user) {
        $this->addUserAudit('Player record deleted: ' . $email . '.');
        flash_set('success', 'Player record deleted.');
    } else {
        flash_set('error', 'Player not found.');
    }
    redirect('admin/users');
}

public function bulkUserActions(): void
{
    Auth::requireAdmin();
    Csrf::check();

    $action = (string)($_POST['action'] ?? '');
    $users = (array)($_POST['users'] ?? []);
    $users = array_values(array_unique(array_map('strtolower', $users)));
    $password = (string)($_POST['password'] ?? '');

    if (empty($users)) {
        flash_set('error', 'Please select at least one user.');
        redirect('admin/users');
    }

    $um = new UserModel();
    $pm = new PlayerModel();

    $currentUser = Auth::user();
    $currentEmail = strtolower((string)($currentUser['email'] ?? ''));

    $deleted = 0;
    $disabled = 0;
    $enabled = 0;
    $reset = 0;
    $skipped = 0;

    if ($action === 'reset') {
        if (strlen($password) < 6) {
            flash_set('error', 'Password must be at least 6 characters.');
            redirect('admin/users');
        }
    }

    foreach ($users as $email) {
        $u = $um->find($email);
        if (!$u) {
            $skipped++;
            continue;
        }

        if ($action === 'delete') {
            if (($u['role'] ?? '') === 'admin') {
                $skipped++;
                continue;
            }
            $um->delete($email);
            $pm->delete($email);
            $deleted++;
            $this->addUserAudit('User deleted (bulk): ' . $email . '.');
            continue;
        }

        if ($action === 'disable') {
            if (($u['role'] ?? '') === 'admin') {
                if ($um->countAdmins() <= 1 && empty($u['disabled'])) {
                    $skipped++;
                    continue;
                }
            }
            $u['disabled'] = true;
            $um->upsert($u);
            $disabled++;
            $this->addUserAudit('User disabled (bulk): ' . $email . '.');
            continue;
        }

        if ($action === 'enable') {
            $u['disabled'] = false;
            $um->upsert($u);
            $enabled++;
            $this->addUserAudit('User enabled (bulk): ' . $email . '.');
            continue;
        }

        if ($action === 'reset') {
            $u['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
            $um->upsert($u);
            $reset++;
            $this->addUserAudit('User password reset (bulk): ' . $email . '.');
            continue;
        }

        $skipped++;
    }

    $msgParts = [];
    if ($deleted) $msgParts[] = "Deleted {$deleted}.";
    if ($disabled) $msgParts[] = "Disabled {$disabled}.";
    if ($enabled) $msgParts[] = "Enabled {$enabled}.";
    if ($reset) $msgParts[] = "Reset {$reset}.";
    if ($skipped) $msgParts[] = "Skipped {$skipped}.";
    $msg = empty($msgParts) ? 'No changes made.' : implode(' ', $msgParts);
    flash_set('success', $msg);
    redirect('admin/users');
}

public function downloadUserAuditCsv(): void
{
    Auth::requireAdmin();

    $rows = $this->getUserAudit();
    usort($rows, function ($a, $b) {
        $ta = strtotime((string)($a['time'] ?? '')) ?: 0;
        $tb = strtotime((string)($b['time'] ?? '')) ?: 0;
        return $tb <=> $ta;
    });

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="user_audit_logs.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Time', 'Admin', 'Action']);
    foreach ($rows as $row) {
        fputcsv($out, [
            (string)($row['time'] ?? ''),
            (string)($row['user'] ?? ''),
            (string)($row['message'] ?? ''),
        ]);
    }
    fclose($out);
    exit;
}

public function printUserAuditPdf(): void
{
    Auth::requireAdmin();

    $rows = $this->getUserAudit();
    usort($rows, function ($a, $b) {
        $ta = strtotime((string)($a['time'] ?? '')) ?: 0;
        $tb = strtotime((string)($b['time'] ?? '')) ?: 0;
        return $tb <=> $ta;
    });

    $pdf = $this->newReportPdf('P', 'mm', 'Letter');
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 8, 'User Management Audit Logs', 0, 1);
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 6, date('Y-m-d h:i A'), 0, 1);
    $pdf->Ln(2);

    $pdf->SetFont('Arial', 'B', 9);
    $colWidths = [35, 45, 110];
    $headers = ['Time', 'Admin', 'Action'];
    foreach ($headers as $i => $h) {
        $pdf->Cell($colWidths[$i], 7, $h, 1, 0);
    }
    $pdf->Ln();

    $pdf->SetFont('Arial', '', 9);
    if (empty($rows)) {
        $pdf->Cell(array_sum($colWidths), 6, 'No audit entries.', 1, 0, 'C');
    } else {
        foreach ($rows as $row) {
            $timeRaw = (string)($row['time'] ?? '');
            $timeFmt = $timeRaw;
            if ($timeRaw !== '') {
                $ts = strtotime($timeRaw);
                if ($ts !== false) {
                    $timeFmt = date('y-m-d h:i A', $ts);
                }
            }
            $pdf->Cell($colWidths[0], 6, $timeFmt, 1, 0);
            $pdf->Cell($colWidths[1], 6, (string)($row['user'] ?? ''), 1, 0);
            $pdf->Cell($colWidths[2], 6, (string)($row['message'] ?? ''), 1, 0);
            $pdf->Ln();
        }
    }

    $fileName = 'user_audit_logs.pdf';
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . $fileName . '"');
    $pdf->Output('I', $fileName);
    exit;
}

public function updateUserRole(): void
{
    Auth::requireAdmin();
    Csrf::check();

    $target = strtolower(trim((string)($_POST['email'] ?? '')));
    $role   = (string)($_POST['role'] ?? '');

    if (!in_array($role, ['admin', 'player'], true)) {
        flash_set('error', 'Invalid role.');
        redirect('admin/users');
    }

    $um = new UserModel();
    $u = $um->find($target);

    if (!$u) {
        flash_set('error', 'User not found.');
        redirect('admin/users');
    }

    $currentUser = Auth::user();
    $currentEmail = strtolower((string)($currentUser['email'] ?? ''));

    // Prevent self-demotion
    if ($target === $currentEmail && $role !== 'admin') {
        flash_set('error', 'You cannot remove your own admin role while logged in.');
        redirect('admin/users');
    }

    // Prevent removing the last active admin
    if (($u['role'] ?? '') === 'admin' && $role !== 'admin') {
        if ($um->countAdmins() <= 1 && empty($u['disabled'])) {
            flash_set('error', 'You cannot demote the last active admin.');
            redirect('admin/users');
        }
    }

    $u['role'] = $role;
    $um->upsert($u);
    $this->addUserAudit('User role updated: ' . $target . ' to ' . $role . '.');

    // If demoted/promoted to player, ensure in players list
    if ($role === 'player') {
        (new PlayerModel())->upsert($target, (string)($u['name'] ?? $target));
    }

    flash_set('success', 'Role updated.');
    redirect('admin/users');
}

public function resetUserPassword(): void
{
    Auth::requireAdmin();
    Csrf::check();

    $target = strtolower(trim((string)($_POST['email'] ?? '')));
    $pass   = (string)($_POST['password'] ?? '');

    if (strlen($pass) < 6) {
        flash_set('error', 'Password must be at least 6 characters.');
        redirect('admin/users');
    }

    $um = new UserModel();
    $u = $um->find($target);
    if (!$u) {
        flash_set('error', 'User not found.');
        redirect('admin/users');
    }

    $u['password_hash'] = password_hash($pass, PASSWORD_DEFAULT);
    $um->upsert($u);
    $this->addUserAudit('User password reset: ' . $target . '.');

    flash_set('success', 'Password reset.');
    redirect('admin/users');
}

    public function toggleUserDisabled(): void
    {
        Auth::requireAdmin();
        Csrf::check();

        $target = strtolower(trim((string)($_POST['email'] ?? '')));

        $um = new UserModel();
        $u = $um->find($target);
        if (!$u) {
            flash_set('error', 'User not found.');
            redirect('admin/users');
        }

        $currentUser = Auth::user();
        $currentEmail = strtolower((string)($currentUser['email'] ?? ''));

        // Prevent disabling self
        if ($target === $currentEmail) {
            flash_set('error', 'You cannot disable your own account while logged in.');
            redirect('admin/users');
        }

        // Prevent disabling last active admin
        if (($u['role'] ?? '') === 'admin' && empty($u['disabled'])) {
            if ($um->countAdmins() <= 1) {
                flash_set('error', 'You cannot disable the last active admin.');
                redirect('admin/users');
            }
        }

        $u['disabled'] = empty($u['disabled']); // toggle
        $um->upsert($u);
        $this->addUserAudit('User ' . ($u['disabled'] ? 'disabled' : 'enabled') . ': ' . $target . '.');

        flash_set('success', 'User status updated.');
        redirect('admin/users');
    }






    private function addUserAudit(string $message): void
    {
        $ds = new DataStore();
        $data = $ds->load('user_audit.json', ['audit' => []]);
        $audit = (array)($data['audit'] ?? []);
        $audit[] = [
            'time' => date('c'),
            'user' => (string)(Auth::user()['email'] ?? ''),
            'message' => $message,
        ];
        $ds->save('user_audit.json', ['audit' => $audit]);
    }

    private function getUserAudit(): array
    {
        $ds = new DataStore();
        $data = $ds->load('user_audit.json', ['audit' => []]);
        return (array)($data['audit'] ?? []);
    }

}
