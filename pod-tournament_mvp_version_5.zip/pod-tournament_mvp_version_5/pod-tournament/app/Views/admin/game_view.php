<?php
$players = (array)($game['players'] ?? []);
$rounds  = (array)($game['rounds'] ?? []);
$hasActiveRound = false;
foreach ($rounds as $r) {
  if (empty($r['completed'])) {
    $hasActiveRound = true;
    break;
  }
}
$status  = (string)($game['status'] ?? 'active');
$droppedPlayers = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
$allPlayers = array_keys($playersMeta);
$playersLower = array_map('strtolower', $players);
$availablePlayers = array_values(array_filter($allPlayers, function ($email) use ($playersLower) {
  return !in_array(strtolower($email), $playersLower, true);
}));
?>
<div id="game-header" class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
  <div>
    <h3 class="mb-1"><?php echo e($game['name']); ?></h3>
    <div class="table-responsive mt-2 game-details-scroll">
      <table class="table table-sm mb-0">
        <tbody>
          <tr>
            <th class="text-muted fw-semibold" style="width: 180px;">ID</th>
            <td><?php echo e($game['id']); ?></td>
          </tr>
          <tr>
            <th class="text-muted fw-semibold">Status</th>
            <td><span class="badge text-bg-<?php echo $status==='ended'?'secondary':'success'; ?>"><?php echo e($status); ?></span></td>
          </tr>
          <tr>
            <th class="text-muted fw-semibold">Game Mode</th>
            <td><?php echo e((string)($game['game_mode'] ?? '-')); ?></td>
          </tr>
          <tr>
            <th class="text-muted fw-semibold">Score System</th>
            <td><?php echo e((string)($game['score_system'] ?? '-')); ?></td>
          </tr>
          <tr>
            <th class="text-muted fw-semibold">Description</th>
            <td><?php echo e((string)($game['description'] ?? '-')); ?></td>
          </tr>
          <tr>
            <th class="text-muted fw-semibold">Date Created</th>
            <td><?php echo e((string)($game['created_at'] ?? '-')); ?></td>
          </tr>
          <tr>
            <th class="text-muted fw-semibold">Date Completed</th>
            <td><?php echo e((string)($game['ended_at'] ?? '-')); ?></td>
          </tr>
          <tr>
            <th class="text-muted fw-semibold">No. of Players</th>
            <td><?php echo count($players); ?></td>
          </tr>
          <tr>
            <th class="text-muted fw-semibold">Rounds</th>
            <td><?php echo count($rounds); ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-lg fw-bold" href="?r=admin/reports&id=<?php echo e($game['id']); ?>">Reports</a>
  </div>
</div>

<div id="game-main">
<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Add Players to Game</div>
    <hr class="mt-0 mb-3">

    <?php if ($status !== 'active'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1">Game ended. Players cannot be added.</div>
    <?php elseif (empty($allPlayers)): ?>
      <div class="text-muted">No players yet. Add players in Admin &rarr; Users.</div>
    <?php elseif (empty($availablePlayers)): ?>
      <div class="text-muted">All players are already in this game.</div>
    <?php else: ?>
      <form method="post" action="?r=admin/addGamePlayers" class="row g-2 align-items-end" data-ajax="1">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">

        <div class="col-12">
          <label class="form-label">Select Players to Add</label>
          <div class="d-flex gap-2 mb-2">
            <button type="button" class="btn btn-success btn-sm" data-select-all="game-players">Select All</button>
            <button type="button" class="btn btn-warning btn-sm" data-clear-all="game-players">Clear All</button>
          </div>
          <div class="mb-2" style="max-width: 320px;">
            <input class="form-control form-control-sm" type="search" placeholder="Search players..." data-player-search>
          </div>
          <div class="table-responsive" style="max-height: 320px;">
            <table class="table table-sm align-middle mb-0">
              <thead>
                <tr>
                  <th style="width: 40px;"></th>
                  <th>Player</th>
                  <th>Email</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($availablePlayers as $email): ?>
                  <?php $p = $playersMeta[$email] ?? ['name' => $email]; ?>
                  <tr data-player-row data-player-name="<?php echo e($p['name']); ?>" data-player-email="<?php echo e($email); ?>">
                    <td>
                      <input class="form-check-input" type="checkbox" name="players[]" value="<?php echo e($email); ?>">
                    </td>
                    <td><?php echo e($p['name']); ?></td>
                    <td class="text-muted"><?php echo e($email); ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

        <div class="col-md-3">
          <button class="btn btn-primary w-100">Add Players</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Display Background (Secondary Screen)</div>
    <hr class="mt-0 mb-3">
    <form method="post" action="?r=admin/uploadDisplayBackground" enctype="multipart/form-data" class="row g-2 align-items-end" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <div class="col-md-8">
        <label class="form-label">Upload Background (PNG/JPG/WEBP)</label>
        <input class="form-control" type="file" name="background_file" accept=".png,.jpg,.jpeg,.webp" required <?php echo $status === 'ended' ? 'disabled' : ''; ?>>
        <?php if (!empty($game['display_background'])): ?>
          <div class="small text-muted mt-1">Current: <?php echo e((string)$game['display_background']); ?></div>
        <?php endif; ?>
      </div>
      <div class="col-md-4">
        <button class="btn btn-success w-100" <?php echo $status === 'ended' ? 'disabled' : ''; ?> onclick="return confirm('Upload this display background?');">Upload Background</button>
      </div>
    </form>
    <?php if ($status === 'ended'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1 mt-2">GAME ENDED. NO MORE CHANGES.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Sponsor Banner (Display Only)</div>
    <hr class="mt-0 mb-3">
    <form method="post" action="?r=admin/uploadSponsorBanner" enctype="multipart/form-data" class="row g-2 align-items-end" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <div class="col-md-8">
        <label class="form-label">Upload Banner (PNG/JPG/WEBP)</label>
        <input class="form-control" type="file" name="sponsor_file" accept=".png,.jpg,.jpeg,.webp" required <?php echo $status === 'ended' ? 'disabled' : ''; ?>>
        <?php if (!empty($game['sponsor_banner'])): ?>
          <div class="small text-muted mt-1">Current: <?php echo e((string)$game['sponsor_banner']); ?></div>
        <?php endif; ?>
      </div>
      <div class="col-md-4">
        <button class="btn btn-success w-100" <?php echo $status === 'ended' ? 'disabled' : ''; ?> onclick="return confirm('Upload this sponsor banner?');">Upload Banner</button>
      </div>
    </form>
    <?php if ($status === 'ended'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1 mt-2">GAME ENDED. NO MORE CHANGES.</div>
    <?php endif; ?>
  </div>
</div>
<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Current Ranking (Tie-break rules applied)</div>
    <hr class="mt-0 mb-3">

    <div class="d-flex flex-wrap justify-content-between gap-2 mb-2">
      <input class="form-control form-control-sm" id="rankingSearch" type="search" placeholder="Search ranking..." style="max-width: 280px;">
    </div>
    <div class="table-responsive ranking-scroll">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>Player</th>
            <th>Total Score</th>
            <th>Total Wins Points</th>
            <th>Win Rate</th>
            <th>Match-win %</th>
            <th>Game-win %</th>
            <th>OWP</th>
            <th>OGP</th>
            <th>Status</th>
          </tr>
          <tr>
            <th><input class="form-control form-control-sm ranking-filter" data-col="0" placeholder="#"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="1" placeholder="Player"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="2" placeholder="Score"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="3" placeholder="Win Pts"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="4" placeholder="Win %"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="5" placeholder="Match %"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="6" placeholder="Game %"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="7" placeholder="OWP"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="8" placeholder="OGP"></th>
            <th><input class="form-control form-control-sm ranking-filter" data-col="9" placeholder="Status"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach (($standings['ranked'] ?? []) as $i => $r): ?>
            <?php
              $emailLower = strtolower((string)$r['email']);
              $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']];
              $isDropped = in_array($emailLower, $droppedPlayers, true);
            ?>
            <tr class="<?php echo $isDropped ? 'table-secondary' : ''; ?>">
              <td><?php echo $i+1; ?></td>
              <td>
                <?php echo e($meta['name']); ?>
                <span class="small text-muted">(<?php echo e($r['email']); ?>)</span>
                <?php if ($isDropped): ?>
                  <span class="badge text-bg-danger ms-1">DROPPED</span>
                <?php endif; ?>
              </td>
              <td><?php echo (int)$r['total_score']; ?></td>
              <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
              <td><?php echo number_format((float)$r['win_rate'], 3); ?></td>
              <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['owp'], 3); ?></td>
              <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
              <td>
                <form method="post" action="?r=admin/toggleDropPlayer" class="m-0" data-ajax="1" onsubmit="return confirm('<?php echo $isDropped ? 'Rejoin this player for future rounds?' : 'Drop this player from future rounds?'; ?>');">
                  <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                  <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
                  <input type="hidden" name="email" value="<?php echo e($r['email']); ?>">
                  <input type="hidden" name="drop" value="<?php echo $isDropped ? '0' : '1'; ?>">
                  <button class="btn btn-sm <?php echo $isDropped ? 'btn-outline-success' : 'btn-outline-danger'; ?>" <?php echo $status === 'ended' ? 'disabled' : ''; ?>>
                    <?php echo $isDropped ? 'Rejoin' : 'Drop'; ?>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($standings['ranked'])): ?>
            <tr><td colspan="10" class="text-muted">No standings yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php if ($status === 'ended'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1 mt-2">GAME ENDED. NO MORE CHANGES.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Create New Round</div>
    <hr class="mt-0 mb-3">

      <?php if ($status !== 'active'): ?>
        <div class="small fst-italic text-white bg-danger rounded text-center py-1">Game ended. No more rounds can be created.</div>
      <?php elseif ($hasActiveRound): ?>
        <div class="small fst-italic text-white bg-danger rounded text-center py-1">An active round is still ongoing. Complete it before creating a new round.</div>
      <?php else: ?>
        <form method="post" action="?r=admin/createRound" class="row g-2 align-items-start" data-ajax="1">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">

        <div class="col-12">
          <div class="fw-bold">Pairing Mode</div>
          <hr class="mt-1 mb-2">
        </div>
        <div class="col-md-6">
          <select class="form-select" name="pairing_mode">
            <option value="ranking_top4">A) Ranking: top 4 per pod (table order)</option>
            <option value="ranking_highlow">B) Ranking: 2 highest + 2 lowest per pod</option>
            <option value="swiss_pods">C) Swiss Pods (recommended)</option>
            <option value="true_swiss">D) True Swiss</option>
            <option value="power_pods">E) Power Pods</option>
            <option value="bubble_pods">F) Bubble Pods</option>
            <option value="random_pods">G) Random Pods (avoid repeats)</option>
            <option value="top1_low3">H) Highest 1 vs Lowest 3</option>
            <option value="alpha_no_repeat">I) Alphabetical (tries to avoid repeats)</option>
          </select>
          <div class="form-text">Note: avoid repeats is best-effort when later rounds make perfect avoidance impossible.</div>
        </div>

        <div class="col-md-3 d-flex align-items-start">
          <button class="btn btn-primary w-100" onclick="return confirm('Are you sure you want to create a NEW ROUND?');">Create Round</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>
<div class="card">
  <div class="card-body">
    <div class="section-title">Rounds</div>
    <hr class="mt-0 mb-3">

    <?php if (empty($rounds)): ?>
      <div class="text-muted">No rounds created yet.</div>
    <?php else: ?>
      <div class="list-group">
        <?php $lastRoundNum = count($rounds); ?>
        <?php foreach ($rounds as $r): ?>
          <?php
            $roundStatus = 'PREPARING';
            if (!empty($r['completed'])) {
              $roundStatus = 'COMPLETED';
            } elseif (!empty($r['timer_running'])) {
              $roundStatus = 'IN PROGRESS';
            } elseif (!empty($r['timer_start'])) {
              $roundStatus = 'TIMER STOPPED';
            } elseif (!empty($r['pairing_locked'])) {
              $roundStatus = 'PAIRINGS LOCKED';
            }
            $statusClass = 'text-bg-secondary';
            if ($roundStatus === 'COMPLETED') $statusClass = 'text-bg-success';
            elseif ($roundStatus === 'IN PROGRESS') $statusClass = 'text-bg-primary';
            elseif ($roundStatus === 'PAIRINGS LOCKED') $statusClass = 'text-bg-warning';
          ?>
          <a class="list-group-item list-group-item-action"
             href="<?php echo $status === 'ended' ? ('?r=admin/reports&id=' . e($game['id'])) : ('?r=admin/viewRound&id=' . e($game['id']) . '&round=' . (int)$r['number']); ?>">
            <div class="d-flex justify-content-between">
              <div>
                <div class="fw-semibold">Round <?php echo (int)$r['number']; ?></div>
                <div class="small text-muted">Pods: <?php echo count((array)$r['pods']); ?></div>
              </div>
              <div class="d-flex align-items-center gap-2">
                <span class="badge <?php echo $statusClass; ?>"><?php echo e($roundStatus); ?></span>
                <div class="small text-muted"><?php echo e($r['created_at'] ?? ''); ?></div>
                <?php if ((int)$r['number'] === $lastRoundNum && empty($r['timer_start']) && empty($r['completed'])): ?>
                  <form method="post" action="?r=admin/deleteRound" data-confirm="Delete this round?" data-ajax="1">
                    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                    <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
                    <input type="hidden" name="round" value="<?php echo (int)$r['number']; ?>">
                    <button class="btn btn-outline-danger btn-sm">Delete</button>
                  </form>
                <?php endif; ?>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="card mt-3">
  <div class="card-body">
    <div class="section-title">AUDIT LOGS</div>
    <hr class="mt-0 mb-3">
    <?php
      $formatAuditTime = function ($ts): string {
        if (!$ts) return '';
        try {
          $dt = new DateTime((string)$ts);
          return $dt->format('y-m-d h:i A');
        } catch (Exception $e) {
          return (string)$ts;
        }
      };
      $sortAudit = function (array $rows): array {
        usort($rows, function ($a, $b) {
          $ta = strtotime((string)($a['time'] ?? '')) ?: 0;
          $tb = strtotime((string)($b['time'] ?? '')) ?: 0;
          return $tb <=> $ta;
        });
        return $rows;
      };
      $gameAudit = $sortAudit((array)($game['audit'] ?? []));
    ?>

      <?php if (empty($gameAudit) && empty($rounds)): ?>
        <div class="text-muted text-center">No audit entries yet.</div>
      <?php else: ?>
        <div class="audit-group-scroll">
          <?php if (!empty($gameAudit)): ?>
            <div class="fw-semibold audit-group-header">Game Actions</div>
            <div class="table-responsive mb-3">
            <table class="table table-sm align-middle">
              <thead>
                <tr>
                  <th>Game</th>
                  <th>Time</th>
                  <th>User</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($gameAudit as $entry): ?>
                  <tr>
                    <td><?php echo e((string)($game['name'] ?? '')); ?></td>
                    <td><?php echo e($formatAuditTime($entry['time'] ?? '')); ?></td>
                    <td><?php echo e((string)($entry['user'] ?? '')); ?></td>
                    <td><?php echo e((string)($entry['message'] ?? '')); ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            </div>
          <?php endif; ?>
  
          <?php foreach ($rounds as $r): ?>
            <?php $roundAudit = $sortAudit((array)($r['audit'] ?? [])); ?>
            <div class="fw-semibold mb-2">Round <?php echo (int)($r['number'] ?? 0); ?></div>
            <?php if (empty($roundAudit)): ?>
              <div class="text-muted mb-3">No audit entries for this round.</div>
            <?php else: ?>
              <div class="table-responsive mb-3">
                <table class="table table-sm align-middle">
                  <thead>
                    <tr>
                      <th>Game</th>
                      <th>Round</th>
                      <th>Time</th>
                      <th>User</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($roundAudit as $entry): ?>
                      <tr>
                        <td><?php echo e((string)($game['name'] ?? '')); ?></td>
                        <td><?php echo (int)($r['number'] ?? 0); ?></td>
                        <td><?php echo e($formatAuditTime($entry['time'] ?? '')); ?></td>
                        <td><?php echo e((string)($entry['user'] ?? '')); ?></td>
                        <td><?php echo e((string)($entry['message'] ?? '')); ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
  </div>
</div>



<?php if ($status === 'ended'): ?>
  <div class="d-flex justify-content-start mt-3">
    <form method="post" action="?r=admin/reopenGame" onsubmit="return confirm('Reopen this game? This will allow changes again.');" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <button class="btn btn-success btn-lg fw-bold">Reopen Game</button>
    </form>
  </div>
<?php endif; ?>
</div>

<script>
(() => {
  const SECTION_IDS = ["game-header", "game-main"];
  const globalAjax = window.MANA_POD_GLOBAL_AJAX === true;

  function initRankingFilters(root = document) {
    const table = root.querySelector(".ranking-scroll table");
    if (!table) return;
    const rows = Array.from(table.querySelectorAll("tbody tr"));
    const search = root.querySelector("#rankingSearch");
    const filters = Array.from(root.querySelectorAll(".ranking-filter"));

    function matches(row) {
      const text = row.textContent.toLowerCase();
      if (search && search.value.trim() !== "") {
        if (!text.includes(search.value.toLowerCase().trim())) return false;
      }
      for (const input of filters) {
        const val = input.value.toLowerCase().trim();
        if (!val) continue;
        const col = Number(input.dataset.col || 0);
        const cell = row.children[col];
        if (!cell || !cell.textContent.toLowerCase().includes(val)) return false;
      }
      return true;
    }

    function applyFilters() {
      rows.forEach((row) => {
        row.style.display = matches(row) ? "" : "none";
      });
    }

    if (search && !search.dataset.filterBound) {
      search.dataset.filterBound = "1";
      search.addEventListener("input", applyFilters);
    }
    filters.forEach((input) => {
      if (input.dataset.filterBound === "1") return;
      input.dataset.filterBound = "1";
      input.addEventListener("input", applyFilters);
    });

    applyFilters();
  }

  function initPlayerSelect(root = document) {
    const search = root.querySelector("[data-player-search]");
    const rows = Array.from(root.querySelectorAll("[data-player-row]"));
    const checkboxes = Array.from(root.querySelectorAll("input[name='players[]']"));
    const selectAllBtn = root.querySelector("[data-select-all='game-players']");
    const clearAllBtn = root.querySelector("[data-clear-all='game-players']");

    function matches(row) {
      const name = String(row.dataset.playerName || "").toLowerCase();
      const email = String(row.dataset.playerEmail || "").toLowerCase();
      const term = search ? search.value.trim().toLowerCase() : "";
      if (!term) return true;
      return name.includes(term) || email.includes(term);
    }

    function applyFilter() {
      rows.forEach((row) => {
        row.style.display = matches(row) ? "" : "none";
      });
    }

    if (search && !search.dataset.filterBound) {
      search.dataset.filterBound = "1";
      search.addEventListener("input", applyFilter);
    }

    if (selectAllBtn && !selectAllBtn.dataset.bound) {
      selectAllBtn.dataset.bound = "1";
      selectAllBtn.addEventListener("click", () => {
        checkboxes.forEach((cb) => {
          if (cb.disabled) return;
          cb.checked = true;
        });
      });
    }

    if (clearAllBtn && !clearAllBtn.dataset.bound) {
      clearAllBtn.dataset.bound = "1";
      clearAllBtn.addEventListener("click", () => {
        checkboxes.forEach((cb) => {
          if (cb.disabled) return;
          cb.checked = false;
        });
      });
    }

    applyFilter();
  }

  function setLoading(form, loading) {
    form.querySelectorAll("button, input[type='submit']").forEach((btn) => {
      if (!btn.dataset.ajaxWasDisabled) {
        btn.dataset.ajaxWasDisabled = btn.disabled ? "1" : "0";
      }
      if (loading) {
        btn.disabled = true;
      } else if (btn.dataset.ajaxWasDisabled === "0") {
        btn.disabled = false;
      }
    });
  }

  function updateFromHtml(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    SECTION_IDS.forEach((id) => {
      const fresh = doc.getElementById(id);
      const current = document.getElementById(id);
      if (fresh && current) {
        current.replaceWith(fresh);
      }
    });
    initRankingFilters();
    initPlayerSelect();
    if (!globalAjax) {
      initAjaxForms();
    }
  }

  async function submitAjax(form) {
    const scrollY = window.scrollY;
    setLoading(form, true);
    try {
      const response = await fetch(form.action, {
        method: form.method || "POST",
        body: new FormData(form),
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
      });

      if (!response.ok) {
        window.location.reload();
        return;
      }

      const html = await response.text();
      const url = response.url || "";
      if (!url.includes("admin/viewGame")) {
        window.location = url || window.location.href;
        return;
      }

      updateFromHtml(html);
      window.scrollTo(0, scrollY);
    } catch (err) {
      window.location.reload();
    } finally {
      setLoading(form, false);
    }
  }

  function initAjaxForms(root = document) {
    if (globalAjax) return;
    root.querySelectorAll("form[data-ajax]").forEach((form) => {
      if (form.dataset.ajaxBound === "1") return;
      form.dataset.ajaxBound = "1";
      form.addEventListener("submit", (event) => {
        if (event.defaultPrevented) return;
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        submitAjax(form);
      });
    });
  }

  initRankingFilters();
  initPlayerSelect();
  if (!globalAjax) {
    initAjaxForms();
  }
})();
</script>



