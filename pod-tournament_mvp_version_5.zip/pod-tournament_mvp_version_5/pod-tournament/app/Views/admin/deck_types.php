<div id="deck-types-header"><h3 class="mb-3">Deck Types</h3></div>

<div id="deck-types-main">
<div class="card mb-3">
  <div class="card-body">
    <div class="fw-semibold mb-2">Add Deck Type</div>
    <form method="post" action="?r=admin/addDeckType" class="row g-2 align-items-end" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="col-md-6">
        <label class="form-label">Type Name</label>
        <input class="form-control" name="type_name" placeholder="e.g. Modern" required>
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary w-100">Add Type</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="fw-semibold mb-2">Available Types</div>
    <ul class="mb-0">
      <?php foreach ($types as $t): ?>
        <li><?php echo e($t); ?></li>
      <?php endforeach; ?>
      <?php if (empty($types)): ?>
        <li class="text-muted">No types yet.</li>
      <?php endif; ?>
    </ul>
  </div>
</div>

<div class="card mt-3">
  <div class="card-body">
    <div class="fw-semibold mb-2">Game Modes</div>
    <form method="post" action="?r=admin/addGameMode" class="row g-2 align-items-end" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="col-md-6">
        <label class="form-label">Mode Name</label>
        <input class="form-control" name="mode_name" placeholder="e.g. Commander Multi" required>
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary w-100">Add Mode</button>
      </div>
    </form>

    <ul class="mb-0 mt-3">
      <?php foreach (($gameModes ?? []) as $mode): ?>
        <li><?php echo e($mode); ?></li>
      <?php endforeach; ?>
      <?php if (empty($gameModes)): ?>
        <li class="text-muted">No modes yet.</li>
      <?php endif; ?>
    </ul>
  </div>
</div>

<div class="card mt-3">
  <div class="card-body">
    <div class="fw-semibold mb-2">Score Systems</div>
    <form method="post" action="?r=admin/addScoreSystem" class="row g-2 align-items-end" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="col-md-6">
        <label class="form-label">System Name</label>
        <input class="form-control" name="system_name" placeholder="e.g. WIN-LOSE-DRAW System" required>
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary w-100">Add System</button>
      </div>
    </form>

    <ul class="mb-0 mt-3">
      <?php foreach (($scoreSystems ?? []) as $system): ?>
        <li><?php echo e($system); ?></li>
      <?php endforeach; ?>
      <?php if (empty($scoreSystems)): ?>
        <li class="text-muted">No systems yet.</li>
      <?php endif; ?>
    </ul>
  </div>
</div>
</div>

<script>
(() => {
  if (window.MANA_POD_GLOBAL_AJAX) return;
  const SECTION_IDS = ["deck-types-header", "deck-types-main"];

  

  function setLoading(form, loading) {
    form.querySelectorAll("button, input[type='submit']").forEach((btn) => {
      if (!btn.dataset.ajaxWasDisabled) {
        btn.dataset.ajaxWasDisabled = btn.disabled ? "1" : "0";
      }
      if (loading) {
        btn.disabled = true;
      } else if (btn.dataset.ajaxWasDisabled === "0") {
        btn.disabled = false;
      }
    });
  }

  function updateFromHtml(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    SECTION_IDS.forEach((id) => {
      const fresh = doc.getElementById(id);
      const current = document.getElementById(id);
      if (fresh && current) {
        current.replaceWith(fresh);
      }
    });
    if (typeof initAfterAjax === "function") {
      initAfterAjax();
    }
    initAjaxForms();
  }

  async function submitAjax(form) {
    const scrollY = window.scrollY;
    setLoading(form, true);
    try {
      const response = await fetch(form.action, {
        method: form.method || "POST",
        body: new FormData(form),
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
      });

      if (!response.ok) {
        window.location.reload();
        return;
      }

      const html = await response.text();
      const url = response.url || "";
      if (!url.includes("admin/deckTypes")) {
        window.location = url || window.location.href;
        return;
      }

      updateFromHtml(html);
      window.scrollTo(0, scrollY);
    } catch (err) {
      window.location.reload();
    } finally {
      setLoading(form, false);
    }
  }

  function initAjaxForms(root = document) {
    root.querySelectorAll("form[data-ajax]").forEach((form) => {
      if (form.dataset.ajaxBound === "1") return;
      form.dataset.ajaxBound = "1";
      form.addEventListener("submit", (event) => {
        if (event.defaultPrevented) return;
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        submitAjax(form);
      });
    });
  }

  if (typeof initAfterAjax === "function") {
    initAfterAjax();
  }
  initAjaxForms();
})();
</script>
