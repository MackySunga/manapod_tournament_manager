<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5 login-panel">
    <img src="assets/manapodlogo.png" alt="Mana Pod logo" class="login-logo">
    <h3 class="mb-3 text-center">Login</h3>

    <form method="post">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">

      <div class="mb-2">
        <label class="form-label">Email</label>
        <input class="form-control" name="email" type="email" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Password</label>
        <input class="form-control" name="password" type="password" required>
      </div>

      <button class="btn btn-primary w-100">Log in</button>
    </form>

    <div class="mt-3 small">
      No account yet? <a href="?r=auth/register">Register</a>
    </div>

    <div class="mt-3 small text-muted">
      Default admin: admin@example.com / admin123
    </div>
  </div>
</div>
