<?php
use App\Core\Auth;

$u = Auth::user();
$isAdmin = $u && (($u['role'] ?? '') === 'admin');
?>
<nav class="navbar navbar-expand-lg border-bottom sticky-top">
  <div class="container">
    <a class="navbar-brand fw-semibold d-inline-flex align-items-center gap-2" href="?r=<?php echo $isAdmin ? 'admin/dashboard' : 'player/home'; ?>">
      <img src="assets/manapodlogo.png" alt="Mana Pod logo" class="brand-logo">
        <span class="d-inline-flex flex-column gap-1">
          <span>Mana Pod Tournament Manager</span>
        </span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <?php if ($u && $isAdmin): ?>
          <li class="nav-item"><a class="nav-link" href="?r=admin/dashboard">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=admin/users">Users</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=admin/games">Games</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=admin/deckTypes">Deck Types</a></li>
        <?php elseif ($u): ?>
          <li class="nav-item"><a class="nav-link" href="?r=player/home">My Games</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=player/myStats">MyStats</a></li>
          <li class="nav-item"><a class="nav-link" href="?r=player/myDeck">My Deck</a></li>
        <?php endif; ?>
        <li class="nav-item"><a class="nav-link" href="?r=about/index">About</a></li>
      </ul>

      <div class="d-flex align-items-center gap-2">
        <?php if ($u): ?>
          <?php $email = (string)($u['email'] ?? ''); ?>
          <?php $initial = $email !== '' ? strtoupper($email[0]) : '?'; ?>
          <button class="btn btn-outline-secondary btn-sm" type="button" id="themeToggle">Toggle theme</button>
          <div class="dropdown">
            <button class="btn p-0 border-0 bg-transparent dropdown-toggle user-avatar-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              <span class="user-avatar" data-initial="<?php echo e($initial); ?>" aria-hidden="true"></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item text-danger" href="?r=auth/logout">Logout</a></li>
            </ul>
          </div>
        <?php else: ?>
          <a class="btn btn-outline-primary btn-sm" href="?r=auth/login">Login</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
