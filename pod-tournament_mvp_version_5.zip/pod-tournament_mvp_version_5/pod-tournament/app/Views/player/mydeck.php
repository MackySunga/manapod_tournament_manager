<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="mb-0">My Deck</h3>
  <span class="badge text-bg-secondary"><?php echo (int)($deckCount ?? 0); ?> / 10</span>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="fw-semibold mb-2">Add Deck</div>
    <form method="post" action="?r=player/addDeck" class="row g-2 align-items-end" id="deckForm">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="col-md-4">
        <label class="form-label">Deck Type</label>
        <select class="form-select" name="deck_type" id="deckType" required>
          <option value="">Select type</option>
          <?php foreach ($types as $t): ?>
            <option value="<?php echo e($t); ?>"><?php echo e($t); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Deck Name</label>
        <input class="form-control" name="deck_name" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">Deck List Link</label>
        <input class="form-control" name="deck_link" placeholder="https://">
      </div>
      <div class="col-md-4 commander-field d-none">
        <label class="form-label">Commander Name</label>
        <input class="form-control" name="commander_name">
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary w-100" <?php echo (($deckCount ?? 0) >= 10) ? 'disabled' : ''; ?>>Save Deck</button>
      </div>
    </form>
    <?php if (($deckCount ?? 0) >= 10): ?>
      <div class="small text-muted mt-2">Deck limit reached (10). Remove a deck to add a new one.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="fw-semibold mb-2">Saved Decks</div>
    <?php if (empty($decks)): ?>
      <div class="text-muted">No decks yet.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>Deck Name</th>
              <th>Type</th>
              <th>Commander</th>
              <th>List</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($decks as $d): ?>
              <?php
                $createdAt = (string)($d['created_at'] ?? '');
                $createdLabel = $createdAt !== '' ? date('Y-m-d H:i', strtotime($createdAt)) : '';
              ?>
              <tr>
                <td><?php echo e((string)($d['deck_name'] ?? '')); ?></td>
                <td><?php echo e((string)($d['deck_type'] ?? '')); ?></td>
                <td><?php echo e((string)($d['commander_name'] ?? '')); ?></td>
                <td>
                  <?php if (!empty($d['deck_link'])): ?>
                    <a href="<?php echo e((string)$d['deck_link']); ?>" target="_blank" rel="noopener">Link</a>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
                <td><?php echo e($createdLabel); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
(() => {
  const typeSelect = document.getElementById("deckType");
  const commanderField = document.querySelector(".commander-field");
  if (!typeSelect || !commanderField) return;

  function toggleCommander() {
    const val = String(typeSelect.value || "").toLowerCase();
    const isCommander = val.includes("commander");
    commanderField.classList.toggle("d-none", !isCommander);
  }

  typeSelect.addEventListener("change", toggleCommander);
  toggleCommander();
})();
</script>
