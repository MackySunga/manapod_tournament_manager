<h3 class="mb-3">My Games</h3>

<?php if (empty($myGames)): ?>
  <div class="text-muted">You are not included in any game yet.</div>
<?php else: ?>
  <div class="list-group">
    <?php foreach ($myGames as $g): ?>
      <?php
        $rounds = (array)($g['rounds'] ?? []);
        $latestRound = count($rounds) > 0 ? count($rounds) : 0;
        $isActive = (($g['status'] ?? '') === 'active');
        $displayRound = (int)($g['display_round'] ?? 0);
        if ($displayRound < 1 || $displayRound > $latestRound) {
          $displayRound = $latestRound;
        }
        $target = $isActive && $displayRound > 0
          ? ('?r=display/round&id=' . e($g['id']) . '&round=' . (int)$displayRound . '&viewer=player')
          : ('?r=player/standing&id=' . e($g['id']));
      ?>
      <a class="list-group-item list-group-item-action"
         href="<?php echo $target; ?>">
        <div class="d-flex justify-content-between">
          <div>
            <div class="fw-semibold"><?php echo e($g['name']); ?></div>
            <div class="small text-muted">Rounds: <?php echo count((array)$g['rounds']); ?></div>
          </div>
          <span class="badge text-bg-<?php echo (($g['status'] ?? '')==='ended')?'secondary':'success'; ?>">
            <?php echo e($g['status'] ?? ''); ?>
          </span>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
