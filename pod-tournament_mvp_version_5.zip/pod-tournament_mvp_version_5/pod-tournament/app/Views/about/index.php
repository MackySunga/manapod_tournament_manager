<h3 class="mb-3">About</h3>

<ul class="nav nav-tabs mb-3" role="tablist">
  <li class="nav-item" role="presentation"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#readme" type="button">README</button></li>
  <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#dedication" type="button">Dedication</button></li>
  <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#license" type="button">License</button></li>
</ul>

<div class="tab-content">
  <div class="tab-pane fade show active" id="readme">
    <pre class="small bg-light border rounded p-3"><?php echo e($readme !== '' ? $readme : 'README not found.'); ?></pre>
  </div>
  <div class="tab-pane fade" id="dedication">
    <pre class="small bg-light border rounded p-3"><?php echo e($dedication !== '' ? $dedication : 'Dedication not found.'); ?></pre>
  </div>
  <div class="tab-pane fade" id="license">
    <pre class="small bg-light border rounded p-3"><?php echo e($license !== '' ? $license : 'License not found.'); ?></pre>
  </div>
</div>
