<?php
/** @var string $viewFile */
$user = $user ?? null;
?>
<!doctype html>
<html lang="en" data-bs-theme="light">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Mana Pod Tournament Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <?php $cssVer = @filemtime(BASE_PATH . '/public/assets/app.css') ?: time(); ?>
  <link href="assets/app.css?v=<?php echo (int)$cssVer; ?>" rel="stylesheet">
</head>
<body class="min-vh-100">
  <?php require VIEW_PATH . '/partials/nav.php'; ?>
  <main id="app-main" class="container py-4">
    <?php if (empty($suppressFlash)): ?>
      <?php require VIEW_PATH . '/partials/flash.php'; ?>
    <?php endif; ?>
    <?php require $viewFile; ?>
  </main>
  <footer class="border-top py-3">
    <div class="container small text-muted text-center">
      <div>Mana Pod - Version 1.0 (initial)</div>
      © <?php echo date('Y'); ?> Bob Mathew Sunga. Licensed under Custom License.
      <div>All rights reserved.</div>
      <div class="mt-1">Free to use by Philippine local game stores.</div>
      <div class="mt-1">Distribution in any form is strictly prohibited.</div>
      <div class="mt-1">Kindly notify the original author of any changes.</div>
      <div>email: bobmathew.sunga@gmail.com</div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/theme.js"></script>
  <script>
  (() => {
    window.MANA_POD_GLOBAL_AJAX = true;
    const debugScroll = false;
    if ("scrollRestoration" in history) {
      history.scrollRestoration = "manual";
    }
    let main = document.getElementById("app-main");
    if (!main) return;

    function sameRoute(url) {
      try {
        const target = new URL(url, window.location.origin);
        const currentUrl = new URL(window.location.href);
        if (target.pathname !== currentUrl.pathname) return false;
        const targetR = target.searchParams.get("r");
        const currentR = currentUrl.searchParams.get("r");
        if (targetR && currentR && targetR === currentR) return true;
        return target.pathname + target.search === currentUrl.pathname + currentUrl.search;
      } catch (err) {
        return false;
      }
    }

    function reinstallScripts(container) {
      const scripts = Array.from(container.querySelectorAll("script"));
      scripts.forEach((oldScript) => {
        const script = document.createElement("script");
        for (const attr of oldScript.attributes) {
          script.setAttribute(attr.name, attr.value);
        }
        if (oldScript.src) {
          script.src = oldScript.src;
        } else {
          script.textContent = oldScript.textContent;
        }
        oldScript.replaceWith(script);
      });
    }

    function setLoading(form, loading) {
      form.querySelectorAll("button, input[type='submit']").forEach((btn) => {
        if (!btn.dataset.ajaxWasDisabled) {
          btn.dataset.ajaxWasDisabled = btn.disabled ? "1" : "0";
        }
        if (loading) {
          btn.disabled = true;
        } else if (btn.dataset.ajaxWasDisabled === "0") {
          btn.disabled = false;
        }
      });
    }

    function updateFromHtml(html) {
      const doc = new DOMParser().parseFromString(html, "text/html");
      const freshMain = doc.getElementById("app-main");
      if (!freshMain) {
        window.location.reload();
        return;
      }
      main.innerHTML = freshMain.innerHTML;
      reinstallScripts(main);
      initAjaxForms(main);
    }

    function appendDebugAudit(message, form) {
      const table = document.querySelector('table[data-audit-table="round"]');
      if (!table) return;
      const tbody = table.querySelector("tbody");
      if (!tbody) return;
      const roundInput = form ? form.querySelector('input[name="round"]') : null;
      const roundVal = roundInput ? roundInput.value : "";
      const gameTitle = document.querySelector("#round-header h3");
      const time = new Date().toLocaleString();
      const row = document.createElement("tr");
      row.innerHTML = `<td>${gameTitle ? gameTitle.textContent : ""}</td>
        <td>${roundVal}</td>
        <td>${time}</td>
        <td>debug</td>
        <td>${message}</td>`;
      tbody.prepend(row);
      const emptyRow = tbody.querySelector("tr[data-empty='1']");
      if (emptyRow) emptyRow.remove();
    }

    function getPageScrollY() {
      return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
    }

    function setPageScrollY(y) {
      document.documentElement.scrollTop = y;
      document.body.scrollTop = y;
      window.scrollTo(0, y);
    }

    function restoreScroll(anchorId, anchorScrollTop, scrollY, scrollTarget) {
      const freshAnchor = anchorId ? document.getElementById(anchorId) : null;
      if (freshAnchor && anchorScrollTop !== null) {
        freshAnchor.scrollTop = anchorScrollTop;
      }
      if (anchorId === "pods-list") {
        if (scrollTarget && freshAnchor) {
          const targetEl = freshAnchor.querySelector(`[data-scroll-target="${scrollTarget}"]`);
          if (targetEl) {
            const offset = targetEl.offsetTop - freshAnchor.offsetTop;
            freshAnchor.scrollTop = Math.max(0, offset - 16);
          }
        }
        setPageScrollY(scrollY);
        return;
      }
      if (scrollTarget) {
        const targetEl = document.querySelector(`[data-scroll-target="${scrollTarget}"]`);
        if (targetEl) {
          targetEl.scrollIntoView({ block: "center" });
          return;
        }
      }
      if (freshAnchor) {
        const top = freshAnchor.getBoundingClientRect().top + window.scrollY;
        setPageScrollY(Math.max(0, top - 16));
        return;
      }
      setPageScrollY(scrollY);
    }

    async function submitAjax(form) {
      const scrollY = getPageScrollY();
      const anchorId = form.dataset.anchor || "";
      const scrollTarget = form.dataset.scrollTarget || "";
      const anchorEl = anchorId ? document.getElementById(anchorId) : null;
      const anchorScrollTop = anchorEl ? anchorEl.scrollTop : null;
      const debugInfo = { scrollY, anchorId, scrollTarget, anchorScrollTop, action: form.action };
      setLoading(form, true);
      try {
        const response = await fetch(form.action, {
          method: form.method || "POST",
          body: new FormData(form),
          headers: { "X-Requested-With": "XMLHttpRequest" },
        });

        if (!response.ok) {
          window.location.reload();
          return;
        }

        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, "text/html");
        const hasMain = !!doc.getElementById("app-main");
        if (!hasMain) {
          window.location = response.url || window.location.href;
          return;
        }
        updateFromHtml(html);
        if (debugScroll && debugInfo.anchorId === "pods-list") {
          appendDebugAudit(
            "DEBUG submit: scrollY=" +
              debugInfo.scrollY +
              " anchor=" +
              debugInfo.anchorId +
              " target=" +
              debugInfo.scrollTarget +
              " anchorTop=" +
              debugInfo.anchorScrollTop,
            form
          );
          appendDebugAudit(
            "DEBUG response: url=" +
              (response.url || "") +
              " ok=" +
              response.ok +
              " hasMain=" +
              hasMain +
              " len=" +
              html.length,
            form
          );
        }
        requestAnimationFrame(() => {
          restoreScroll(anchorId, anchorScrollTop, scrollY, scrollTarget);
          requestAnimationFrame(() => restoreScroll(anchorId, anchorScrollTop, scrollY, scrollTarget));
        });
        setTimeout(() => restoreScroll(anchorId, anchorScrollTop, scrollY, scrollTarget), 0);
        setTimeout(() => restoreScroll(anchorId, anchorScrollTop, scrollY, scrollTarget), 120);
      } catch (err) {
        window.location.reload();
      } finally {
        setLoading(form, false);
      }
    }

    function initAjaxForms() {
      if (initAjaxForms.bound) return;
      initAjaxForms.bound = true;
      document.addEventListener("submit", (event) => {
        const form = event.target;
        if (!form || form.tagName !== "FORM") return;
        if ((form.method || "").toLowerCase() !== "post") return;
        if (form.dataset.noAjax === "1") return;
        if (event.defaultPrevented) return;
        const confirmMsg = form.dataset.confirm || "";
        if (confirmMsg && !window.confirm(confirmMsg)) {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        submitAjax(form);
      }, true);
    }

    initAjaxForms();
  })();
  </script>
</body>
</html>
