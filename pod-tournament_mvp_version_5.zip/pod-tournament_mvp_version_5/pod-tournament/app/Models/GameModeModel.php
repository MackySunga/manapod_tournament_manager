<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\DataStore;

final class GameModeModel
{
    private DataStore $ds;
    private string $file = 'game_modes.json';

    private array $defaults = [
        'Commander Multi',
        'Best of Three (BO3)',
        'Best of One (BO1)',
    ];

    public function __construct()
    {
        $this->ds = new DataStore();
    }

    public function all(): array
    {
        $data = $this->ds->load($this->file, ['modes' => []]);
        $modes = array_values(array_filter(array_map('strval', (array)($data['modes'] ?? []))));
        if (empty($modes)) {
            $modes = $this->defaults;
            $this->saveAll($modes);
        }
        return $modes;
    }

    public function add(string $mode): bool
    {
        $mode = trim($mode);
        if ($mode === '') return false;

        $modes = $this->all();
        $lower = array_map('strtolower', $modes);
        if (in_array(strtolower($mode), $lower, true)) {
            return false;
        }
        $modes[] = $mode;
        $this->saveAll($modes);
        return true;
    }

    public function saveAll(array $modes): void
    {
        $modes = array_values(array_filter(array_map('strval', $modes)));
        $this->ds->save($this->file, ['modes' => $modes]);
    }
}
