<?php
declare(strict_types=1);

namespace App\Core;

use App\Models\UserModel;

final class Auth
{
    public static function user(): ?array
    {
        $email = (string)($_SESSION['user_email'] ?? '');
        if ($email === '') return null;

        $users = (new UserModel())->all();
        return $users[$email] ?? null;
    }

    public static function requireLogin(): void
    {
        if (!self::user()) {
            flash_set('error', 'Please log in.');
            redirect('auth/login');
        }
    }

    public static function requireAdmin(): void
    {
        self::requireLogin();
        $u = self::user();
        if (!$u || ($u['role'] ?? '') !== 'admin') {
            http_response_code(403);
            exit('Admins only.');
        }
    }

    public static function login(string $email): void
    {
        $_SESSION['user_email'] = strtolower(trim($email));
    }

    public static function logout(): void
    {
        unset($_SESSION['user_email']);
    }
}
