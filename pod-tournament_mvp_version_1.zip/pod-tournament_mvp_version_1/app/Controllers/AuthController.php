<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Csrf;
use App\Models\UserModel;
use App\Models\PlayerModel;

final class AuthController extends Controller
{
    public function login(): void
    {
        if (request_method() === 'POST') {
            \App\Core\Csrf::check();

            $email = strtolower(trim((string)($_POST['email'] ?? '')));
            $pass  = (string)($_POST['password'] ?? '');

            $u = (new \App\Models\UserModel())->find($email);

            if (!$u || !password_verify($pass, (string)($u['password_hash'] ?? ''))) {
                flash_set('error', 'Invalid email or password.');
                redirect('auth/login');
            }

            if (!empty($u['disabled'])) {
                flash_set('error', 'Account is disabled. Contact the administrator.');
                redirect('auth/login');
            }

            \App\Core\Auth::login($email);

            if (($u['role'] ?? '') === 'admin') redirect('admin/dashboard');
            redirect('player/home');
        }

        $this->render('auth/login', [
            'csrf' => \App\Core\Csrf::token(),
            'user' => \App\Core\Auth::user()
        ]);
    }


    public function register(): void
    {
        if (request_method() === 'POST') {
            Csrf::check();

            $email = strtolower(trim((string)($_POST['email'] ?? '')));
            $name  = trim((string)($_POST['name'] ?? ''));
            $pass  = (string)($_POST['password'] ?? '');

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                flash_set('error', 'Please enter a valid email.');
                redirect('auth/register');
            }
            if (strlen($pass) < 6) {
                flash_set('error', 'Password must be at least 6 characters.');
                redirect('auth/register');
            }

            $users = new UserModel();
            if ($users->find($email)) {
                flash_set('error', 'Account already exists. Please log in.');
                redirect('auth/login');
            }

            // Ensure player exists in master players list too
            (new PlayerModel())->upsert($email, $name);

            $users->upsert([
                'email' => $email,
                'name' => $name !== '' ? $name : $email,
                'role' => 'player',
                'password_hash' => password_hash($pass, PASSWORD_DEFAULT),
                'created_at' => date('c'),
            ]);

            flash_set('success', 'Registration successful. You can now log in.');
            redirect('auth/login');
        }

        $this->render('auth/register', [
            'csrf' => Csrf::token(),
            'user' => Auth::user()
        ]);
    }

    public function logout(): void
    {
        Auth::logout();
        flash_set('success', 'Logged out.');
        redirect('auth/login');
    }
}
