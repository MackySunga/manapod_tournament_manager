<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\DataStore;

final class GameModel
{
    private DataStore $ds;
    private string $file = 'games.json';

    public function __construct()
    {
        $this->ds = new DataStore();
    }

    public function all(): array
    {
        $data = $this->ds->load($this->file, ['games' => []]);
        return (array)($data['games'] ?? []);
    }

    public function saveAll(array $gamesById): void
    {
        $this->ds->save($this->file, ['games' => $gamesById]);
    }

    public function create(string $name, array $playerEmails): string
    {
        $id = 'g_' . bin2hex(random_bytes(6));
        $games = $this->all();

        $playerEmails = array_values(array_unique(array_map('strtolower', $playerEmails)));

        $games[$id] = [
            'id' => $id,
            'name' => $name !== '' ? $name : ('Game ' . date('Y-m-d H:i')),
            'status' => 'active', // active|ended
            'created_at' => date('c'),
            'is_active' => true,
            'players' => $playerEmails,
            'rounds' => [],
        ];

        $this->saveAll($games);
        return $id;
    }

    public function find(string $id): ?array
    {
        $games = $this->all();
        return $games[$id] ?? null;
    }

    public function update(string $id, array $game): void
    {
        $games = $this->all();
        $games[$id] = $game;
        $this->saveAll($games);
    }

    public function delete(string $id): bool
    {
        $games = $this->all();
        if (!isset($games[$id])) {
            return false;
        }
        unset($games[$id]);
        $this->saveAll($games);
        return true;
    }
}
