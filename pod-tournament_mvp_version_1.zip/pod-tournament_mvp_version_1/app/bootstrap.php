<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('VIEW_PATH', APP_PATH . '/Views');
define('STORAGE_PATH', BASE_PATH . '/storage');

if (!is_dir(STORAGE_PATH)) {
    mkdir(STORAGE_PATH, 0777, true);
}

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (str_starts_with($class, $prefix)) {
        $relative = substr($class, strlen($prefix));
        $file = APP_PATH . '/' . str_replace('\\', '/', $relative) . '.php';
        if (is_file($file)) require_once $file;
    }
});

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function request_method(): string {
    return strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
}

function redirect(string $route): never {
    $parts = explode('&', $route, 2);
    $r = rawurlencode($parts[0]);
    $qs = $parts[1] ?? '';
    $location = '?r=' . $r;
    if ($qs !== '') {
        $location .= '&' . $qs;
    }
    header('Location: ' . $location);
    exit;
}

function flash_set(string $key, string $msg): void {
    $_SESSION['flash'][$key] = $msg;
}

function flash_get(string $key): ?string {
    $v = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return is_string($v) ? $v : null;
}
