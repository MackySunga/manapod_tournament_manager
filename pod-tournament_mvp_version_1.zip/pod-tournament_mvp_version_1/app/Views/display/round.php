<?php
$timeLimit = (int)($round['time_limit_minutes'] ?? 0);
$timerStart = !empty($round['timer_start']) ? strtotime((string)$round['timer_start']) : null;
$timerEnd = !empty($round['timer_end']) ? strtotime((string)$round['timer_end']) : null;
$timerRunning = !empty($round['timer_running']);
$completed = !empty($round['completed']);
$displayShowPods = !empty($round['display_show_pods']);
$displayBackground = trim((string)($round['display_background'] ?? ''));
if ($displayBackground === '') {
  $displayBackground = trim((string)($game['display_background'] ?? ''));
}
$displayBackground = $displayBackground !== '' ? $displayBackground : 'assets/manapodlogo.png';
$sponsorBanner = trim((string)($game['sponsor_banner'] ?? ''));
$pods = (array)($round['pods'] ?? []);
$podsTotal = count($pods);
$podsSaved = 0;
$podsLocked = 0;
foreach ($pods as $pod) {
  if (!empty($pod['saved'])) $podsSaved++;
  if (!empty($pod['locked'])) $podsLocked++;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo e($game['name'] ?? 'Tournament'); ?> Display</title>
  <style>
    :root {
      --bg: #0b0d12;
      --fg: #f5f5f5;
      --muted: #b7b7b7;
      --accent: #ffcf33;
    }
    * { box-sizing: border-box; }
    html, body { height: 100%; }
    body {
      margin: 0;
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background: var(--bg) url("<?php echo e($displayBackground); ?>") no-repeat center;
      background-size: 85vmin;
      color: var(--fg);
    }
    .overlay {
      min-height: 100%;
      background: rgba(0, 0, 0, 0.68);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 32px;
    }
    .title {
      font-size: 52px;
      font-weight: 700;
      margin-bottom: 8px;
      text-align: center;
      display: inline-flex;
      align-items: center;
      gap: 12px;
    }
    .title-logo {
      height: 1em;
      width: auto;
    }
    .subtitle {
      font-size: 28px;
      color: var(--muted);
      margin-bottom: 24px;
      text-align: center;
    }
    .timer {
      font-size: 96px;
      font-weight: 800;
      letter-spacing: 2px;
      font-variant-numeric: tabular-nums;
      text-align: center;
    }
    .timer small {
      display: block;
      font-size: 20px;
      color: var(--muted);
      margin-top: 8px;
    }
    .status {
      font-size: 64px;
      font-weight: 800;
      color: var(--accent);
      text-align: center;
    }
    .sponsor-banner {
      width: 100%;
      display: flex;
      justify-content: center;
      margin: 8px 0 16px;
    }
    .sponsor-banner img {
      height: 120px;
      max-width: 90%;
      object-fit: contain;
    }
    .pods {
      width: 100%;
      max-width: 1100px;
      margin-top: 24px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 16px;
    }
    .pod {
      border: 1px solid #333;
      border-radius: 12px;
      padding: 16px;
      background: rgba(20, 22, 28, 0.9);
    }
    .pod h3 {
      margin: 0 0 10px;
      font-size: 22px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--accent);
      border-bottom: 1px solid rgba(255, 255, 255, 0.12);
      padding-bottom: 6px;
    }
    .pod-status {
      font-size: 18px;
      font-weight: 700;
      color: var(--accent);
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .pod ul {
      margin: 0;
      padding-left: 16px;
    }
    .pod li {
      margin: 4px 0;
    }
    .pod li.is-winner {
      color: var(--accent);
      font-weight: 700;
    }
    .results {
      width: 100%;
      max-width: 900px;
      margin-top: 24px;
      background: rgba(20, 22, 28, 0.9);
      border: 1px solid #333;
      border-radius: 12px;
      padding: 16px;
    }
    .results h3 {
      margin: 0 0 12px;
      font-size: 22px;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--accent);
    }
    .results table {
      width: 100%;
      border-collapse: collapse;
      font-size: 20px;
    }
    .results th,
    .results td {
      padding: 8px 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.12);
      text-align: left;
    }
    .results th {
      color: var(--muted);
      font-weight: 600;
    }
    .results tr.top8 td {
      color: var(--accent);
      font-weight: 700;
    }
    .display-footer {
      margin-top: 32px;
      font-size: 14px;
      color: var(--muted);
      text-align: center;
    }
    .hidden { display: none; }
  </style>
</head>
<body>
  <div class="overlay" id="displayRoot"
       data-game="<?php echo e($game['id'] ?? ''); ?>"
       data-round="<?php echo (int)$roundNum; ?>"
       data-server-now="<?php echo (int)$serverNow; ?>"
       data-player-view="<?php echo !empty($isPlayerView) ? '1' : '0'; ?>"
       data-bg="<?php echo e($displayBackground); ?>"
       data-game-status="<?php echo e((string)($game['status'] ?? '')); ?>"
       data-start="<?php echo (int)($timerStart ?? 0); ?>"
       data-end="<?php echo (int)($timerEnd ?? 0); ?>"
       data-running="<?php echo $timerRunning ? '1' : '0'; ?>"
       data-limit="<?php echo (int)($timeLimit * 60); ?>"
       data-completed="<?php echo $completed ? '1' : '0'; ?>"
       data-show-pods="<?php echo $displayShowPods ? '1' : '0'; ?>"
       data-pods-total="<?php echo (int)$podsTotal; ?>"
       data-pods-saved="<?php echo (int)$podsSaved; ?>"
       data-pods-locked="<?php echo (int)$podsLocked; ?>">
    <div class="title">
      <img class="title-logo" src="assets/manapodlogo.png" alt="Mana Pod logo">
      <?php echo e($game['name'] ?? 'Tournament'); ?>
    </div>
    <div class="subtitle" id="roundSubtitle">Round <?php echo (int)$roundNum; ?></div>
    <div class="title hidden" id="completedLine">IS NOW COMPLETED</div>
    <div id="sponsorBanner" class="sponsor-banner hidden">
      <img id="sponsorImg" alt="Sponsor banner">
    </div>

    <div id="timerView" class="timer hidden">00:00<small>Round Timer</small></div>
    <div id="overtimeView" class="subtitle hidden">Overtime: <span class="timer-overtime">00:00</span></div>
    <div id="playerTimerNote" class="status hidden">
      ROUND IN PROGRESS
      <div class="subtitle">See Screen Display for Timer</div>
    </div>
    <div id="completedView" class="status hidden">CONGRATULATIONS</div>
    <div id="statusView" class="subtitle hidden"></div>
    <div id="waitingView" class="subtitle hidden">Waiting for round to start…</div>

    <div id="podsView" class="pods hidden">
      <?php foreach ((array)($round['pods'] ?? []) as $idx => $pod): ?>
        <?php $players = (array)($pod['players'] ?? []); ?>
        <?php
          $podSaved = !empty($pod['saved']);
          $podLocked = !empty($pod['locked']);
          $podStatus = $podLocked ? 'GAME CONFIRMED' : ($podSaved ? 'GAME DONE' : 'PENDING');
          $scores = (array)($pod['scores'] ?? []);
          $topPlayer = null;
          if ($podLocked && !empty($players)) {
            $bestScore = null;
            foreach ($players as $email) {
              $val = $scores[$email] ?? null;
              if ($val === null) continue;
              $val = (int)$val;
              if ($bestScore === null || $val > $bestScore) {
                $bestScore = $val;
                $topPlayer = $email;
              }
            }
          }
        ?>
        <div class="pod" data-pod-index="<?php echo (int)$idx; ?>" data-pod-saved="<?php echo $podSaved ? '1' : '0'; ?>" data-pod-locked="<?php echo $podLocked ? '1' : '0'; ?>">
          <h3>Table <?php echo (int)($idx + 1); ?></h3>
          <div class="pod-status"><?php echo e($podStatus); ?></div>
          <ul>
            <?php foreach ($players as $email): ?>
              <?php $meta = $playersMeta[$email] ?? ['name' => $email]; ?>
              <li data-player-email="<?php echo e($email); ?>" class="<?php echo ($podLocked && $topPlayer === $email) ? 'is-winner' : ''; ?>">
                <?php echo e($meta['name']); ?>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endforeach; ?>
    </div>
    <div id="resultsView" class="results hidden">
      <h3>Top 20</h3>
      <table>
        <thead>
          <tr><th>#</th><th>Player</th><th>Score</th></tr>
        </thead>
        <tbody id="resultsBody"></tbody>
      </table>
    </div>
    <?php if (!empty($isPlayerView)): ?>
      <div class="display-footer">
        © <?php echo date('Y'); ?> Bob Mathew Sunga. Licensed under LGPL-3.0.
        <div>Free to use by Philippine local game stores. Kindly notify the original author of any changes.</div>
      </div>
    <?php endif; ?>
  </div>

  <script>
  (() => {
    const root = document.getElementById("displayRoot");
    const timerView = document.getElementById("timerView");
    const completedView = document.getElementById("completedView");
    const waitingView = document.getElementById("waitingView");
    const podsView = document.getElementById("podsView");
    const overtimeView = document.getElementById("overtimeView");
    const statusView = document.getElementById("statusView");
    const playerTimerNote = document.getElementById("playerTimerNote");
    const resultsView = document.getElementById("resultsView");
    const resultsBody = document.getElementById("resultsBody");
    const completedLine = document.getElementById("completedLine");
    const roundSubtitle = document.getElementById("roundSubtitle");
    const sponsorBanner = document.getElementById("sponsorBanner");
    const sponsorImg = document.getElementById("sponsorImg");
    const isPlayerView = root.dataset.playerView === "1";
    const gameId = root.dataset.game || "";
    let gameStatus = root.dataset.gameStatus || "";
    let sponsor = "<?php echo e($sponsorBanner); ?>";

    let serverOffset = Number(root.dataset.serverNow || 0) - Math.floor(Date.now() / 1000);
    let currentBg = root.dataset.bg || "";
    let state = {
      start: Number(root.dataset.start || 0),
      end: Number(root.dataset.end || 0),
      running: root.dataset.running === "1",
      limit: Number(root.dataset.limit || 0),
      completed: root.dataset.completed === "1",
      showPods: root.dataset.showPods === "1",
      podsTotal: Number(root.dataset.podsTotal || 0),
      podsSaved: Number(root.dataset.podsSaved || 0),
      podsLocked: Number(root.dataset.podsLocked || 0),
      podsStatus: [],
      showResults: false,
      results: [],
    };

    function fmt(sec) {
      sec = Math.max(0, sec);
      const h = Math.floor(sec / 3600);
      const m = Math.floor((sec % 3600) / 60);
      const s = Math.floor(sec % 60);
      if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
      return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    }

    function render() {
      if (isPlayerView && gameStatus === "ended") {
        window.location.href = "?r=player/home";
        return;
      }
      sponsorBanner.classList.add("hidden");
      if (sponsor) {
        sponsorImg.src = sponsor;
        sponsorBanner.classList.remove("hidden");
      }
      if (currentBg) {
        document.body.style.backgroundImage = `url("${currentBg}")`;
      }
      timerView.classList.add("hidden");
      completedView.classList.add("hidden");
      completedLine.classList.add("hidden");
      roundSubtitle.classList.remove("hidden");
      waitingView.classList.add("hidden");
      podsView.classList.add("hidden");
      statusView.classList.add("hidden");
      resultsView.classList.add("hidden");
      playerTimerNote.classList.add("hidden");
      const shouldShowResults = state.showResults || (state.completed && !isPlayerView);
      if (shouldShowResults) {
        resultsBody.innerHTML = "";
        state.results.slice(0, 20).forEach((row, idx) => {
          const tr = document.createElement("tr");
          if (idx < 8) tr.classList.add("top8");
          tr.innerHTML = `<td>${row.rank}</td><td>${row.name}</td><td>${row.score}</td>`;
          resultsBody.appendChild(tr);
        });
      }
      if (state.completed) {
        completedView.classList.remove("hidden");
        completedLine.classList.remove("hidden");
        roundSubtitle.classList.add("hidden");
        overtimeView.classList.add("hidden");
        statusView.classList.add("hidden");
        if (shouldShowResults) {
          resultsView.classList.remove("hidden");
        }
        return;
      }

      if (!state.start) {
        if (state.showPods) {
          podsView.classList.remove("hidden");
        } else {
          waitingView.classList.remove("hidden");
        }
        overtimeView.classList.add("hidden");
        return;
      }

      const now = Math.floor(Date.now() / 1000) + serverOffset;
      const elapsed = (state.running ? now : (state.end || now)) - state.start;
      if (isPlayerView) {
        playerTimerNote.classList.remove("hidden");
        overtimeView.classList.add("hidden");
      } else {
        timerView.textContent = fmt(elapsed);
        timerView.classList.remove("hidden");
      }
      if (state.showPods) {
        podsView.classList.remove("hidden");
      }
      if (state.showResults) {
        resultsView.classList.remove("hidden");
      }
      if (!isPlayerView && state.limit > 0) {
        const overtime = Math.max(0, elapsed - state.limit);
        overtimeView.classList.remove("hidden");
        overtimeView.querySelector(".timer-overtime").textContent = fmt(overtime);
      } else if (!isPlayerView) {
        overtimeView.classList.add("hidden");
      }
      if (state.showPods) {
        const statusList = state.podsStatus.length > 0
          ? state.podsStatus
          : Array.from(podsView.querySelectorAll("[data-pod-index]")).map((el) => ({
              index: Number(el.dataset.podIndex || 0),
              saved: el.dataset.podSaved === "1",
              locked: el.dataset.podLocked === "1",
              top_player: null,
            }));
        statusList.forEach((p) => {
          const podEl = podsView.querySelector(`[data-pod-index="${p.index}"]`);
          if (!podEl) return;
          const statusEl = podEl.querySelector(".pod-status");
          if (!statusEl) return;
          if (p.locked) {
            statusEl.textContent = "GAME CONFIRMED";
          } else if (p.saved) {
            statusEl.textContent = "GAME DONE";
          } else {
            statusEl.textContent = "PENDING";
          }
          const playerEls = podEl.querySelectorAll("[data-player-email]");
          playerEls.forEach((el) => {
            const isWinner = p.locked && p.top_player && el.dataset.playerEmail === p.top_player;
            el.classList.toggle("is-winner", isWinner);
          });
        });
      }

    }

    async function poll() {
      try {
        const url = `?r=display/roundData&id=${encodeURIComponent(root.dataset.game)}&round=${encodeURIComponent(root.dataset.round)}`;
        const res = await fetch(url, { cache: "no-store" });
        if (!res.ok) return;
        const data = await res.json();
        if (!data || data.error) return;
        serverOffset = Number(data.serverNow || 0) - Math.floor(Date.now() / 1000);
        gameStatus = String(data.game && data.game.status ? data.game.status : "");
        sponsor = String(data.game && data.game.sponsor_banner ? data.game.sponsor_banner : "");
        const r = data.round || {};
        const gameBg = String(data.game && data.game.display_background ? data.game.display_background : "");
        const roundBg = String(r.display_background || "");
        currentBg = (roundBg.trim() !== "" ? roundBg : gameBg.trim()) || currentBg;
        state.start = r.timer_start ? Math.floor(new Date(r.timer_start).getTime() / 1000) : 0;
        state.end = r.timer_end ? Math.floor(new Date(r.timer_end).getTime() / 1000) : 0;
        state.running = !!r.timer_running;
        state.limit = Number(r.time_limit_minutes || 0) * 60;
        state.completed = !!r.completed;
        state.showPods = !!r.display_show_pods;
        state.podsTotal = Number(r.pods_total || 0);
        state.podsSaved = Number(r.pods_saved || 0);
        state.podsLocked = Number(r.pods_locked || 0);
        state.podsStatus = Array.isArray(r.pods_status) ? r.pods_status : [];
        state.showResults = !!r.display_show_results;
        state.results = Array.isArray(r.results) ? r.results : [];
        render();
      } catch (_) {
      }
    }

    render();
    setInterval(poll, 3000);
    setInterval(render, 1000);
  })();
  </script>
</body>
</html>
