<h3 class="mb-3">Games</h3>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-body">
        <div class="fw-semibold mb-2">Create a New Game</div>

        <form method="post" action="?r=admin/createGame">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">

          <div class="mb-2">
            <label class="form-label">Game Name</label>
            <input class="form-control" name="name" placeholder="Optional">
          </div>

          <div class="mb-2">
            <label class="form-label">Select Players (email as ID)</label>
            <div class="form-text mb-2">Hold Ctrl to select multiple.</div>
            <select class="form-select" name="players[]" multiple size="10">
              <?php foreach ($players as $email => $p): ?>
                <option value="<?php echo e($email); ?>"><?php echo e($p['name']); ?> (<?php echo e($email); ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>

          <button class="btn btn-primary">Create Game</button>
        </form>

        <?php if (empty($players)): ?>
          <div class="alert alert-info mt-3">No players yet. You can still create a game and add players later.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-body">
        <div class="fw-semibold mb-2">Existing Games</div>

        <?php if (empty($games)): ?>
          <div class="text-muted">No games yet.</div>
        <?php else: ?>
          <div class="list-group">
            <?php foreach ($games as $g): ?>
              <?php $isActive = ($g['is_active'] ?? true); ?>
              <div class="list-group-item d-flex justify-content-between align-items-start gap-2">
                <a class="text-decoration-none text-reset flex-grow-1"
                   href="?r=admin/viewGame&id=<?php echo e($g['id']); ?>">
                  <div class="d-flex justify-content-between">
                    <div>
                      <div class="fw-semibold"><?php echo e($g['name']); ?></div>
                      <div class="small text-muted">Players: <?php echo count((array)$g['players']); ?> | Rounds: <?php echo count((array)$g['rounds']); ?></div>
                    </div>
                    <span class="badge text-bg-<?php echo $isActive ? ((($g['status'] ?? '') === 'ended') ? 'secondary' : 'success') : 'secondary'; ?>">
                      <?php echo e($isActive ? ($g['status'] ?? '') : 'inactive'); ?>
                    </span>
                  </div>
                </a>
                <div class="d-flex gap-2">
                  <form method="post" action="?r=admin/setGameActive">
                    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                    <input type="hidden" name="id" value="<?php echo e($g['id']); ?>">
                    <input type="hidden" name="active" value="<?php echo $isActive ? '0' : '1'; ?>">
                    <button class="btn btn-outline-secondary btn-sm">
                      <?php echo $isActive ? 'Deactivate' : 'Activate'; ?>
                    </button>
                  </form>
                  <form method="post" action="?r=admin/deleteGame">
                    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                    <input type="hidden" name="id" value="<?php echo e($g['id']); ?>">
                    <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete this game?');">Delete</button>
                  </form>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
