<?php
$players = (array)($game['players'] ?? []);
$rounds  = (array)($game['rounds'] ?? []);
$status  = (string)($game['status'] ?? 'active');
$allPlayers = array_keys($playersMeta);
$playersLower = array_map('strtolower', $players);
$availablePlayers = array_values(array_filter($allPlayers, function ($email) use ($playersLower) {
  return !in_array(strtolower($email), $playersLower, true);
}));
?>
<div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
  <div>
    <h3 class="mb-1"><?php echo e($game['name']); ?></h3>
    <div class="small text-muted"><span class="fw-semibold">ID:</span> <?php echo e($game['id']); ?></div>
    <div class="small text-muted"><span class="fw-semibold">Status:</span> <span class="badge text-bg-<?php echo $status==='ended'?'secondary':'success'; ?>"><?php echo e($status); ?></span></div>
    <div class="small text-muted"><span class="fw-semibold">Date Created:</span> <?php echo e((string)($game['created_at'] ?? '')); ?></div>
    <div class="small text-muted"><span class="fw-semibold">Date Completed:</span> <?php echo e((string)($game['ended_at'] ?? '')); ?></div>
    <div class="small text-muted"><span class="fw-semibold">No. of Players:</span> <?php echo count($players); ?></div>
    <div class="small text-muted"><span class="fw-semibold">Rounds:</span> <?php echo count($rounds); ?></div>
  </div>

  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-lg fw-bold" href="?r=admin/reports&id=<?php echo e($game['id']); ?>">Reports</a>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Add Players to Game</div>
    <hr class="mt-0 mb-3">

    <?php if ($status !== 'active'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1">Game ended. Players cannot be added.</div>
    <?php elseif (empty($allPlayers)): ?>
      <div class="text-muted">No players yet. Add players in Admin &rarr; Players.</div>
    <?php elseif (empty($availablePlayers)): ?>
      <div class="text-muted">All players are already in this game.</div>
    <?php else: ?>
      <form method="post" action="?r=admin/addGamePlayers" class="row g-2 align-items-end">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">

        <div class="col-md-9">
          <label class="form-label">Select Players to Add</label>
          <select class="form-select" name="players[]" multiple size="8">
            <?php foreach ($availablePlayers as $email): ?>
              <?php $p = $playersMeta[$email] ?? ['name' => $email]; ?>
              <option value="<?php echo e($email); ?>"><?php echo e($p['name']); ?> (<?php echo e($email); ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3">
          <button class="btn btn-primary w-100">Add Players</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Display Background (Secondary Screen)</div>
    <hr class="mt-0 mb-3">
    <form method="post" action="?r=admin/uploadDisplayBackground" enctype="multipart/form-data" class="row g-2 align-items-end">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <div class="col-md-8">
        <label class="form-label">Upload Background (PNG/JPG/WEBP)</label>
        <input class="form-control" type="file" name="background_file" accept=".png,.jpg,.jpeg,.webp" required <?php echo $status === 'ended' ? 'disabled' : ''; ?>>
        <?php if (!empty($game['display_background'])): ?>
          <div class="small text-muted mt-1">Current: <?php echo e((string)$game['display_background']); ?></div>
        <?php endif; ?>
      </div>
      <div class="col-md-4">
        <button class="btn btn-outline-secondary w-100" <?php echo $status === 'ended' ? 'disabled' : ''; ?>>Upload Background</button>
      </div>
    </form>
    <?php if ($status === 'ended'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1 mt-2">GAME ENDED. NO MORE CHANGES.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Sponsor Banner (Display Only)</div>
    <hr class="mt-0 mb-3">
    <form method="post" action="?r=admin/uploadSponsorBanner" enctype="multipart/form-data" class="row g-2 align-items-end">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <div class="col-md-8">
        <label class="form-label">Upload Banner (PNG/JPG/WEBP)</label>
        <input class="form-control" type="file" name="sponsor_file" accept=".png,.jpg,.jpeg,.webp" required <?php echo $status === 'ended' ? 'disabled' : ''; ?>>
        <?php if (!empty($game['sponsor_banner'])): ?>
          <div class="small text-muted mt-1">Current: <?php echo e((string)$game['sponsor_banner']); ?></div>
        <?php endif; ?>
      </div>
      <div class="col-md-4">
        <button class="btn btn-outline-secondary w-100" <?php echo $status === 'ended' ? 'disabled' : ''; ?>>Upload Banner</button>
      </div>
    </form>
    <?php if ($status === 'ended'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1 mt-2">GAME ENDED. NO MORE CHANGES.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Create New Round</div>
    <hr class="mt-0 mb-3">

    <?php if ($status !== 'active'): ?>
      <div class="small fst-italic text-white bg-danger rounded text-center py-1">Game ended. No more rounds can be created.</div>
    <?php else: ?>
      <form method="post" action="?r=admin/createRound" class="row g-2 align-items-end">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">

        <div class="col-md-6">
          <label class="form-label">Pairing Mode</label>
          <select class="form-select" name="pairing_mode">
            <option value="ranking_top4">A) Ranking: top 4 per pod (table order)</option>
            <option value="ranking_highlow">B) Ranking: 2 highest + 2 lowest per pod</option>
            <option value="swiss_pods">C) Swiss Pods (recommended)</option>
            <option value="true_swiss">D) True Swiss</option>
            <option value="power_pods">E) Power Pods</option>
            <option value="bubble_pods">F) Bubble Pods</option>
            <option value="random_pods">G) Random Pods (avoid repeats)</option>
            <option value="top1_low3">H) Highest 1 vs Lowest 3</option>
            <option value="alpha_no_repeat">I) Alphabetical (tries to avoid repeats)</option>
          </select>
          <div class="form-text">
            Note: “avoid repeats” is best-effort when later rounds make perfect avoidance impossible.
          </div>
        </div>

        <div class="col-md-3">
          <button class="btn btn-primary w-100">Create Round</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="section-title">Current Ranking (Tie-break rules applied)</div>
    <hr class="mt-0 mb-3">

    <div class="table-responsive">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>Player</th>
            <th>Total Score</th>
            <th>Total Wins Points</th>
            <th>Win Rate</th>
            <th>Match-win %</th>
            <th>Game-win %</th>
            <th>OWP</th>
            <th>OGP</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach (($standings['ranked'] ?? []) as $i => $r): ?>
            <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
            <tr>
              <td><?php echo $i+1; ?></td>
              <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span></td>
              <td><?php echo (int)$r['total_score']; ?></td>
              <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
              <td><?php echo number_format((float)$r['win_rate'], 3); ?></td>
              <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
              <td><?php echo number_format((float)$r['owp'], 3); ?></td>
              <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($standings['ranked'])): ?>
            <tr><td colspan="9" class="text-muted">No standings yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="section-title">Rounds</div>
    <hr class="mt-0 mb-3">

    <?php if (empty($rounds)): ?>
      <div class="text-muted">No rounds created yet.</div>
    <?php else: ?>
      <div class="list-group">
        <?php $lastRoundNum = count($rounds); ?>
        <?php foreach ($rounds as $r): ?>
          <a class="list-group-item list-group-item-action"
             href="<?php echo $status === 'ended' ? ('?r=admin/reports&id=' . e($game['id'])) : ('?r=admin/viewRound&id=' . e($game['id']) . '&round=' . (int)$r['number']); ?>">
            <div class="d-flex justify-content-between">
              <div>
                <div class="fw-semibold">Round <?php echo (int)$r['number']; ?></div>
                <div class="small text-muted">Mode: <?php echo e($r['pairing_mode']); ?> · Pods: <?php echo count((array)$r['pods']); ?></div>
              </div>
              <div class="d-flex align-items-center gap-2">
                <div class="small text-muted"><?php echo e($r['created_at'] ?? ''); ?></div>
                <?php if ((int)$r['number'] === $lastRoundNum && empty($r['timer_start'])): ?>
                  <form method="post" action="?r=admin/deleteRound" onsubmit="return confirm('Delete this round?');">
                    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                    <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
                    <input type="hidden" name="round" value="<?php echo (int)$r['number']; ?>">
                    <button class="btn btn-outline-danger btn-sm">Delete</button>
                  </form>
                <?php endif; ?>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php if ($status === 'ended'): ?>
  <div class="d-flex justify-content-start mt-3">
    <form method="post" action="?r=admin/reopenGame" onsubmit="return confirm('Reopen this game? This will allow changes again.');">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
      <button class="btn btn-success btn-lg fw-bold">Reopen Game</button>
    </form>
  </div>
<?php endif; ?>
