<?php
// app/Views/admin/users.php
?>

<h3 class="mb-3">User Management</h3>

<div class="card mb-3">
  <div class="card-body">
    <div class="fw-semibold mb-3">Create User</div>

    <form method="post" action="?r=admin/createUser">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">

      <div class="row g-3 align-items-end">
        <div class="col-12 col-lg-3">
          <label class="form-label">Email</label>
          <input class="form-control" name="email" type="email" required>
        </div>

        <div class="col-12 col-lg-3">
          <label class="form-label">Name</label>
          <input class="form-control" name="name" type="text" placeholder="Optional">
        </div>

        <div class="col-12 col-lg-2">
          <label class="form-label">Role</label>
          <select class="form-select" name="role">
            <option value="player">Player</option>
            <option value="admin">Admin</option>
          </select>
        </div>

        <div class="col-12 col-lg-2">
          <label class="form-label">Password</label>
          <input class="form-control" name="password" type="text" minlength="6" required>
        </div>

        <div class="col-12 col-lg-2">
          <div class="d-grid">
            <button class="btn btn-primary" type="submit">Create</button>
          </div>
        </div>
      </div>

      <!-- moved OUTSIDE the row so it won't push the password input up -->
      <div class="d-flex flex-wrap align-items-center gap-3 mt-2">
        <div class="form-text">Password must be at least 6 characters.</div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" name="add_to_players" id="addPlayers" value="1">
          <label class="form-check-label" for="addPlayers">Also add to Players list</label>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
(() => {
  const table = document.querySelector(".users-table");
  if (!table) return;
  const searchInput = document.getElementById("userSearch");
  const clearBtn = document.getElementById("clearUserFilters");
  const filters = table.querySelectorAll("[data-filter]");
  const rows = Array.from(table.querySelectorAll("tbody tr"))
    .filter((row) => row.dataset.email !== undefined);

  function norm(val) {
    return String(val || "").toLowerCase();
  }

  function applyFilters() {
    const search = norm(searchInput.value);
    const filterMap = {};
    filters.forEach((el) => {
      filterMap[el.dataset.filter] = norm(el.value);
    });

    rows.forEach((row) => {
      const email = norm(row.dataset.email);
      const name = norm(row.dataset.name);
      const role = norm(row.dataset.role);
      const status = norm(row.dataset.status);

      const matchesSearch =
        search === "" ||
        email.includes(search) ||
        name.includes(search) ||
        role.includes(search) ||
        status.includes(search);

      const matchesEmail = filterMap.email === "" || email.includes(filterMap.email);
      const matchesName = filterMap.name === "" || name.includes(filterMap.name);
      const matchesRole = filterMap.role === "" || role === filterMap.role;
      const matchesStatus = filterMap.status === "" || status === filterMap.status;

      row.classList.toggle(
        "d-none",
        !(matchesSearch && matchesEmail && matchesName && matchesRole && matchesStatus)
      );
    });
  }

  searchInput.addEventListener("input", applyFilters);
  filters.forEach((el) => el.addEventListener("input", applyFilters));
  filters.forEach((el) => el.addEventListener("change", applyFilters));
  clearBtn.addEventListener("click", () => {
    searchInput.value = "";
    filters.forEach((el) => { el.value = ""; });
    applyFilters();
  });
})();
</script>

<?php if (!empty($playersWithoutAccounts)): ?>
  <div class="card mb-3">
    <div class="card-body">
      <div class="fw-semibold mb-2">Players without Login Accounts</div>
      <div class="small text-muted mb-3">
        These players exist in <code>players.json</code> (ex: CSV import), but have no <code>users.json</code> account yet.
      </div>

      <div class="list-group">
        <?php foreach ($playersWithoutAccounts as $email => $p): ?>
          <?php $pname = (string)($p['name'] ?? $email); ?>

          <div class="list-group-item">
            <form method="post" action="?r=admin/createUser" class="row g-2 align-items-end">
              <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
              <input type="hidden" name="email" value="<?php echo e($email); ?>">
              <input type="hidden" name="name" value="<?php echo e($pname); ?>">
              <input type="hidden" name="role" value="player">

              <div class="col-12 col-lg-5">
                <div class="fw-semibold"><?php echo e($pname); ?></div>
                <div class="small text-muted"><?php echo e($email); ?></div>
              </div>

              <div class="col-12 col-lg-4">
                <label class="form-label">Password</label>
                <input class="form-control form-control-sm" name="password" type="text" minlength="6" placeholder="Set password" required>
                <div class="form-text">Min 6 chars.</div>
              </div>

              <div class="col-12 col-lg-3">
                <div class="d-grid">
                  <button class="btn btn-sm btn-success" type="submit">Create Account</button>
                </div>
              </div>
            </form>
          </div>

        <?php endforeach; ?>
      </div>
    </div>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <div class="fw-semibold mb-2">All Users</div>

    <div class="row g-2 align-items-end mb-2">
      <div class="col-12 col-lg-6">
        <label class="form-label">Search</label>
        <input class="form-control form-control-sm" type="search" id="userSearch" placeholder="Search email, name, role, status">
      </div>
      <div class="col-12 col-lg-2">
        <button class="btn btn-outline-secondary btn-sm w-100" type="button" id="clearUserFilters">Clear Filters</button>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-sm align-middle users-table" style="table-layout: fixed;">
        <colgroup>
          <col style="width: 28%">
          <col style="width: 18%">
          <col style="width: 18%">
          <col style="width: 10%">
          <col style="width: 26%">
        </colgroup>
        <thead>
          <tr>
            <th>Email</th>
            <th>Name</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
          <tr>
            <th><input class="form-control form-control-sm" type="text" data-filter="email" placeholder="Filter email"></th>
            <th><input class="form-control form-control-sm" type="text" data-filter="name" placeholder="Filter name"></th>
            <th>
              <select class="form-select form-select-sm" data-filter="role">
                <option value="">All</option>
                <option value="admin">Admin</option>
                <option value="player">Player</option>
              </select>
            </th>
            <th>
              <select class="form-select form-select-sm" data-filter="status">
                <option value="">All</option>
                <option value="active">Active</option>
                <option value="disabled">Disabled</option>
              </select>
            </th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($users)): ?>
            <tr><td colspan="5" class="text-muted">No users found.</td></tr>
          <?php else: ?>
            <?php foreach ($users as $email => $u): ?>
              <?php
                $role = (string)($u['role'] ?? '');
                $disabled = !empty($u['disabled']);
              ?>
              <tr data-email="<?php echo e($email); ?>"
                  data-name="<?php echo e((string)($u['name'] ?? $email)); ?>"
                  data-role="<?php echo e($role); ?>"
                  data-status="<?php echo $disabled ? 'disabled' : 'active'; ?>">
                <td class="text-break"><?php echo e($email); ?></td>

                <td class="text-break"><?php echo e((string)($u['name'] ?? $email)); ?></td>

                <td>
                  <form method="post" action="?r=admin/updateUserRole" class="d-flex align-items-center gap-2 flex-nowrap m-0">
                    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">

                    <select class="form-select form-select-sm" name="role" style="width: 140px;">
                      <option value="player" <?php echo $role==='player'?'selected':''; ?>>Player</option>
                      <option value="admin" <?php echo $role==='admin'?'selected':''; ?>>Admin</option>
                    </select>

                    <button class="btn btn-sm btn-outline-primary" type="submit">Save</button>
                  </form>
                </td>

                <td>
                  <?php if ($disabled): ?>
                    <span class="badge text-bg-secondary">Disabled</span>
                  <?php else: ?>
                    <span class="badge text-bg-success">Active</span>
                  <?php endif; ?>
                </td>

                <td>
                  <div class="d-flex align-items-center gap-2 flex-nowrap">
                    <form method="post" action="?r=admin/resetUserPassword" class="m-0">
                      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                      <input type="hidden" name="email" value="<?php echo e($email); ?>">

                      <div class="input-group input-group-sm" style="width: 240px;">
                        <input class="form-control" name="password" type="text" minlength="6" placeholder="New password" required>
                        <button class="btn btn-outline-warning" type="submit">Reset</button>
                      </div>
                    </form>

                    <form method="post" action="?r=admin/toggleUserDisabled" class="m-0">
                      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                      <input type="hidden" name="email" value="<?php echo e($email); ?>">
                      <button class="btn btn-sm btn-outline-danger" type="submit" style="min-width: 92px;">
                        <?php echo $disabled ? 'Enable' : 'Disable'; ?>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="form-text mt-2">
      Safety rules: you can’t disable yourself, you can’t demote yourself, and you can’t remove/disable the last active admin.
    </div>
  </div>
</div>
