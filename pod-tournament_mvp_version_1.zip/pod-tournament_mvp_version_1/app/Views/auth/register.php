<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5">
    <h3 class="mb-3">Player Registration</h3>

    <form method="post">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">

      <div class="mb-2">
        <label class="form-label">Email (used as Player ID)</label>
        <input class="form-control" name="email" type="email" required>
      </div>

      <div class="mb-2">
        <label class="form-label">Name</label>
        <input class="form-control" name="name" type="text" placeholder="Optional">
      </div>

      <div class="mb-3">
        <label class="form-label">Password</label>
        <input class="form-control" name="password" type="password" required>
        <div class="form-text">Minimum 6 characters.</div>
      </div>

      <button class="btn btn-success w-100">Create account</button>
    </form>
  </div>
</div>
