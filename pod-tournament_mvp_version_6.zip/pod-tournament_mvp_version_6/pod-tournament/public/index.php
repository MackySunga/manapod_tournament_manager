<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../app/bootstrap.php';

use App\Core\Router;

$route = (string)($_GET['r'] ?? 'auth/login');

$router = new Router();
$router->dispatch($route);
