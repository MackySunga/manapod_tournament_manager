// public/assets/theme.js
(() => {
  const STORAGE_KEY = "pt_theme";

  function preferredTheme() {
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  }

  function getTheme() {
    return localStorage.getItem(STORAGE_KEY) || preferredTheme();
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-bs-theme", theme);

    const btn = document.getElementById("themeToggle");
    if (btn) {
      btn.textContent = theme === "dark" ? "Light mode" : "Dark mode";
      btn.setAttribute("aria-pressed", theme === "dark" ? "true" : "false");
    }
  }

  function toggleTheme() {
    const current = document.documentElement.getAttribute("data-bs-theme") || "light";
    const next = current === "dark" ? "light" : "dark";
    localStorage.setItem(STORAGE_KEY, next);
    applyTheme(next);
  }

  // Apply theme immediately
  applyTheme(getTheme());

  // Bind button click
  document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("themeToggle");
    if (!btn) return;
    btn.addEventListener("click", toggleTheme);
  });

  document.addEventListener("DOMContentLoaded", () => {
    const nodes = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    nodes.forEach((el) => {
      if (typeof bootstrap !== "undefined" && bootstrap.Tooltip) {
        new bootstrap.Tooltip(el);
      }
    });
  });
})();
