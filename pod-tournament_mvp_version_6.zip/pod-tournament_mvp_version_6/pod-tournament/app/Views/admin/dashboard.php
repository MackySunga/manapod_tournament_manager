<h3 class="mb-3">Admin Dashboard</h3>

<div class="row g-3">
  <div class="col-md-4">
    <div class="card">
      <div class="card-body">
        <div class="dashboard-title title-blue px-2 py-1 rounded">Total Players</div>
        <hr class="mt-2 mb-3">
        <div class="display-6"><?php echo (int)$playerCount; ?></div>
        <a class="btn btn-sm btn-outline-primary mt-2" href="?r=admin/users">Manage Users</a>
      </div>
    </div>
  </div>

  <div class="col-md-8">
    <div class="card">
      <div class="card-body">
        <div class="dashboard-title mb-2 title-blue px-2 py-1 rounded">Games</div>
        <hr class="mt-2 mb-3">
        <?php if (empty($games)): ?>
          <div class="text-muted">No games yet.</div>
        <?php else: ?>
          <?php
            $activeGames = [];
            $completedGames = [];
            $suspendedGames = [];
            foreach ($games as $g) {
              $isActive = ($g['is_active'] ?? true);
              $status = (string)($g['status'] ?? '');
              if ($status === 'ended') {
                $completedGames[] = $g;
              } elseif ($isActive) {
                $activeGames[] = $g;
              } else {
                $suspendedGames[] = $g;
              }
            }
          ?>

          <div class="games-group-scroll mb-3">
            <div class="games-group-header games-group-header--active">Active</div>
            <div class="list-group">
              <?php if (empty($activeGames)): ?>
                <div class="list-group-item text-muted">No active games.</div>
              <?php else: ?>
                <?php foreach ($activeGames as $g): ?>
                  <a class="list-group-item list-group-item-action"
                     href="?r=admin/viewGame&id=<?php echo e($g['id']); ?>">
                    <div class="d-flex justify-content-between">
                      <div>
                        <div class="fw-semibold"><?php echo e($g['name']); ?></div>
                        <div class="small text-muted"><?php echo e($g['id']); ?> · Players: <?php echo count((array)$g['players']); ?></div>
                      </div>
                      <span class="badge text-bg-success"><?php echo e($g['status'] ?? 'active'); ?></span>
                    </div>
                  </a>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <div class="games-group-scroll mb-3">
            <div class="games-group-header games-group-header--completed">Completed</div>
            <div class="list-group">
              <?php if (empty($completedGames)): ?>
                <div class="list-group-item text-muted">No completed games.</div>
              <?php else: ?>
                <?php foreach ($completedGames as $g): ?>
                  <a class="list-group-item list-group-item-action"
                     href="?r=admin/viewGame&id=<?php echo e($g['id']); ?>">
                    <div class="d-flex justify-content-between">
                      <div>
                        <div class="fw-semibold"><?php echo e($g['name']); ?></div>
                        <div class="small text-muted"><?php echo e($g['id']); ?> · Players: <?php echo count((array)$g['players']); ?></div>
                      </div>
                      <span class="badge text-bg-secondary">ended</span>
                    </div>
                  </a>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <div class="games-group-scroll">
            <div class="games-group-header games-group-header--suspended">Suspended</div>
            <div class="list-group">
              <?php if (empty($suspendedGames)): ?>
                <div class="list-group-item text-muted">No suspended games.</div>
              <?php else: ?>
                <?php foreach ($suspendedGames as $g): ?>
                  <a class="list-group-item list-group-item-action"
                     href="?r=admin/viewGame&id=<?php echo e($g['id']); ?>">
                    <div class="d-flex justify-content-between">
                      <div>
                        <div class="fw-semibold"><?php echo e($g['name']); ?></div>
                        <div class="small text-muted"><?php echo e($g['id']); ?> · Players: <?php echo count((array)$g['players']); ?></div>
                      </div>
                      <span class="badge text-bg-secondary">inactive</span>
                    </div>
                  </a>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php
$gameCount = count($games);
$activeCount = 0;
$endedCount = 0;
$inactiveCount = 0;
$roundCount = 0;
$completedRounds = 0;
$podCount = 0;
$totalPlayers = 0;
$modeCounts = [];

foreach ($games as $g) {
  $isActive = ($g['is_active'] ?? true);
  $status = (string)($g['status'] ?? '');
  if (!$isActive) {
    $inactiveCount++;
  } elseif ($status === 'ended') {
    $endedCount++;
  } else {
    $activeCount++;
  }

  $playersInGame = count((array)($g['players'] ?? []));
  $totalPlayers += $playersInGame;

  $rounds = (array)($g['rounds'] ?? []);
  $roundCount += count($rounds);
  foreach ($rounds as $r) {
    if (!empty($r['completed'])) $completedRounds++;
    $pods = (array)($r['pods'] ?? []);
    $podCount += count($pods);
    $mode = (string)($r['pairing_mode'] ?? '');
    if ($mode !== '') {
      $modeCounts[$mode] = (int)($modeCounts[$mode] ?? 0) + 1;
    }
  }
}

$avgPlayers = $gameCount > 0 ? ($totalPlayers / $gameCount) : 0;
$avgRounds = $gameCount > 0 ? ($roundCount / $gameCount) : 0;
$avgPodsPerRound = $roundCount > 0 ? ($podCount / $roundCount) : 0;
$completedRate = $roundCount > 0 ? ($completedRounds / $roundCount) : 0;
arsort($modeCounts);
?>

<div class="card mt-3">
  <div class="card-body">
    <div class="dashboard-title mb-2 title-blue px-2 py-1 rounded">All Games Stats</div>
    <hr class="mt-2 mb-3">

    <div class="row g-3">
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-bold mb-2 title-blue-light px-2 py-1 rounded">Totals</div>
            <hr class="mt-0 mb-2">
            <div>Games: <?php echo $gameCount; ?></div>
            <div>Players (sum): <?php echo $totalPlayers; ?></div>
            <div>Rounds: <?php echo $roundCount; ?></div>
            <div>Pods: <?php echo $podCount; ?></div>
          </div>
        </div>
      </div>

      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-bold mb-2 title-blue-light px-2 py-1 rounded">Averages</div>
            <hr class="mt-0 mb-2">
            <div>Avg players per game: <?php echo number_format($avgPlayers, 2); ?></div>
            <div>Avg rounds per game: <?php echo number_format($avgRounds, 2); ?></div>
            <div>Avg pods per round: <?php echo number_format($avgPodsPerRound, 2); ?></div>
            <div>Round completion rate: <?php echo number_format($completedRate * 100, 1); ?>%</div>
          </div>
        </div>
      </div>

      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-bold mb-2 title-blue-light px-2 py-1 rounded">Game Status</div>
            <hr class="mt-0 mb-2">
            <?php
              $totalForStatus = max(1, $gameCount);
              $statusRows = [
                'Active' => $activeCount,
                'Ended' => $endedCount,
                'Inactive' => $inactiveCount,
              ];
            ?>
            <?php foreach ($statusRows as $label => $count): ?>
              <?php $pct = ($count / $totalForStatus) * 100; ?>
              <div class="d-flex justify-content-between small">
                <span><?php echo e($label); ?></span>
                <span><?php echo $count; ?></span>
              </div>
              <div class="stat-bar mb-2"><span style="width: <?php echo $pct; ?>%;"></span></div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-3 mt-1">
      <div class="col-lg-6">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-bold mb-2 title-blue-light px-2 py-1 rounded">Pairing Mode Usage (Top 6)</div>
            <hr class="mt-0 mb-2">
            <?php if (empty($modeCounts)): ?>
              <div class="text-muted">No rounds yet.</div>
            <?php else: ?>
              <?php
                $topModes = array_slice($modeCounts, 0, 6, true);
                $totalModes = max(1, array_sum($modeCounts));
              ?>
              <?php foreach ($topModes as $mode => $count): ?>
                <?php $pct = ($count / $totalModes) * 100; ?>
                <div class="d-flex justify-content-between small">
                  <span><?php echo e($mode); ?></span>
                  <span><?php echo $count; ?></span>
                </div>
                <div class="stat-bar mb-2"><span style="width: <?php echo $pct; ?>%;"></span></div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="card h-100">
          <div class="card-body">
            <div class="fw-bold mb-2 title-blue-light px-2 py-1 rounded">Round Progress</div>
            <hr class="mt-0 mb-2">
            <?php
              $completedPct = $roundCount > 0 ? ($completedRounds / $roundCount) * 100 : 0;
              $remainingPct = 100 - $completedPct;
            ?>
            <div class="d-flex justify-content-between small">
              <span>Completed rounds</span>
              <span><?php echo $completedRounds; ?> / <?php echo $roundCount; ?></span>
            </div>
            <div class="stat-bar mb-2"><span style="width: <?php echo $completedPct; ?>%;"></span></div>
            <div class="d-flex justify-content-between small">
              <span>In-progress rounds</span>
              <span><?php echo max(0, $roundCount - $completedRounds); ?></span>
            </div>
            <div class="stat-bar mb-2"><span style="width: <?php echo $remainingPct; ?>%;"></span></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
