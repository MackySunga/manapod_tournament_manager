<div id="games-header"><h3 class="mb-3">Games</h3></div>

<div id="games-main">
<div class="row g-3">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-body">
        <div class="fw-semibold mb-2 text-white bg-success rounded px-2 py-1">Create a New Game</div>

        <form method="post" action="?r=admin/createGame" data-ajax="1">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">

          <hr class="mt-2 mb-3">
          <div class="mb-2">
            <label class="form-label">Game Name</label>
            <input class="form-control" name="name" placeholder="Optional">
          </div>

          <div class="mb-2">
            <label class="form-label">Game Mode</label>
            <?php
              $allowedGameModes = [
                'MULTI PLAYER',
                'One V One (BO3-SWISS)',
              ];
            ?>
            <select class="form-select" name="game_mode">
              <?php foreach ($allowedGameModes as $mode): ?>
                <option value="<?php echo e($mode); ?>"><?php echo e($mode); ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-2">
            <label class="form-label">Score System</label>
            <?php
              $allowedScoreSystems = [
                'Point System (Limited)',
                'Point System (Unlimited)',
              ];
            ?>
            <select class="form-select" name="score_system" id="scoreSystemSelect">
              <?php foreach ($allowedScoreSystems as $system): ?>
                <option value="<?php echo e($system); ?>"><?php echo e($system); ?></option>
              <?php endforeach; ?>
            </select>
            <div class="form-text d-none" id="scoreSystemLockedNote">Score System is fixed to Point System (Limited) for One V One (BO3-SWISS).</div>
          </div>

          <div class="mb-2">
            <label class="form-label">Game Description</label>
            <textarea class="form-control" name="description" rows="3" placeholder="Short narrative about this tournament."></textarea>
          </div>

          <hr class="mt-2 mb-3">
          <div class="mb-2">
            <div class="fw-semibold mb-2 text-white bg-success rounded px-2 py-1">Select Players (email as ID)</div>
            <hr class="mt-0 mb-2">
            <div class="form-text mb-2">Tick the players you want to include. You can leave this empty.</div>
            <div class="d-flex gap-2 mb-2">
              <button type="button" class="btn btn-success btn-sm" data-select-all="players">Select All</button>
              <button type="button" class="btn btn-warning btn-sm" data-clear-all="players">Clear All</button>
            </div>
            <div class="mb-2" style="max-width: 320px;">
              <input class="form-control form-control-sm" type="search" placeholder="Search players..." data-player-search>
            </div>
            <div class="table-responsive" style="max-height: 320px;">
              <table class="table table-sm align-middle mb-0">
                <thead>
                  <tr>
                    <th style="width: 40px;"></th>
                    <th>Player</th>
                    <th>Email</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($players as $email => $p): ?>
                    <tr data-player-row data-player-name="<?php echo e($p['name']); ?>" data-player-email="<?php echo e($email); ?>">
                      <td>
                        <input class="form-check-input" type="checkbox" name="players[]" value="<?php echo e($email); ?>">
                      </td>
                      <td><?php echo e($p['name']); ?></td>
                      <td class="text-muted"><?php echo e($email); ?></td>
                    </tr>
                  <?php endforeach; ?>
                  <?php if (empty($players)): ?>
                    <tr><td colspan="3" class="text-muted">No players yet.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <button class="btn btn-primary" onclick="return confirm('Are you sure you want to create this game?');">Create Game</button>
        </form>

        <?php if (empty($players)): ?>
          <div class="alert alert-info mt-3">No players yet. You can still create a game and add players later.</div>
        <?php endif; ?>
      </div>
  </div>
</div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-body">
        <div class="fw-semibold mb-2 text-white bg-success rounded px-2 py-1">Existing Games</div>
        <hr class="mt-0 mb-3">

        <?php if (empty($games)): ?>
          <div class="text-muted">No games yet.</div>
        <?php else: ?>
          <?php
            $activeGames = [];
            $completedGames = [];
            $suspendedGames = [];
            foreach ($games as $g) {
              $isActive = ($g['is_active'] ?? true);
              $status = (string)($g['status'] ?? '');
              if ($status === 'ended') {
                $completedGames[] = $g;
              } elseif ($isActive) {
                $activeGames[] = $g;
              } else {
                $suspendedGames[] = $g;
              }
            }
          ?>

          <div class="games-group-scroll mb-3">
            <div class="games-group-header games-group-header--active">Active</div>
            <div class="list-group">
              <?php if (empty($activeGames)): ?>
                <div class="list-group-item text-muted">No active games.</div>
              <?php else: ?>
                <?php foreach ($activeGames as $g): ?>
                  <?php $isActive = ($g['is_active'] ?? true); ?>
                  <div class="list-group-item d-flex justify-content-between align-items-start gap-2">
                    <a class="text-decoration-none text-reset flex-grow-1"
                       href="?r=admin/viewGame&id=<?php echo e($g['id']); ?>">
                      <div class="d-flex justify-content-between">
                        <div>
                          <div class="fw-semibold"><?php echo e($g['name']); ?></div>
                          <div class="small text-muted">Players: <?php echo count((array)$g['players']); ?> | Rounds: <?php echo count((array)$g['rounds']); ?></div>
                        </div>
                        <span class="badge text-bg-success"><?php echo e($g['status'] ?? 'active'); ?></span>
                      </div>
                    </a>
                    <div class="d-flex gap-2">
                      <form method="post" action="?r=admin/setGameActive" data-ajax="1">
                        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                        <input type="hidden" name="id" value="<?php echo e($g['id']); ?>">
                        <input type="hidden" name="active" value="<?php echo $isActive ? '0' : '1'; ?>">
                        <button class="btn btn-outline-secondary btn-sm">Deactivate</button>
                      </form>
                      <form method="post" action="?r=admin/deleteGame" data-confirm="Delete this game?" data-ajax="1">
                        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                        <input type="hidden" name="id" value="<?php echo e($g['id']); ?>">
                        <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete this game?');">Delete</button>
                      </form>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <div class="games-group-scroll mb-3">
            <div class="games-group-header games-group-header--completed">Completed</div>
            <div class="list-group">
              <?php if (empty($completedGames)): ?>
                <div class="list-group-item text-muted">No completed games.</div>
              <?php else: ?>
                <?php foreach ($completedGames as $g): ?>
                  <div class="list-group-item d-flex justify-content-between align-items-start gap-2">
                    <a class="text-decoration-none text-reset flex-grow-1"
                       href="?r=admin/viewGame&id=<?php echo e($g['id']); ?>">
                      <div class="d-flex justify-content-between">
                        <div>
                          <div class="fw-semibold"><?php echo e($g['name']); ?></div>
                          <div class="small text-muted">Players: <?php echo count((array)$g['players']); ?> | Rounds: <?php echo count((array)$g['rounds']); ?></div>
                        </div>
                        <span class="badge text-bg-secondary">ended</span>
                      </div>
                    </a>
                    <div class="d-flex gap-2">
                      <form method="post" action="?r=admin/deleteGame" data-confirm="Delete this game?" data-ajax="1">
                        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                        <input type="hidden" name="id" value="<?php echo e($g['id']); ?>">
                        <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete this game?');">Delete</button>
                      </form>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <div class="games-group-scroll">
            <div class="games-group-header games-group-header--suspended">Suspended</div>
            <div class="list-group">
              <?php if (empty($suspendedGames)): ?>
                <div class="list-group-item text-muted">No suspended games.</div>
              <?php else: ?>
                <?php foreach ($suspendedGames as $g): ?>
                  <?php $isActive = ($g['is_active'] ?? true); ?>
                  <div class="list-group-item d-flex justify-content-between align-items-start gap-2">
                    <a class="text-decoration-none text-reset flex-grow-1"
                       href="?r=admin/viewGame&id=<?php echo e($g['id']); ?>">
                      <div class="d-flex justify-content-between">
                        <div>
                          <div class="fw-semibold"><?php echo e($g['name']); ?></div>
                          <div class="small text-muted">Players: <?php echo count((array)$g['players']); ?> | Rounds: <?php echo count((array)$g['rounds']); ?></div>
                        </div>
                        <span class="badge text-bg-secondary">inactive</span>
                      </div>
                    </a>
                    <div class="d-flex gap-2">
                      <form method="post" action="?r=admin/setGameActive" data-ajax="1">
                        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                        <input type="hidden" name="id" value="<?php echo e($g['id']); ?>">
                        <input type="hidden" name="active" value="<?php echo $isActive ? '0' : '1'; ?>">
                        <button class="btn btn-outline-secondary btn-sm">Activate</button>
                      </form>
                      <form method="post" action="?r=admin/deleteGame" data-confirm="Delete this game?" data-ajax="1">
                        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                        <input type="hidden" name="id" value="<?php echo e($g['id']); ?>">
                        <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete this game?');">Delete</button>
                      </form>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script>
(() => {
  const gameModeSelect = document.querySelector('select[name="game_mode"]');
  const scoreSelect = document.getElementById("scoreSystemSelect");
  const scoreNote = document.getElementById("scoreSystemLockedNote");

  function syncScoreSystem() {
    if (!gameModeSelect || !scoreSelect) return;
    const mode = gameModeSelect.value;
    if (mode === "One V One (BO3-SWISS)") {
      scoreSelect.value = "Point System (Limited)";
      scoreSelect.disabled = true;
      if (scoreNote) scoreNote.classList.remove("d-none");
    } else {
      scoreSelect.disabled = false;
      if (scoreNote) scoreNote.classList.add("d-none");
    }
  }

  if (gameModeSelect) {
    gameModeSelect.addEventListener("change", syncScoreSystem);
  }
  syncScoreSystem();
})();
</script>
</div>

<script>
(() => {
  const form = document.querySelector("form[action='?r=admin/createGame']");
  if (!form) return;
  const checkboxes = Array.from(form.querySelectorAll("input[type='checkbox'][name='players[]']"));
  const selectAll = form.querySelector("[data-select-all='players']");
  const clearAll = form.querySelector("[data-clear-all='players']");
  const search = form.querySelector("[data-player-search]");
  const rows = Array.from(form.querySelectorAll("[data-player-row]"));

  if (selectAll) {
    selectAll.addEventListener("click", () => {
      checkboxes.forEach((box) => { box.checked = true; });
    });
  }

  if (clearAll) {
    clearAll.addEventListener("click", () => {
      checkboxes.forEach((box) => { box.checked = false; });
    });
  }

  if (search) {
    const applyFilter = () => {
      const term = search.value.trim().toLowerCase();
      rows.forEach((row) => {
        const name = String(row.dataset.playerName || "").toLowerCase();
        const email = String(row.dataset.playerEmail || "").toLowerCase();
        const match = term === "" || name.includes(term) || email.includes(term);
        row.style.display = match ? "" : "none";
      });
    };
    search.addEventListener("input", applyFilter);
    applyFilter();
  }
})();
</script>

<script>
(() => {
  if (window.MANA_POD_GLOBAL_AJAX) return;
  const SECTION_IDS = ["games-header", "games-main"];

  

  function setLoading(form, loading) {
    form.querySelectorAll("button, input[type='submit']").forEach((btn) => {
      if (!btn.dataset.ajaxWasDisabled) {
        btn.dataset.ajaxWasDisabled = btn.disabled ? "1" : "0";
      }
      if (loading) {
        btn.disabled = true;
      } else if (btn.dataset.ajaxWasDisabled === "0") {
        btn.disabled = false;
      }
    });
  }

  function updateFromHtml(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    SECTION_IDS.forEach((id) => {
      const fresh = doc.getElementById(id);
      const current = document.getElementById(id);
      if (fresh && current) {
        current.replaceWith(fresh);
      }
    });
    if (typeof initAfterAjax === "function") {
      initAfterAjax();
    }
    initAjaxForms();
  }

  async function submitAjax(form) {
    const scrollY = window.scrollY;
    setLoading(form, true);
    try {
      const response = await fetch(form.action, {
        method: form.method || "POST",
        body: new FormData(form),
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
      });

      if (!response.ok) {
        window.location.reload();
        return;
      }

      const html = await response.text();
      const url = response.url || "";
      if (!url.includes("admin/games")) {
        window.location = url || window.location.href;
        return;
      }

      updateFromHtml(html);
      window.scrollTo(0, scrollY);
    } catch (err) {
      window.location.reload();
    } finally {
      setLoading(form, false);
    }
  }

  function initAjaxForms(root = document) {
    root.querySelectorAll("form[data-ajax]").forEach((form) => {
      if (form.dataset.ajaxBound === "1") return;
      form.dataset.ajaxBound = "1";
      form.addEventListener("submit", (event) => {
        if (event.defaultPrevented) return;
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        submitAjax(form);
      });
    });
  }

  if (typeof initAfterAjax === "function") {
    initAfterAjax();
  }
  initAjaxForms();
})();
</script>
