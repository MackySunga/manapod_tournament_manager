<div id="players-header"><h3 class="mb-3">Players</h3></div>

<div id="players-main">
<div class="d-flex flex-wrap gap-2 mb-3">
  <form method="post" action="?r=admin/seedPlayers" data-ajax="1">
    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
    <button class="btn btn-outline-success btn-sm">Add Sample Players Data</button>
  </form>
  <form method="post" action="?r=admin/seedPlayerUsers" data-ajax="1">
    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
    <button class="btn btn-outline-primary btn-sm">Create Logins for Players (user123456)</button>
  </form>

  <a class="btn btn-outline-secondary btn-sm" href="?r=admin/downloadTemplate">Download Blank CSV Template</a>
  <a class="btn btn-outline-secondary btn-sm" href="?r=admin/downloadGuide">Download CSV Guide</a>
</div>

<div class="card mb-3">
  <div class="card-body">
    <div class="fw-semibold mb-2">Upload Players via CSV</div>
    <form method="post" action="?r=admin/uploadPlayersCsv" enctype="multipart/form-data" class="row g-2 align-items-end" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="col-md-6">
        <input class="form-control" type="file" name="csv_file" accept=".csv" required>
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary w-100">Import CSV</button>
      </div>
    </form>
    <div class="form-text mt-2">Required headers: <code>email,name</code>. Email is the Player ID.</div>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2 text-white bg-primary rounded px-2 py-1">
      <div class="fw-semibold">Player List</div>
      <div class="small">Total: <?php echo (int)$playerCount; ?></div>
    </div>
    <hr class="mt-0 mb-3">

    <div class="d-flex flex-wrap justify-content-between gap-2 mb-2">
      <input class="form-control form-control-sm" id="playerSearch" type="search" placeholder="Search players..." style="max-width: 280px;">
    </div>
    <div class="table-responsive players-scroll">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>Email (ID)</th>
            <th>Name</th>
            <th>Created</th>
          </tr>
          <tr>
            <th><input class="form-control form-control-sm player-filter" data-col="0" placeholder="Filter email"></th>
            <th><input class="form-control form-control-sm player-filter" data-col="1" placeholder="Filter name"></th>
            <th><input class="form-control form-control-sm player-filter" data-col="2" placeholder="Filter date"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($players as $p): ?>
            <tr>
              <td><?php echo e($p['email']); ?></td>
              <td><?php echo e($p['name']); ?></td>
              <td class="small text-muted"><?php echo e($p['created_at'] ?? ''); ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($players)): ?>
            <tr><td colspan="3" class="text-muted">No players yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
(() => {
  const table = document.querySelector(".players-scroll table");
  if (!table) return;
  const rows = Array.from(table.querySelectorAll("tbody tr"));
  const search = document.getElementById("playerSearch");
  const filters = Array.from(document.querySelectorAll(".player-filter"));

  function matches(row) {
    const text = row.textContent.toLowerCase();
    if (search && search.value.trim() !== "") {
      if (!text.includes(search.value.toLowerCase().trim())) return false;
    }
    for (const input of filters) {
      const val = input.value.toLowerCase().trim();
      if (!val) continue;
      const col = Number(input.dataset.col || 0);
      const cell = row.children[col];
      if (!cell || !cell.textContent.toLowerCase().includes(val)) return false;
    }
    return true;
  }

  function applyFilters() {
    rows.forEach((row) => {
      row.style.display = matches(row) ? "" : "none";
    });
  }

  if (search) search.addEventListener("input", applyFilters);
  filters.forEach((input) => input.addEventListener("input", applyFilters));
})();
</script>
</div>

<script>
(() => {
  if (window.MANA_POD_GLOBAL_AJAX) return;
  const SECTION_IDS = ["players-header", "players-main"];

  

  function setLoading(form, loading) {
    form.querySelectorAll("button, input[type='submit']").forEach((btn) => {
      if (!btn.dataset.ajaxWasDisabled) {
        btn.dataset.ajaxWasDisabled = btn.disabled ? "1" : "0";
      }
      if (loading) {
        btn.disabled = true;
      } else if (btn.dataset.ajaxWasDisabled === "0") {
        btn.disabled = false;
      }
    });
  }

  function updateFromHtml(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    SECTION_IDS.forEach((id) => {
      const fresh = doc.getElementById(id);
      const current = document.getElementById(id);
      if (fresh && current) {
        current.replaceWith(fresh);
      }
    });
    if (typeof initAfterAjax === "function") {
      initAfterAjax();
    }
    initAjaxForms();
  }

  async function submitAjax(form) {
    const scrollY = window.scrollY;
    setLoading(form, true);
    try {
      const response = await fetch(form.action, {
        method: form.method || "POST",
        body: new FormData(form),
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
      });

      if (!response.ok) {
        window.location.reload();
        return;
      }

      const html = await response.text();
      const url = response.url || "";
      if (!url.includes("admin/players")) {
        window.location = url || window.location.href;
        return;
      }

      updateFromHtml(html);
      window.scrollTo(0, scrollY);
    } catch (err) {
      window.location.reload();
    } finally {
      setLoading(form, false);
    }
  }

  function initAjaxForms(root = document) {
    root.querySelectorAll("form[data-ajax]").forEach((form) => {
      if (form.dataset.ajaxBound === "1") return;
      form.dataset.ajaxBound = "1";
      form.addEventListener("submit", (event) => {
        if (event.defaultPrevented) return;
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        submitAjax(form);
      });
    });
  }

  if (typeof initAfterAjax === "function") {
    initAfterAjax();
  }
  initAjaxForms();
})();
</script>
