<?php
// app/Views/admin/users.php
?>

<div id="users-header"><h3 class="mb-3">User Management</h3></div>

<div id="users-main">

<div class="card mb-3">
  <div class="card-body">
    <div class="title-blue fw-bold fs-5 px-2 py-1 rounded mb-3">Create User</div>

    <form method="post" action="?r=admin/createUser" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">

      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <thead>
            <tr>
              <th>Email</th>
              <th>Name</th>
              <th>Role</th>
              <th>Password</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><input class="form-control form-control-sm" name="email" type="email" required></td>
              <td><input class="form-control form-control-sm" name="name" type="text" placeholder="Optional"></td>
              <td>
                <select class="form-select form-select-sm" name="role">
                  <option value="player">Player</option>
                  <option value="admin">Admin</option>
                </select>
              </td>
              <td><input class="form-control form-control-sm" name="password" type="text" minlength="6" required></td>
              <td>
                <button class="btn btn-sm btn-primary text-nowrap" type="submit">Create</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="d-flex flex-wrap align-items-center gap-3 mt-2">
        <div class="form-text">Password must be at least 6 characters.</div>
      </div>
    </form>

    <hr class="my-3">

    <div class="fw-semibold mb-2">Import Users via CSV</div>
    <form method="post" action="?r=admin/uploadUsersCsv" enctype="multipart/form-data" data-no-ajax="1" class="row g-2 align-items-start">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="col-12 col-lg-6">
        <input class="form-control form-control-sm" type="file" name="csv_file" accept=".csv" required>
        <div class="form-text">Required headers: <code>email,name,role,password</code>. Role must be <code>admin</code> or <code>player</code>.</div>
      </div>
      <div class="col-12 col-lg-3">
        <button class="btn btn-sm btn-primary w-100">Import CSV</button>
      </div>
      <div class="col-12 col-lg-3">
        <a class="btn btn-sm btn-outline-secondary w-100" href="?r=admin/downloadUsersTemplate">Download CSV Template</a>
      </div>
    </form>
  </div>
</div>



<?php if (!empty($playersWithoutAccounts)): ?>
  <div class="card mb-3">
    <div class="card-body">
      <div class="title-blue fw-bold fs-5 px-2 py-1 rounded mb-2">Players without Login Accounts</div>
      <div class="small text-muted mb-3">
        These players exist in <code>players.json</code> (ex: CSV import), but have no <code>users.json</code> account yet.
      </div>

      <form id="bulkCreateForm" method="post" action="?r=admin/bulkCreatePlayerUsers" data-ajax="1" class="mb-3">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <div class="table-responsive">
          <table class="table table-sm align-middle mb-0">
            <thead>
              <tr>
                <th>Default Password</th>
                <th>Selection</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <input class="form-control form-control-sm" name="password" type="text" minlength="6" placeholder="Set password for all selected (min 6 chars)" required>
                </td>
                <td class="d-flex gap-2 flex-wrap">
                  <button type="button" class="btn btn-outline-secondary btn-sm" data-select-all="pending-players">Select All</button>
                  <button type="button" class="btn btn-outline-secondary btn-sm" data-clear-all="pending-players">Clear All</button>
                </td>
                <td>
                  <button class="btn btn-success btn-sm text-nowrap" type="submit">Create Selected</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </form>

      <div class="row g-2 align-items-end mb-2">
        <div class="col-12 col-md-4">
          <label class="form-label fw-bold" for="pendingPlayerSearch">Search</label>
          <input class="form-control form-control-sm" id="pendingPlayerSearch" type="search" placeholder="Search players...">
        </div>
      </div>
      <div class="table-responsive users-pending-scroll">
        <table class="table table-sm align-middle">
          <colgroup>
            <col style="width: 6%">
            <col style="width: 28%">
            <col style="width: 36%">
            <col style="width: 30%">
          </colgroup>
          <thead>
            <tr>
              <th></th>
              <th>Name</th>
              <th>Password</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($playersWithoutAccounts as $email => $p): ?>
              <?php $pname = (string)($p['name'] ?? $email); ?>
              <tr data-pending-email="<?php echo e($email); ?>" data-pending-name="<?php echo e($pname); ?>">
                <td>
                  <input class="form-check-input pending-player" type="checkbox" value="<?php echo e($email); ?>">
                </td>
                <td>
                  <div class="fw-semibold"><?php echo e($pname); ?></div>
                  <div class="small text-muted"><?php echo e($email); ?></div>
                </td>
                <td>
                  <?php $formId = 'pendingCreate_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $email); ?>
                  <form id="<?php echo e($formId); ?>" method="post" action="?r=admin/createUser" data-ajax="1">
                    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">
                    <input type="hidden" name="name" value="<?php echo e($pname); ?>">
                    <input type="hidden" name="role" value="player">
                    <input class="form-control form-control-sm" name="password" type="text" minlength="6" placeholder="Set password (min 6 chars)" required>
                  </form>
                </td>
                <td>
                  <div class="d-flex align-items-center gap-2 flex-nowrap">
                    <button class="btn btn-sm btn-success text-nowrap" type="submit" form="<?php echo e($formId); ?>">Create Account</button>
                    <form method="post" action="?r=admin/deletePlayerRecord" data-ajax="1" onsubmit="return confirm('Delete this player from the system? This will remove them from games and history.');">
                      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                      <input type="hidden" name="email" value="<?php echo e($email); ?>">
                      <button class="btn btn-sm btn-outline-danger">Remove</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <div class="title-blue fw-bold fs-5 px-2 py-1 rounded mb-2">All Users</div>
    <div class="fst-italic text-muted small">Safety rules: you can't disable yourself, you can't demote yourself, and you can't remove/disable the last active admin.</div>
    <hr class="mt-2 mb-3">

    <div class="row g-2 align-items-end mb-2">
      <div class="col-12 col-lg-6">
        <label class="form-label fw-bold">Search</label>
        <input class="form-control form-control-sm" type="search" id="userSearch" placeholder="Search email, name, role, status">
      </div>
      <div class="col-12 col-lg-2">
        <button class="btn btn-outline-secondary btn-sm w-100" type="button" id="clearUserFilters">Clear Filters</button>
      </div>
    </div>

    <div class="table-responsive users-scroll">
      <table class="table table-sm align-middle users-table" style="table-layout: fixed;">
        <colgroup>
          <col style="width: 6%">
          <col style="width: 22%">
          <col style="width: 16%">
          <col style="width: 16%">
          <col style="width: 10%">
          <col style="width: 30%">
        </colgroup>
        <thead>
          <tr>
            <th><input class="form-check-input" type="checkbox" id="selectAllUsers"></th>
            <th>Email</th>
            <th>Name</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
          <tr>
            <th></th>
            <th><input class="form-control form-control-sm" type="text" data-filter="email" placeholder="Filter email"></th>
            <th><input class="form-control form-control-sm" type="text" data-filter="name" placeholder="Filter name"></th>
            <th>
              <select class="form-select form-select-sm" data-filter="role">
                <option value="">All</option>
                <option value="admin">Admin</option>
                <option value="player">Player</option>
              </select>
            </th>
            <th>
              <select class="form-select form-select-sm" data-filter="status">
                <option value="">All</option>
                <option value="active">Active</option>
                <option value="disabled">Disabled</option>
              </select>
            </th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($users)): ?>
            <tr><td colspan="6" class="text-muted">No users found.</td></tr>
          <?php else: ?>
            <?php foreach ($users as $email => $u): ?>
              <?php
                $role = (string)($u['role'] ?? '');
                $disabled = !empty($u['disabled']);
              ?>
              <tr data-email="<?php echo e($email); ?>"
                  data-name="<?php echo e((string)($u['name'] ?? $email)); ?>"
                  data-role="<?php echo e($role); ?>"
                  data-status="<?php echo $disabled ? 'disabled' : 'active'; ?>">
                <td>
                  <input class="form-check-input user-select" type="checkbox" value="<?php echo e($email); ?>">
                </td>
                <td class="text-break"><?php echo e($email); ?></td>

                <td class="text-break"><?php echo e((string)($u['name'] ?? $email)); ?></td>

                <td>
                  <form method="post" action="?r=admin/updateUserRole" class="d-flex align-items-center gap-2 flex-nowrap m-0" data-ajax="1">
                    <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">

                    <select class="form-select form-select-sm" name="role" style="width: 140px;">
                      <option value="player" <?php echo $role==='player'?'selected':''; ?>>Player</option>
                      <option value="admin" <?php echo $role==='admin'?'selected':''; ?>>Admin</option>
                    </select>

                    <button class="btn btn-sm btn-outline-primary" type="submit">Save</button>
                  </form>
                </td>

                <td>
                  <?php if ($disabled): ?>
                    <span class="badge text-bg-secondary">Disabled</span>
                  <?php else: ?>
                    <span class="badge text-bg-success">Active</span>
                  <?php endif; ?>
                </td>

                <td>
                  <div class="d-flex align-items-center gap-2 flex-nowrap users-actions">
                    <form method="post" action="?r=admin/resetUserPassword" class="m-0" data-ajax="1">
                      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                      <input type="hidden" name="email" value="<?php echo e($email); ?>">

                      <div class="input-group input-group-sm" style="width: 220px;">
                        <input class="form-control" name="password" type="text" minlength="6" placeholder="New password" required>
                        <button class="btn btn-outline-warning" type="submit">Reset</button>
                      </div>
                    </form>

                    <form method="post" action="?r=admin/toggleUserDisabled" class="m-0" data-ajax="1">
                      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
                      <input type="hidden" name="email" value="<?php echo e($email); ?>">
                      <button class="btn btn-sm btn-outline-danger" type="submit" style="min-width: 92px;">
                        <?php echo $disabled ? 'Enable' : 'Disable'; ?>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <form id="bulkUsersForm" class="mt-3" method="post" action="?r=admin/bulkUserActions" data-ajax="1">
      <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
      <div class="d-flex flex-wrap gap-2 mb-2">
        <button class="btn btn-outline-danger btn-sm" type="button" data-bulk-action="delete">Delete Selected</button>
        <button class="btn btn-outline-warning btn-sm" type="button" data-bulk-action="disable">Disable Selected</button>
        <button class="btn btn-outline-success btn-sm" type="button" data-bulk-action="enable">Enable Selected</button>
      </div>
      <hr class="my-2">
      <div class="row g-2 align-items-end">
        <div class="col-12 col-lg-4">
          <label class="form-label fw-bold">Bulk Password Reset</label>
          <input class="form-control form-control-sm" type="text" name="password" minlength="6" placeholder="Set password for selected (min 6 chars)">
        </div>
        <div class="col-12 col-lg-8 d-flex flex-wrap gap-2">
          <button class="btn btn-outline-primary btn-sm" type="button" data-bulk-action="reset">Reset Passwords</button>
        </div>
      </div>
    </form>

    <div class="form-text mt-2">
      Safety rules: you can’t disable yourself, you can’t demote yourself, and you can’t remove/disable the last active admin.
    </div>
  </div>
</div>

<div class="card mt-3">
  <div class="card-body">
    <div class="title-blue fw-bold fs-5 px-2 py-1 rounded mb-2">User Management Audit Logs</div>
    <div class="table-responsive mb-2">
      <table class="table table-sm align-middle mb-0">
        <thead>
          <tr>
            <th>Search</th>
            <th>Admin Filter</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <input class="form-control form-control-sm" id="auditSearch" type="search" placeholder="Search audit logs...">
            </td>
            <td>
              <input class="form-control form-control-sm" id="auditAdminFilter" type="search" placeholder="Filter admin...">
            </td>
            <td class="d-flex gap-2 flex-wrap">
              <button class="btn btn-outline-secondary btn-sm" type="button" id="auditClearFilters">Clear</button>
              <a class="btn btn-outline-primary btn-sm" href="?r=admin/printUserAuditPdf" target="_blank" rel="noopener">Print PDF</a>
              <a class="btn btn-outline-success btn-sm" href="?r=admin/downloadUserAuditCsv">Download CSV</a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <?php
      $formatUserAuditTime = function ($ts): string {
        if (!$ts) return '';
        try {
          $dt = new DateTime((string)$ts);
          return $dt->format('y-m-d h:i A');
        } catch (Exception $e) {
          return (string)$ts;
        }
      };
      $auditRows = (array)($userAudit ?? []);
      usort($auditRows, function ($a, $b) {
        $ta = strtotime((string)($a['time'] ?? '')) ?: 0;
        $tb = strtotime((string)($b['time'] ?? '')) ?: 0;
        return $tb <=> $ta;
      });
    ?>

    <?php if (empty($auditRows)): ?>
      <div class="text-muted text-center">No audit entries yet.</div>
    <?php else: ?>
      <div class="table-responsive audit-scroll">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>Time</th>
              <th>Admin</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($auditRows as $entry): ?>
              <tr>
                <?php
                  $auditTime = $formatUserAuditTime($entry['time'] ?? '');
                  $auditUser = (string)($entry['user'] ?? '');
                  $auditMsg = (string)($entry['message'] ?? '');
                ?>
                <td data-iso-time="<?php echo e((string)($entry['time'] ?? '')); ?>" data-audit-time="<?php echo e($auditTime); ?>"><?php echo e($auditTime); ?></td>
                <td data-audit-admin="<?php echo e($auditUser); ?>"><?php echo e($auditUser); ?></td>
                <td data-audit-message="<?php echo e($auditMsg); ?>"><?php echo e($auditMsg); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
(() => {
  const SECTION_IDS = ["users-header", "users-main"];
  const globalAjax = window.MANA_POD_GLOBAL_AJAX === true;

  function initAfterAjax() {
    const table = document.querySelector(".users-table");
    if (!table) return;
    const searchInput = document.getElementById("userSearch");
    const clearBtn = document.getElementById("clearUserFilters");
    const filters = table.querySelectorAll("[data-filter]");
    const rows = Array.from(table.querySelectorAll("tbody tr"))
      .filter((row) => row.dataset.email !== undefined);

    function norm(val) {
      return String(val || "").toLowerCase();
    }

    function applyFilters() {
      const search = norm(searchInput.value);
      const filterMap = {};
      filters.forEach((el) => {
        filterMap[el.dataset.filter] = norm(el.value);
      });

      rows.forEach((row) => {
        const email = norm(row.dataset.email);
        const name = norm(row.dataset.name);
        const role = norm(row.dataset.role);
        const status = norm(row.dataset.status);

        const matchesSearch =
          search === "" ||
          email.includes(search) ||
          name.includes(search) ||
          role.includes(search) ||
          status.includes(search);

        const matchesEmail = filterMap.email === "" || email.includes(filterMap.email);
        const matchesName = filterMap.name === "" || name.includes(filterMap.name);
        const matchesRole = filterMap.role === "" || role === filterMap.role;
        const matchesStatus = filterMap.status === "" || status.includes(filterMap.status);

        row.classList.toggle(
          "d-none",
          !(matchesSearch && matchesEmail && matchesName && matchesRole && matchesStatus)
        );
      });
    }

    if (searchInput && !searchInput.dataset.filterBound) {
      searchInput.dataset.filterBound = "1";
      searchInput.addEventListener("input", applyFilters);
    }
    filters.forEach((el) => {
      if (el.dataset.filterBound === "1") return;
      el.dataset.filterBound = "1";
      el.addEventListener("input", applyFilters);
      el.addEventListener("change", applyFilters);
    });
    if (clearBtn && !clearBtn.dataset.filterBound) {
      clearBtn.dataset.filterBound = "1";
      clearBtn.addEventListener("click", () => {
        if (searchInput) searchInput.value = "";
        filters.forEach((el) => { el.value = ""; });
        applyFilters();
      });
    }

    const selectAll = document.getElementById("selectAllUsers");
    const userChecks = Array.from(document.querySelectorAll(".user-select"));
    if (selectAll) {
      selectAll.addEventListener("change", () => {
        userChecks.forEach((cb) => { cb.checked = selectAll.checked; });
      });
    }

    const bulkForm = document.getElementById("bulkUsersForm");
    if (bulkForm) {
      bulkForm.querySelectorAll("[data-bulk-action]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const action = btn.getAttribute("data-bulk-action");
          const selected = userChecks.filter((cb) => cb.checked).map((cb) => cb.value);
          if (selected.length === 0) {
            alert("Please select at least one user.");
            return;
          }
          if (action === "reset") {
            const pass = bulkForm.querySelector("input[name='password']").value || "";
            if (pass.length < 6) {
              alert("Password must be at least 6 characters.");
              return;
            }
          }
          if (action === "delete" && !confirm("Delete the selected users? This cannot be undone.")) {
            return;
          }
          if (action === "disable" && !confirm("Disable the selected users?")) {
            return;
          }
          if (action === "enable" && !confirm("Enable the selected users?")) {
            return;
          }
          bulkForm.querySelectorAll("input[name='users[]'], input[name='action']").forEach((el) => el.remove());
          selected.forEach((email) => {
            const input = document.createElement("input");
            input.type = "hidden";
            input.name = "users[]";
            input.value = email;
            bulkForm.appendChild(input);
          });
          const actionInput = document.createElement("input");
          actionInput.type = "hidden";
          actionInput.name = "action";
          actionInput.value = action;
          bulkForm.appendChild(actionInput);
          bulkForm.requestSubmit();
        });
      });
    }

    const auditSearch = document.getElementById("auditSearch");
    const auditAdmin = document.getElementById("auditAdminFilter");
    const auditClear = document.getElementById("auditClearFilters");
    const auditRows = Array.from(document.querySelectorAll("td[data-audit-message]")).map((cell) => cell.closest("tr"));

    function auditMatches(row) {
      const text = row.textContent.toLowerCase();
      const searchVal = (auditSearch?.value || "").trim().toLowerCase();
      const adminVal = (auditAdmin?.value || "").trim().toLowerCase();
      if (searchVal && !text.includes(searchVal)) return false;
      if (adminVal) {
        const adminCell = row.querySelector("[data-audit-admin]");
        const adminText = adminCell ? adminCell.textContent.toLowerCase() : "";
        if (!adminText.includes(adminVal)) return false;
      }
      return true;
    }

    function applyAuditFilters() {
      auditRows.forEach((row) => {
        row.style.display = auditMatches(row) ? "" : "none";
      });
    }

    if (auditSearch && !auditSearch.dataset.filterBound) {
      auditSearch.dataset.filterBound = "1";
      auditSearch.addEventListener("input", applyAuditFilters);
    }
    if (auditAdmin && !auditAdmin.dataset.filterBound) {
      auditAdmin.dataset.filterBound = "1";
      auditAdmin.addEventListener("input", applyAuditFilters);
    }
    if (auditClear && !auditClear.dataset.filterBound) {
      auditClear.dataset.filterBound = "1";
      auditClear.addEventListener("click", () => {
        if (auditSearch) auditSearch.value = "";
        if (auditAdmin) auditAdmin.value = "";
        applyAuditFilters();
      });
    }
    applyAuditFilters();

    const pendingSearch = document.getElementById("pendingPlayerSearch");
    const pendingRows = Array.from(document.querySelectorAll("tr[data-pending-email]"));
    function applyPendingFilter() {
      const term = (pendingSearch?.value || "").trim().toLowerCase();
      pendingRows.forEach((row) => {
        const name = String(row.dataset.pendingName || "").toLowerCase();
        const email = String(row.dataset.pendingEmail || "").toLowerCase();
        const match = term === "" || name.includes(term) || email.includes(term);
        row.style.display = match ? "" : "none";
      });
    }
    if (pendingSearch && !pendingSearch.dataset.filterBound) {
      pendingSearch.dataset.filterBound = "1";
      pendingSearch.addEventListener("input", applyPendingFilter);
    }
    applyPendingFilter();

    applyFilters();
  }


  function setLoading(form, loading) {
    form.querySelectorAll("button, input[type='submit']").forEach((btn) => {
      if (!btn.dataset.ajaxWasDisabled) {
        btn.dataset.ajaxWasDisabled = btn.disabled ? "1" : "0";
      }
      if (loading) {
        btn.disabled = true;
      } else if (btn.dataset.ajaxWasDisabled === "0") {
        btn.disabled = false;
      }
    });
  }

  function updateFromHtml(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    SECTION_IDS.forEach((id) => {
      const fresh = doc.getElementById(id);
      const current = document.getElementById(id);
      if (fresh && current) {
        current.replaceWith(fresh);
      }
    });
    if (typeof initAfterAjax === "function") {
      initAfterAjax();
    }
    if (!globalAjax) {
      initAjaxForms();
    }
  }

  async function submitAjax(form) {
    const scrollY = window.scrollY;
    setLoading(form, true);
    try {
      const response = await fetch(form.action, {
        method: form.method || "POST",
        body: new FormData(form),
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
      });

      if (!response.ok) {
        window.location.reload();
        return;
      }

      const html = await response.text();
      const url = response.url || "";
      if (!url.includes("admin/users")) {
        window.location = url || window.location.href;
        return;
      }

      updateFromHtml(html);
      window.scrollTo(0, scrollY);
    } catch (err) {
      window.location.reload();
    } finally {
      setLoading(form, false);
    }
  }

  function initAjaxForms(root = document) {
    if (globalAjax) return;
    root.querySelectorAll("form[data-ajax]").forEach((form) => {
      if (form.dataset.ajaxBound === "1") return;
      form.dataset.ajaxBound = "1";
      form.addEventListener("submit", (event) => {
        if (event.defaultPrevented) return;
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        submitAjax(form);
      });
    });
  }

  if (typeof initAfterAjax === "function") {
    initAfterAjax();
  }
  if (!globalAjax) {
    initAjaxForms();
  }
})();
</script>

<script>
(() => {
  const form = document.getElementById("bulkCreateForm");
  if (!form) return;
  const boxes = Array.from(document.querySelectorAll(".pending-player"));
  const selectAll = form.querySelector("[data-select-all='pending-players']");
  const clearAll = form.querySelector("[data-clear-all='pending-players']");

  if (selectAll) {
    selectAll.addEventListener("click", () => {
      boxes.forEach((box) => { box.checked = true; });
    });
  }
  if (clearAll) {
    clearAll.addEventListener("click", () => {
      boxes.forEach((box) => { box.checked = false; });
    });
  }

  form.addEventListener("submit", (event) => {
    form.querySelectorAll("input[type='hidden'][name='players[]']").forEach((el) => el.remove());
    const selected = boxes.filter((box) => box.checked).map((box) => box.value);
    if (selected.length === 0) {
      event.preventDefault();
      alert("Please select at least one player.");
      return;
    }
    selected.forEach((email) => {
      const input = document.createElement("input");
      input.type = "hidden";
      input.name = "players[]";
      input.value = email;
      form.appendChild(input);
    });
  });
})();
</script>
