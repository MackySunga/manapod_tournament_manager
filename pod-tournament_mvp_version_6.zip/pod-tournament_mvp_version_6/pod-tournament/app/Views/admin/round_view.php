<div class="print-only mb-3">
  <div class="fw-semibold"><?php echo e($game['name']); ?></div>
  <div>Round <?php echo (int)$roundNum; ?></div>
</div>

<?php
$allLocked = true;
foreach ((array)($round['pods'] ?? []) as $p) {
  if (empty($p['locked'])) { $allLocked = false; break; }
}
$pairingLocked = !empty($round['pairing_locked']);
$timerLocked = !empty($round['timer_locked']);
$timeLimit = (int)($round['time_limit_minutes'] ?? 0);
$timerStart = !empty($round['timer_start']) ? strtotime((string)$round['timer_start']) : null;
$timerEnd = !empty($round['timer_end']) ? strtotime((string)$round['timer_end']) : null;
$timerRunning = !empty($round['timer_running']);
$timerStarted = !empty($round['timer_start']);
$roundCompleted = !empty($round['completed']);
$roundCompletedAt = (string)($round['completed_at'] ?? '');
$displayShowPods = !empty($round['display_show_pods']);
$gameMode = (string)($game['game_mode'] ?? 'MULTI PLAYER');
$isOneVOne = ($gameMode === 'One V One (BO3-SWISS)');
$scoreSystem = (string)($game['score_system'] ?? 'Point System (Limited)');
$isUnlimited = ($scoreSystem === 'Point System (Unlimited)');
$scoreMin = 0;
$scoreMax = $isUnlimited ? 100 : 4;
$podTotalMax = $isUnlimited ? 400 : 9;
if ($isOneVOne) {
  $scoreMax = 2;
  $podTotalMax = 3;
  $isUnlimited = false;
}
$nowTs = time();
$elapsed = $timerStart ? (($timerEnd ?? $nowTs) - $timerStart) : 0;
$limitSeconds = $timeLimit > 0 ? ($timeLimit * 60) : 0;
$overtime = ($limitSeconds > 0) ? max(0, $elapsed - $limitSeconds) : 0;

$byeHistory = array_change_key_case((array)($game['bye_history'] ?? []), CASE_LOWER);
$currentBye = null;
foreach ((array)($round['pods'] ?? []) as $p) {
  if (!empty($p['bye']) && !empty($p['players'][0])) {
    $currentBye = strtolower((string)$p['players'][0]);
    break;
  }
  if (count((array)($p['players'] ?? [])) === 1 && !empty($p['players'][0])) {
    $currentBye = strtolower((string)$p['players'][0]);
    break;
  }
}
$activePlayers = array_values(array_map('strtolower', (array)($game['players'] ?? [])));
$droppedPlayers = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
$activePlayers = array_values(array_filter($activePlayers, fn($p) => !in_array($p, $droppedPlayers, true)));
$canSelectBye = $isOneVOne && $roundNum > 1 && !$pairingLocked && !$roundCompleted && (count($activePlayers) % 2 === 1);
$eligibleBye = array_values(array_filter($activePlayers, function ($p) use ($byeHistory, $currentBye) {
  return empty($byeHistory[$p]) || $p === $currentBye;
}));

$formatSeconds = function(int $sec): string {
  $sec = max(0, $sec);
  $h = intdiv($sec, 3600);
  $m = intdiv($sec % 3600, 60);
  $s = $sec % 60;
  if ($h > 0) return sprintf('%d:%02d:%02d', $h, $m, $s);
  return sprintf('%02d:%02d', $m, $s);
};

$priorPairs = [];
foreach ((array)($game['rounds'] ?? []) as $r) {
  if (($r['number'] ?? 0) >= $roundNum) continue;
  foreach ((array)($r['pods'] ?? []) as $p) {
    $plist = array_values((array)($p['players'] ?? []));
    for ($i = 0; $i < count($plist); $i++) {
      for ($j = $i + 1; $j < count($plist); $j++) {
        $a = $plist[$i];
        $b = $plist[$j];
        $key = ($a < $b) ? ($a . '|' . $b) : ($b . '|' . $a);
        $priorPairs[$key] = true;
      }
    }
  }
}
?>

<div id="round-header">
<h3 class="mb-2 text-center fw-bold fs-3"><?php echo e($game['name']); ?></h3>
<div class="d-flex justify-content-center mb-2">
  <table class="table table-sm table-bordered w-auto mb-0">
    <tbody>
      <tr>
        <th class="px-3">Players</th>
        <td class="px-3"><?php echo (int)count($activePlayers); ?></td>
      </tr>
      <tr>
        <th class="px-3">Game Mode</th>
        <td class="px-3"><?php echo e((string)($game['game_mode'] ?? '')); ?></td>
      </tr>
      <tr>
        <th class="px-3">Point System</th>
        <td class="px-3"><?php echo e((string)($game['score_system'] ?? '')); ?></td>
      </tr>
    </tbody>
  </table>
</div>
<div class="d-flex flex-column align-items-center gap-2 mb-2">
  <?php if (!$pairingLocked): ?>
    <div class="d-inline-block px-3 py-1 fw-bold fs-3 bg-warning rounded">ROUND <?php echo (int)$roundNum; ?></div>
    <div class="d-inline-block px-3 py-1 fw-semibold bg-warning text-dark rounded">STATUS: PREPARING ROUND</div>
  <?php else: ?>
    <div class="d-inline-block px-3 py-1 fw-bold fs-3">ROUND <?php echo (int)$roundNum; ?></div>
  <?php endif; ?>
</div>
</div>
<?php
$successNotice = flash_get('success');
$errorNotice = flash_get('error');
$notices = [
  'pods' => [],
  'pairings' => [],
  'timer' => [],
  'display' => [],
  'actions' => [],
];
$routeNotice = function(string $msg): string {
  $lc = strtolower($msg);
  if (strpos($lc, 'timer') !== false || strpos($lc, 'time') !== false) return 'timer';
  if (strpos($lc, 'display') !== false) return 'display';
  if (strpos($lc, 'pairings') !== false || strpos($lc, 'swap') !== false || strpos($lc, 're-pair') !== false || strpos($lc, 'auto-swap') !== false) return 'pairings';
  if (strpos($lc, 'score') !== false || strpos($lc, 'pod') !== false) return 'pods';
  return 'actions';
};
$pushNotice = function(string $bucket, string $type, string $msg) use (&$notices): void {
  $notices[$bucket][] = ['type' => $type, 'msg' => $msg];
};
if ($successNotice) {
  $pushNotice($routeNotice($successNotice), 'success', $successNotice);
}
if ($errorNotice) {
  $pushNotice($routeNotice($errorNotice), 'danger', $errorNotice);
}
?>
<?php $showTimerFirst = ($timerStarted || $allLocked); ?>
<div class="row g-3">
<div class="card mb-3 pairing-controls">
  <div class="card-body">
    <div class="card mb-3 <?php echo $pairingLocked ? 'bg-light' : ''; ?>" id="pairings-tools">
      <div class="card-body">
        <div class="section-title section-title--round text-center <?php echo $pairingLocked ? 'bg-secondary bg-opacity-25 text-dark' : ''; ?>">Pairings Tools</div>
        <hr class="mt-0 mb-3">
    <?php foreach ($notices['pairings'] as $n): ?>
      <div class="alert alert-<?php echo e($n['type']); ?> py-1 text-center mb-2"><?php echo e($n['msg']); ?></div>
    <?php endforeach; ?>
    <div class="mb-3">
        <form method="post" action="?r=admin/repodRound" data-anchor="pairings-tools" onsubmit="return confirm('Re-pairing will reset scores for this round. Continue?');" class="d-flex flex-column align-items-center gap-2">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
            <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
            <label class="small text-muted text-center">
              Pairing:
              <?php $isOneVOne = (($game['game_mode'] ?? '') === 'One V One (BO3-SWISS)'); ?>
              <?php if ($isOneVOne): ?>
                <span class="ms-1 fw-bold">Swiss Pods</span>
                <input type="hidden" name="pairing_mode" value="swiss_pods">
              <?php else: ?>
                <select name="pairing_mode" class="form-select form-select-sm d-inline-block w-auto ms-1" <?php echo $pairingLocked ? 'disabled' : ''; ?>>
                  <option value="ranking_top4" <?php echo (($round['pairing_mode'] ?? '') === 'ranking_top4') ? 'selected' : ''; ?>>Ranking top 4</option>
                  <option value="ranking_highlow" <?php echo (($round['pairing_mode'] ?? '') === 'ranking_highlow') ? 'selected' : ''; ?>>Ranking high/low</option>
                  <option value="swiss_pods" <?php echo (($round['pairing_mode'] ?? '') === 'swiss_pods') ? 'selected' : ''; ?>>Swiss Pods</option>
                  <option value="true_swiss" <?php echo (($round['pairing_mode'] ?? '') === 'true_swiss') ? 'selected' : ''; ?>>True Swiss</option>
                  <option value="power_pods" <?php echo (($round['pairing_mode'] ?? '') === 'power_pods') ? 'selected' : ''; ?>>Power Pods</option>
                  <option value="bubble_pods" <?php echo (($round['pairing_mode'] ?? '') === 'bubble_pods') ? 'selected' : ''; ?>>Bubble Pods</option>
                  <option value="random_pods" <?php echo (($round['pairing_mode'] ?? '') === 'random_pods') ? 'selected' : ''; ?>>Random Pods</option>
                  <option value="top1_low3" <?php echo (($round['pairing_mode'] ?? '') === 'top1_low3') ? 'selected' : ''; ?>>Highest 1 vs Lowest 3</option>
                  <option value="alpha_no_repeat" <?php echo (($round['pairing_mode'] ?? '') === 'alpha_no_repeat') ? 'selected' : ''; ?>>Alphabetical</option>
                </select>
              <?php endif; ?>
            </label>
            <button class="btn btn-outline-primary btn-sm <?php echo $pairingLocked ? 'bg-secondary border-secondary text-dark' : ''; ?>" <?php echo $pairingLocked ? 'disabled' : ''; ?>>Re-pair Pods</button>
          </form>
        </div>

        <div class="mb-3 d-flex justify-content-center">
          <form method="post" action="?r=admin/autoSwapPods" data-anchor="pairings-tools" onsubmit="return confirm('Auto-swap will reset all scores in this round. Continue?');">
            <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
            <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
            <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
            <button class="btn btn-outline-warning btn-sm <?php echo $pairingLocked ? 'bg-secondary border-secondary text-dark' : ''; ?>" <?php echo $pairingLocked ? 'disabled' : ''; ?>>Auto-swap to Reduce Repeats</button>
          </form>
        </div>

        <div class="section-title section-title--round text-center <?php echo $pairingLocked ? 'bg-secondary bg-opacity-25 text-dark' : ''; ?>">Manual Player Swap (between pods)</div>
        <hr class="mt-0 mb-3">
        <form method="post" action="?r=admin/swapPodPlayers" data-anchor="pairings-tools" onsubmit="return confirm('Swapping will reset scores for the affected pods. Continue?');" class="row g-2 align-items-end">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
          <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
          <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">

          <div class="col-md-5">
            <label class="form-label">Player A</label>
            <select class="form-select" name="player_a" required <?php echo $pairingLocked ? 'disabled' : ''; ?>>
              <option value="">Select player</option>
              <?php foreach ((array)($round['pods'] ?? []) as $p): ?>
                <optgroup label="<?php echo e($p['id']); ?>">
                  <?php foreach ((array)($p['players'] ?? []) as $email): ?>
                    <?php $meta = $playersMeta[$email] ?? ['name'=>$email]; ?>
                    <option value="<?php echo e($email); ?>"><?php echo e($meta['name']); ?> (<?php echo e($email); ?>)</option>
                  <?php endforeach; ?>
                </optgroup>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-5">
            <label class="form-label">Player B</label>
            <select class="form-select" name="player_b" required <?php echo $pairingLocked ? 'disabled' : ''; ?>>
              <option value="">Select player</option>
              <?php foreach ((array)($round['pods'] ?? []) as $p): ?>
                <optgroup label="<?php echo e($p['id']); ?>">
                  <?php foreach ((array)($p['players'] ?? []) as $email): ?>
                    <?php $meta = $playersMeta[$email] ?? ['name'=>$email]; ?>
                    <option value="<?php echo e($email); ?>"><?php echo e($meta['name']); ?> (<?php echo e($email); ?>)</option>
                  <?php endforeach; ?>
                </optgroup>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-2">
            <button class="btn btn-primary w-100 <?php echo $pairingLocked ? 'bg-secondary border-secondary' : ''; ?>" <?php echo $pairingLocked ? 'disabled' : ''; ?>>Swap Players</button>
          </div>
        </form>

        <?php if ($canSelectBye): ?>
          <form method="post" action="?r=admin/setRoundBye" data-anchor="pairings-tools" data-confirm="Reassign the BYE and regenerate pods? This will reset scores in this round." class="w-100">
            <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
            <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
            <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
            <div class="section-title section-title--round text-center fs-6 mt-3">Select BYE Player</div>
            <hr class="mt-1 mb-2">
            <div class="d-flex flex-column align-items-center gap-2">
              <select class="form-select form-select-sm" name="bye_player" style="max-width: 260px;">
                <?php foreach ($eligibleBye as $email): ?>
                  <?php $meta = $playersMeta[$email] ?? ['name' => $email]; ?>
                  <option value="<?php echo e($email); ?>" <?php echo $email === $currentBye ? 'selected' : ''; ?>>
                    <?php echo e($meta['name']); ?> (<?php echo e($email); ?>)
                  </option>
                <?php endforeach; ?>
              </select>
              <button class="btn btn-outline-primary btn-sm">Set BYE</button>
            </div>
            <div class="form-text text-center">Only available for odd player counts; BYE is 2 points.</div>
          </form>
        <?php endif; ?>
        <div class="form-text text-center">Swaps are blocked if any selected pod is locked or pairings are locked.</div>

        <div class="mt-3 text-center">
          <hr class="my-3">
          <?php if ($pairingLocked): ?>
            <div class="d-inline-flex flex-wrap align-items-center gap-2 justify-content-center">
              <span class="badge text-bg-secondary">PAIRINGS LOCKED</span>
            </div>
            <div class="d-flex justify-content-center mt-2">
              <a class="btn btn-success btn-lg fw-bold" href="?r=admin/printPairingsPdf&id=<?php echo e($game['id']); ?>&round=<?php echo (int)$roundNum; ?>" target="_blank" rel="noopener">Print Pairings (PDF)</a>
            </div>
          <?php else: ?>
            <form method="post" action="?r=admin/lockPairings" data-anchor="pairings-tools" data-confirm="Lock pairings for this round? This will disable re-pairing and swaps.">
              <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
              <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
              <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
              <button class="btn btn-outline-danger">Lock Pairings</button>
            </form>
            <div class="small text-danger mt-1">Once pairings are locked, it cannot be changed.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

  </div>
</div>

<div id="round-main">

<?php if ($roundCompleted): ?>
  <?php
    $rows = $roundStandings['ranked'] ?? [];
    $dropped = array_values(array_unique(array_map('strtolower', (array)($game['dropped_players'] ?? []))));
    $activeRows = [];
    $droppedRows = [];
    foreach ($rows as $row) {
      if (in_array(strtolower((string)$row['email']), $dropped, true)) {
        $droppedRows[] = $row;
      } else {
        $activeRows[] = $row;
      }
    }
  ?>
  <div class="card mb-3">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <div class="fw-semibold">Current Standings (Round <?php echo (int)$roundNum; ?>)</div>
        <a class="btn btn-outline-secondary btn-sm" href="?r=admin/printRoundReportPdf&id=<?php echo e($game['id']); ?>&round=<?php echo (int)$roundNum; ?>" target="_blank" rel="noopener">Print Round Report (PDF)</a>
      </div>
      <div class="table-responsive audit-scroll">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>#</th><th>Player</th><th>Total Score</th><th>Total Wins Points</th><th>Total Loss</th>
              <th>Win Rate</th><th>Match-win %</th><th>Game-win %</th><th>OWP</th><th>OGP</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($activeRows as $i => $r): ?>
              <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
              <tr>
                <td><?php echo $i+1; ?></td>
                <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span></td>
                <td><?php echo (int)$r['total_score']; ?></td>
                <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
                <td><?php echo (int)$r['total_loss']; ?></td>
                <td><?php echo number_format((float)$r['win_rate'], 3); ?></td>
                <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
                <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
                <td><?php echo number_format((float)$r['owp'], 3); ?></td>
                <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($activeRows)): ?>
              <tr><td colspan="10" class="text-muted">No data yet.</td></tr>
            <?php endif; ?>
            <?php if (!empty($droppedRows)): ?>
              <tr><td colspan="10" class="text-muted">Dropped Players</td></tr>
              <?php foreach ($droppedRows as $r): ?>
                <?php $meta = $playersMeta[$r['email']] ?? ['name'=>$r['email']]; ?>
                <tr class="table-secondary">
                  <td>-</td>
                  <td><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($r['email']); ?>)</span> <span class="badge text-bg-danger ms-1">DROPPED</span></td>
                  <td><?php echo (int)$r['total_score']; ?></td>
                  <td><?php echo number_format((float)$r['total_wins_points'], 2); ?></td>
                  <td><?php echo (int)$r['total_loss']; ?></td>
                  <td><?php echo number_format((float)$r['win_rate'], 3); ?></td>
                  <td><?php echo number_format((float)$r['match_win_pct'], 3); ?></td>
                  <td><?php echo number_format((float)$r['game_win_pct'], 3); ?></td>
                  <td><?php echo number_format((float)$r['owp'], 3); ?></td>
                  <td><?php echo number_format((float)$r['ogp'], 3); ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php if ($showTimerFirst): ?>
  <div class="card mb-3" id="round-timer">
    <div class="card-body">
      <div class="section-title section-title--round text-center">Round Timer</div>
      <hr class="mt-0 mb-3">
      <?php foreach ($notices['timer'] as $n): ?>
        <div class="alert alert-<?php echo e($n['type']); ?> py-1 text-center mb-2"><?php echo e($n['msg']); ?></div>
      <?php endforeach; ?>
      <?php if ($roundCompleted): ?>
        <div class="fw-bold text-center text-dark bg-warning rounded py-2 mb-2">Round Complete</div>
      <?php elseif (!$pairingLocked): ?>
        <div class="fw-bold text-center text-white bg-danger rounded py-2 mb-2">Lock Pairings to Set Time</div>
      <?php elseif ($timerStarted || $timerRunning): ?>
        <div class="fw-bold text-center text-white bg-success rounded py-2 mb-2">ROUND BEGINS</div>
      <?php else: ?>
        <div class="fw-bold text-center text-white bg-success rounded py-2 mb-2">YOU MAY NOW SET THE TIME</div>
      <?php endif; ?>
      <div class="round-timer text-center mb-3" data-start="<?php echo (int)($timerStart ?? 0); ?>" data-end="<?php echo (int)($timerEnd ?? 0); ?>" data-running="<?php echo $timerRunning ? '1' : '0'; ?>" data-limit="<?php echo (int)$limitSeconds; ?>">
        <div class="display-6 fw-semibold timer-elapsed"><?php echo e($formatSeconds((int)$elapsed)); ?></div>
        <div class="small text-muted">Overtime: <span class="timer-overtime"><?php echo e($formatSeconds((int)$overtime)); ?></span></div>
        <div class="small text-muted">Limit: <?php echo $timeLimit > 0 ? (int)$timeLimit . ' min' : 'Not set'; ?></div>
      </div>

      <div class="d-flex flex-wrap justify-content-center gap-2 mb-2">
        <?php if (!$timerLocked): ?>
          <form method="post" action="?r=admin/setRoundTimer" data-anchor="round-timer" onsubmit="return confirm('Set this round to ' + this.minutes.value + ' minute(s)? This will lock the time.');">
            <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
            <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
            <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
            <div class="input-group input-group-sm">
              <input class="form-control" type="number" name="minutes" min="1" placeholder="Minutes" required <?php echo ($pairingLocked && !$roundCompleted) ? '' : 'disabled'; ?>>
              <button class="btn btn-outline-dark" <?php echo ($pairingLocked && !$roundCompleted) ? '' : 'disabled'; ?>>Set Time</button>
            </div>
          </form>
        <?php else: ?>
          <span class="badge text-bg-secondary align-self-center">TIME LOCKED</span>
        <?php endif; ?>
      </div>

      <div class="d-flex flex-column align-items-center gap-3 mb-3">
        <form method="post" action="?r=admin/startRoundTimer" data-anchor="round-timer">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
          <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
          <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
          <button class="btn btn-success btn-sm btn-lg fw-bold w-100" <?php echo ($roundCompleted || $timerRunning || $timerStarted || !$timerLocked) ? 'disabled' : ''; ?>>Start Timer</button>
        </form>
        <form method="post" action="?r=admin/stopRoundTimer" data-anchor="round-timer">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
          <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
          <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
          <button class="btn btn-outline-danger btn-sm btn-lg fw-bold w-100" <?php echo ($roundCompleted || !$timerRunning || !$allLocked) ? 'disabled' : ''; ?>>Stop Timer</button>
        </form>
      </div>
    </div>
  </div>

  <hr class="my-4">
<?php endif; ?>

<div id="pods-list" class="pod-list-scroll">
  <div class="pod-list-header">
    <div class="section-title section-title--round text-center mb-1 <?php echo $pairingLocked ? 'bg-success bg-opacity-25 text-dark' : ''; ?>">
      ROUND #<?php echo (int)$roundNum; ?> POD LIST
    </div>
    <?php if ($pairingLocked): ?>
      <div class="text-center small text-muted mb-2">PODS READY FOR POSTING</div>
    <?php endif; ?>
    <hr class="mt-0 mb-3">
  </div>
  <?php foreach ($notices['pods'] as $n): ?>
    <div class="alert alert-<?php echo e($n['type']); ?> py-1 text-center mb-2"><?php echo e($n['msg']); ?></div>
  <?php endforeach; ?>
  <div class="row g-3">
<?php foreach ((array)($round['pods'] ?? []) as $podIndex => $pod): ?>
  <?php
    $podLocked = !empty($pod['locked']);
    $podSaved = !empty($pod['saved']);
    $pList = (array)($pod['players'] ?? []);
    $scores = (array)($pod['scores'] ?? []);
    $maxScore = null;
    $tie = false;
    if ($podLocked) {
      $minScoreVal = null;
      foreach ($pList as $email) {
        if ($scores[$email] !== null) {
          $val = (int)$scores[$email];
          if ($maxScore === null || $val > $maxScore) {
            $maxScore = $val;
          }
          if ($minScoreVal === null || $val < $minScoreVal) {
            $minScoreVal = $val;
          }
        }
      }
      if ($maxScore !== null && $minScoreVal !== null) {
        if ($isOneVOne) {
          $tie = ($maxScore === $minScoreVal);
        } elseif ($isUnlimited) {
          $tie = ($maxScore === $minScoreVal);
        } else {
          $tie = ($maxScore <= 2);
        }
      }
      if ($tie) {
        $maxScore = null;
      }
    }
    $cardClass = 'card h-100';
    if ($podLocked) {
      $cardClass .= ' bg-warning bg-opacity-25 border-2 border-danger';
    } elseif ($podSaved) {
      $cardClass .= ' bg-info bg-opacity-25 border-success';
    } elseif ($pairingLocked) {
      $cardClass .= ' bg-light border-2';
    }

    $repeatPairs = [];
    for ($i = 0; $i < count($pList); $i++) {
      for ($j = $i + 1; $j < count($pList); $j++) {
        $a = $pList[$i];
        $b = $pList[$j];
        $key = ($a < $b) ? ($a . '|' . $b) : ($b . '|' . $a);
        if (!empty($priorPairs[$key])) {
          $repeatPairs[] = [$a, $b];
        }
      }
    }
    if (!empty($repeatPairs) && !$podLocked) {
      $cardClass .= ' border-warning';
    }
  ?>
  <div class="col-12 col-md-6" data-scroll-target="pod-<?php echo (int)$podIndex; ?>">
    <div class="<?php echo $cardClass; ?>">
      <div class="card-body">
      <div class="text-center fw-bold fs-5">
        Table <?php echo (int)($podIndex + 1); ?>
        <?php if (!empty($pod['bye'])): ?>
          <span class="badge text-bg-info ms-1">BYE</span>
        <?php endif; ?>
      </div>
      <hr class="my-2">
      <div class="text-center">
        <?php if ($podLocked): ?>
          <span class="badge text-bg-danger">LOCKED</span>
        <?php elseif ($podSaved): ?>
          <span class="badge text-bg-success">SAVED</span>
        <?php else: ?>
          <span class="badge text-bg-warning">UNLOCKED</span>
        <?php endif; ?>
      </div>
      <?php if ($podLocked): ?>
        <div class="small text-danger mt-1 text-center">Locked: scores cannot be changed.</div>
      <?php elseif ($podSaved): ?>
        <div class="small text-success mt-1 text-center">Saved: scores can still be edited.</div>
      <?php elseif (!empty($repeatPairs)): ?>
        <div class="small text-warning mt-1 text-center">Repeat pairing detected in this pod.</div>
      <?php endif; ?>
      <?php if (!empty($repeatPairs)): ?>
        <div class="small text-warning mt-1">
          <?php foreach ($repeatPairs as $pair): ?>
            <?php
              $m1 = $playersMeta[$pair[0]] ?? ['name' => $pair[0]];
              $m2 = $playersMeta[$pair[1]] ?? ['name' => $pair[1]];
            ?>
            <?php echo e($m1['name']); ?> &amp; <?php echo e($m2['name']); ?><br>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="post" action="?r=admin/savePodScores" data-anchor="pods-list" data-scroll-target="pod-<?php echo (int)$podIndex; ?>" data-score-min="<?php echo $scoreMin; ?>" data-score-max="<?php echo $scoreMax; ?>" data-total-max="<?php echo $podTotalMax; ?>" data-score-system="<?php echo e($scoreSystem); ?>" data-game-mode="<?php echo e($gameMode); ?>" class="mt-3 pod-score-form">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
        <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
        <input type="hidden" name="pod_id" value="<?php echo e($pod['id']); ?>">
        <input type="hidden" name="pod_table" value="<?php echo (int)($podIndex + 1); ?>">

        <?php if ($isOneVOne): ?>
          <div class="small text-muted text-center mb-2">BO3: 0–2 points per player. 2 points wins the round; equal scores are a tie.</div>
        <?php endif; ?>
        <div class="table-responsive">
          <table class="table table-sm align-middle">
            <thead>
              <tr>
                <th>Player</th>
                <th style="width:180px">Score (<?php echo $scoreMin; ?> to <?php echo $scoreMax; ?>)</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($pList as $email): ?>
                <?php $meta = $playersMeta[$email] ?? ['name'=>$email]; ?>
                <?php
                  $scoreVal = $scores[$email] ?? null;
                  $isTopScore = $podLocked && $maxScore !== null && $scoreVal !== null && (int)$scoreVal === (int)$maxScore;
                  $nameClasses = $isTopScore ? 'fw-bold bg-warning text-dark' : '';
                ?>
                <tr>
                  <td class="<?php echo e($nameClasses); ?>"><?php echo e($meta['name']); ?> <span class="small text-muted">(<?php echo e($email); ?>)</span></td>
                  <td>
                    <?php
                      $scoreClasses = 'form-control form-control-sm score-input';
                      if ($podLocked) {
                        $scoreClasses .= ' text-center';
                      }
                      if ($isTopScore) {
                        $scoreClasses .= ' bg-warning fw-bold text-dark';
                      }
                    ?>
                    <input class="<?php echo e($scoreClasses); ?>"
                           name="scores[<?php echo e($email); ?>]"
                           type="number" min="<?php echo $scoreMin; ?>" max="<?php echo $scoreMax; ?>"
                           value="<?php echo ($scoreVal === null) ? '' : (int)$scoreVal; ?>"
                           <?php echo ($podLocked || !$pairingLocked) ? 'disabled' : ''; ?>>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <div class="d-flex justify-content-center">
          <button class="btn btn-primary btn-sm" <?php echo ($podLocked || !$pairingLocked) ? 'disabled' : ''; ?>>
            Save Scores (Not Locked)
          </button>
        </div>
      </form>

      <form method="post" action="?r=admin/lockPod" data-anchor="pods-list" data-scroll-target="pod-<?php echo (int)$podIndex; ?>" data-confirm="Lock this pod permanently? This cannot be changed." class="mt-2">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
        <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
        <input type="hidden" name="pod_id" value="<?php echo e($pod['id']); ?>">
        <div class="d-flex justify-content-center">
          <button class="btn btn-outline-danger btn-sm" <?php echo ($podLocked || !$pairingLocked || !$podSaved) ? 'disabled' : ''; ?>>
            Lock Pod Scores Permanently
          </button>
        </div>
        <div class="form-text text-center">Locking validates all players scored <?php echo $scoreMin; ?>..<?php echo $scoreMax; ?> and prevents any future edits.</div>
      </form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
</div>
</div>

<?php if (!$showTimerFirst): ?>
  <hr class="my-4">

  <div class="card mb-3" id="round-timer">
    <div class="card-body">
      <div class="section-title section-title--round text-center">Round Timer</div>
      <hr class="mt-0 mb-3">
      <?php foreach ($notices['timer'] as $n): ?>
        <div class="alert alert-<?php echo e($n['type']); ?> py-1 text-center mb-2"><?php echo e($n['msg']); ?></div>
      <?php endforeach; ?>
      <?php if ($roundCompleted): ?>
        <div class="fw-bold text-center text-dark bg-warning rounded py-2 mb-2">Round Complete</div>
      <?php elseif (!$pairingLocked): ?>
        <div class="fw-bold text-center text-white bg-danger rounded py-2 mb-2">Lock Pairings to Set Time</div>
      <?php elseif ($timerStarted || $timerRunning): ?>
        <div class="fw-bold text-center text-white bg-success rounded py-2 mb-2">ROUND BEGINS</div>
      <?php else: ?>
        <div class="fw-bold text-center text-white bg-success rounded py-2 mb-2">YOU MAY NOW SET THE TIME</div>
      <?php endif; ?>
      <div class="round-timer text-center mb-3" data-start="<?php echo (int)($timerStart ?? 0); ?>" data-end="<?php echo (int)($timerEnd ?? 0); ?>" data-running="<?php echo $timerRunning ? '1' : '0'; ?>" data-limit="<?php echo (int)$limitSeconds; ?>">
        <div class="display-6 fw-semibold timer-elapsed"><?php echo e($formatSeconds((int)$elapsed)); ?></div>
        <div class="small text-muted">Overtime: <span class="timer-overtime"><?php echo e($formatSeconds((int)$overtime)); ?></span></div>
        <div class="small text-muted">Limit: <?php echo $timeLimit > 0 ? (int)$timeLimit . ' min' : 'Not set'; ?></div>
      </div>

      <div class="d-flex flex-wrap justify-content-center gap-2 mb-2">
        <?php if (!$timerLocked): ?>
          <form method="post" action="?r=admin/setRoundTimer" data-anchor="round-timer" onsubmit="return confirm('Set this round to ' + this.minutes.value + ' minute(s)? This will lock the time.');">
            <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
            <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
            <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
            <div class="input-group input-group-sm">
              <input class="form-control" type="number" name="minutes" min="1" placeholder="Minutes" required <?php echo ($pairingLocked && !$roundCompleted) ? '' : 'disabled'; ?>>
              <button class="btn btn-outline-dark" <?php echo ($pairingLocked && !$roundCompleted) ? '' : 'disabled'; ?>>Set Time</button>
            </div>
          </form>
        <?php else: ?>
          <span class="badge text-bg-secondary align-self-center">TIME LOCKED</span>
        <?php endif; ?>
      </div>

      <div class="d-flex flex-column align-items-center gap-3 mb-3">
        <form method="post" action="?r=admin/startRoundTimer" data-anchor="round-timer">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
          <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
          <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
          <button class="btn btn-success btn-sm btn-lg fw-bold w-100" <?php echo ($roundCompleted || $timerRunning || $timerStarted || !$timerLocked) ? 'disabled' : ''; ?>>Start Timer</button>
        </form>
        <form method="post" action="?r=admin/stopRoundTimer" data-anchor="round-timer">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
          <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
          <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
          <button class="btn btn-outline-danger btn-sm btn-lg fw-bold w-100" <?php echo ($roundCompleted || !$timerRunning || !$allLocked) ? 'disabled' : ''; ?>>Stop Timer</button>
        </form>
      </div>
    </div>
  </div>

  <hr class="my-4">
<?php endif; ?>

<div class="card mb-3" id="second-screen-controls">
  <div class="card-body">
    <div class="section-title section-title--round text-center">Second Screen Controls</div>
    <hr class="mt-0 mb-3">
    <?php foreach ($notices['display'] as $n): ?>
      <div class="alert alert-<?php echo e($n['type']); ?> py-1 text-center mb-2"><?php echo e($n['msg']); ?></div>
    <?php endforeach; ?>
    <div class="d-flex flex-column align-items-center gap-2">
      <a class="btn btn-primary btn-lg fw-bold" href="?r=display/round&id=<?php echo e($game['id']); ?>&round=<?php echo (int)$roundNum; ?>" target="_blank" rel="noopener">Open Display</a>
      <form method="post" action="?r=admin/setDisplayPods" data-anchor="second-screen-controls">
        <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
        <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
        <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
        <input type="hidden" name="show" value="<?php echo $displayShowPods ? '0' : '1'; ?>">
        <button class="btn btn-warning btn-lg fw-bold" <?php echo (!$pairingLocked || $roundCompleted) ? 'disabled' : ''; ?>>
          <?php echo $displayShowPods ? 'Hide Pods on Display' : 'Show Pods on Display'; ?>
        </button>
      </form>
      <?php if ($roundCompleted): ?>
        <form method="post" action="?r=admin/setDisplayResults" data-anchor="second-screen-controls">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
          <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
          <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
          <input type="hidden" name="show" value="<?php echo !empty($round['display_show_results']) ? '0' : '1'; ?>">
          <button class="btn btn-success btn-lg fw-bold">
            <?php echo !empty($round['display_show_results']) ? 'Hide Results on Display' : 'Show Results on Display'; ?>
          </button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="card mb-3" id="round-actions">
  <div class="card-body">
    <div class="section-title section-title--round text-center">Round Actions</div>
    <hr class="mt-0 mb-3">
    <?php foreach ($notices['actions'] as $n): ?>
      <div class="alert alert-<?php echo e($n['type']); ?> py-1 text-center mb-2"><?php echo e($n['msg']); ?></div>
    <?php endforeach; ?>
    <div class="d-flex flex-column align-items-center gap-2">
      <a class="btn btn-outline-secondary btn-sm" href="?r=admin/viewGame&id=<?php echo e($game['id']); ?>">Back to Game View</a>
      <?php if (!$roundCompleted): ?>
        <form method="post" action="?r=admin/completeRound" data-anchor="round-actions" data-confirm="Complete this round? This will publish the current standings.">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
          <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
          <input type="hidden" name="round" value="<?php echo (int)$roundNum; ?>">
          <button class="btn btn-outline-success btn-lg fw-bold" <?php echo ($timerRunning || !$allLocked) ? 'disabled' : ''; ?>>Complete Round</button>
        </form>
      <?php else: ?>
        <div class="d-flex flex-column align-items-center gap-1 w-100">
          <?php if ($roundCompletedAt !== ''): ?>
            <span class="small text-muted">Completed: <?php echo e($roundCompletedAt); ?></span>
          <?php endif; ?>
          <span class="badge text-bg-success">ROUND COMPLETE</span>
        </div>
      <?php endif; ?>
      <a class="btn btn-primary btn-sm <?php echo $roundCompleted ? '' : 'disabled'; ?>" href="?r=admin/viewGame&id=<?php echo e($game['id']); ?>" <?php echo $roundCompleted ? '' : 'aria-disabled="true" tabindex="-1"'; ?>>Proceed to Next Round</a>
      <?php if ((($game['status'] ?? '') === 'active')): ?>
        <?php $canFinalize = $allLocked && $roundCompleted; ?>
        <form method="post" action="?r=admin/endGame" data-anchor="round-actions" data-confirm="Finalize results for this game? You can reopen it later if needed.">
          <input type="hidden" name="csrf" value="<?php echo e($csrf); ?>">
          <input type="hidden" name="game_id" value="<?php echo e($game['id']); ?>">
          <span class="d-inline-block" tabindex="0" data-bs-toggle="tooltip" title="<?php echo $canFinalize ? 'Finalize results for this game.' : 'Complete the round and lock all tables before finalizing.'; ?>">
            <button class="btn btn-danger btn-sm" <?php echo $canFinalize ? '' : 'disabled'; ?>>Finalize Results</button>
          </span>
        </form>
      <?php endif; ?>
      <?php if ($roundCompleted): ?>
        <a class="btn btn-outline-secondary btn-sm" href="?r=admin/printRoundReportPdf&id=<?php echo e($game['id']); ?>&round=<?php echo (int)$roundNum; ?>" target="_blank" rel="noopener">Print Round Report (PDF)</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="card mb-3" id="audit-logs">
  <div class="card-body">
    <div class="section-title section-title--round text-center">AUDIT LOGS</div>
    <hr class="mt-0 mb-3">
    <div class="d-flex justify-content-center mb-2">
      <a class="btn btn-outline-secondary btn-sm" href="?r=admin/printRoundAuditPdf&id=<?php echo e($game['id']); ?>&round=<?php echo (int)$roundNum; ?>" target="_blank" rel="noopener">Print Audit Logs (PDF)</a>
    </div>
    <?php
      $audit = (array)($round['audit'] ?? []);
      $formatAuditTime = function ($ts): string {
        if (!$ts) return '';
        try {
          $dt = new DateTime((string)$ts);
          return $dt->format('y-m-d h:i A');
        } catch (Exception $e) {
          return (string)$ts;
        }
      };
    ?>
    <div class="table-responsive audit-scroll">
      <table class="table table-sm align-middle" data-audit-table="round">
        <thead>
          <tr>
            <th>Game</th>
            <th>Round</th>
            <th>Time</th>
            <th>User</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($audit)): ?>
            <tr data-empty="1"><td colspan="5" class="text-muted text-center">No audit entries yet.</td></tr>
          <?php else: ?>
            <?php foreach ($audit as $entry): ?>
              <tr>
                <td><?php echo e((string)($game['name'] ?? '')); ?></td>
                <td><?php echo (int)$roundNum; ?></td>
                <td data-iso-time="<?php echo e((string)($entry['time'] ?? '')); ?>"><?php echo e($formatAuditTime($entry['time'] ?? '')); ?></td>
                <td><?php echo e((string)($entry['user'] ?? '')); ?></td>
                <td><?php echo e((string)($entry['message'] ?? '')); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div>

<script>
(() => {
  const SECTION_IDS = [
    "round-header",
    "pairings-tools",
    "round-main",
  ];
  const globalAjax = window.MANA_POD_GLOBAL_AJAX === true;
  let timerIntervalId = null;

  function initScoreValidation(root = document) {
    const forms = root.querySelectorAll(".pod-score-form");

    function clearErrors(form) {
      form.querySelectorAll(".score-input").forEach((input) => {
        input.classList.remove("is-invalid");
        input.setCustomValidity("");
      });
    }

    function markInvalid(input, message) {
      input.classList.add("is-invalid");
      input.setCustomValidity(message);
    }

    forms.forEach((form) => {
      if (form.dataset.validationBound === "1") return;
      form.dataset.validationBound = "1";

      const inputs = Array.from(form.querySelectorAll(".score-input"));
      inputs.forEach((input) => {
        input.addEventListener("input", () => {
          input.classList.remove("is-invalid");
          input.setCustomValidity("");
        });
      });

      form.addEventListener("submit", (event) => {
        clearErrors(form);

        const maxScore = Number(form.dataset.scoreMax || 4);
        const minScore = Number(form.dataset.scoreMin || 0);
        const maxTotal = Number(form.dataset.totalMax || 9);
        const isUnlimited = String(form.dataset.scoreSystem || "") === "Point System (Unlimited)";
        const isOneVOne = String(form.dataset.gameMode || "") === "One V One (BO3-SWISS)";

        let total = 0;
        let fourCount = 0;
        let threeCount = 0;

        inputs.forEach((input) => {
          const raw = input.value.trim();
          if (raw === "") {
            markInvalid(input, "All players must have a score before saving.");
            return;
          }
          const val = Number(raw);
          if (Number.isNaN(val)) {
            markInvalid(input, "Score must be a number.");
            return;
          }
          if (val < minScore || val > maxScore) {
            markInvalid(input, `Score must be between ${minScore} and ${maxScore}.`);
            return;
          }
          if (!isUnlimited) {
            if (val === 4) fourCount += 1;
            if (val === 3) threeCount += 1;
          }
          total += val;
        });

        if (!isUnlimited && !isOneVOne && fourCount > 1) {
          inputs.forEach((input) => {
            if (Number(input.value) === 4) {
              markInvalid(input, "Only one player can have a score of 4.");
            }
          });
        }
        if (!isUnlimited && !isOneVOne && threeCount > 1) {
          inputs.forEach((input) => {
            if (Number(input.value) === 3) {
              markInvalid(input, "Only one player can have a score of 3.");
            }
          });
        }

        if (total > maxTotal) {
          inputs.forEach((input) => {
            if (input.value.trim() !== "") {
              markInvalid(input, `Pod total cannot exceed ${maxTotal}.`);
            }
          });
        }

        if (!form.checkValidity()) {
          event.preventDefault();
          form.reportValidity();
        }
      });
    });
  }

  function initRoundTimer() {
    const el = document.querySelector(".round-timer");
    if (timerIntervalId) {
      clearInterval(timerIntervalId);
      timerIntervalId = null;
    }
    if (!el) return;

    const start = Number(el.dataset.start || 0);
    const end = Number(el.dataset.end || 0);
    const running = el.dataset.running === "1";
    const limit = Number(el.dataset.limit || 0);
    const elapsedEl = el.querySelector(".timer-elapsed");
    const overtimeEl = el.querySelector(".timer-overtime");

    function fmt(sec) {
      sec = Math.max(0, sec);
      const h = Math.floor(sec / 3600);
      const m = Math.floor((sec % 3600) / 60);
      const s = Math.floor(sec % 60);
      if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
      return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    }

    function tick() {
      if (!start) return;
      const now = Math.floor(Date.now() / 1000);
      const elapsed = (running ? now : end) - start;
      const overtime = limit > 0 ? Math.max(0, elapsed - limit) : 0;
      if (elapsedEl) elapsedEl.textContent = fmt(elapsed);
      if (overtimeEl) overtimeEl.textContent = fmt(overtime);
    }

    tick();
    if (running) {
      timerIntervalId = setInterval(tick, 1000);
    }
  }

  function setLoading(form, loading) {
    form.querySelectorAll("button, input[type='submit']").forEach((btn) => {
      if (!btn.dataset.ajaxWasDisabled) {
        btn.dataset.ajaxWasDisabled = btn.disabled ? "1" : "0";
      }
      if (loading) {
        btn.disabled = true;
      } else if (btn.dataset.ajaxWasDisabled === "0") {
        btn.disabled = false;
      }
    });
  }

  function updateFromHtml(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    SECTION_IDS.forEach((id) => {
      const fresh = doc.getElementById(id);
      const current = document.getElementById(id);
      if (fresh && current) {
        current.replaceWith(fresh);
      }
    });
    initScoreValidation();
    if (!globalAjax) {
      initAjaxForms();
    }
    initRoundTimer();
  }

  async function submitAjax(form) {
    const scrollY = window.scrollY;
    setLoading(form, true);
    try {
      const response = await fetch(form.action, {
        method: form.method || "POST",
        body: new FormData(form),
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
      });

      if (!response.ok) {
        window.location.reload();
        return;
      }

      const html = await response.text();
      const url = response.url || "";
      if (!url.includes("admin/viewRound")) {
        window.location = url || window.location.href;
        return;
      }

      updateFromHtml(html);
      window.scrollTo(0, scrollY);
    } catch (err) {
      window.location.reload();
    } finally {
      setLoading(form, false);
    }
  }

  function initAjaxForms(root = document) {
    if (globalAjax) return;
    root.querySelectorAll("form[data-anchor]").forEach((form) => {
      if (form.dataset.ajaxBound === "1") return;
      form.dataset.ajaxBound = "1";

      form.addEventListener("submit", (event) => {
        if (event.defaultPrevented) return;
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        submitAjax(form);
      });
    });
  }

  initScoreValidation();
  if (!globalAjax) {
    initAjaxForms();
  }
  initRoundTimer();
})();
</script>


