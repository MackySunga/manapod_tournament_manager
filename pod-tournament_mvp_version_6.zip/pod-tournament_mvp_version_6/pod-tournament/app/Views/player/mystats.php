<h3 class="mb-3">My Stats</h3>

<?php if (empty($perGame)): ?>
  <div class="text-muted">No games yet.</div>
<?php else: ?>
  <div class="row g-3 mb-3">
    <div class="col-md-6 col-lg-4">
      <div class="card h-100">
        <div class="card-body">
          <div class="fw-semibold mb-2">Totals</div>
          <div>Games: <?php echo (int)$overall['games']; ?></div>
          <div>Rounds: <?php echo (int)$overall['rounds']; ?></div>
          <div>Pods: <?php echo (int)$overall['pods']; ?></div>
          <div>Matches: <?php echo (int)$overall['matches']; ?></div>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-4">
      <div class="card h-100">
        <div class="card-body">
          <div class="fw-semibold mb-2">Scoring</div>
          <div>Total score: <?php echo (int)$overall['total_score']; ?></div>
          <div>Win points: <?php echo number_format((float)$overall['wins_points'], 2); ?></div>
          <div>Avg score per entry: <?php echo number_format((float)$overall['avg_score_entry'], 2); ?></div>
        </div>
      </div>
    </div>

    <div class="col-md-12 col-lg-4">
      <div class="card h-100">
        <div class="card-body">
          <div class="fw-semibold mb-2">Rates</div>
          <div>Win rate: <?php echo number_format((float)$overall['win_rate'], 3); ?></div>
          <div>Game-win %: <?php echo number_format((float)$overall['game_win_pct'], 3); ?></div>
          <div>Most frequent opponent:
            <?php if ($overall['most_opp'] !== ''): ?>
              <?php $meta = $playersMeta[$overall['most_opp']] ?? ['name' => $overall['most_opp']]; ?>
              <?php echo e($meta['name']); ?> (<?php echo (int)$overall['most_opp_count']; ?>)
            <?php else: ?>
              N/A
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <div class="fw-semibold mb-2">By Game</div>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>Game</th>
              <th>Date</th>
              <th>Status</th>
              <th>Rounds</th>
              <th>Pods</th>
              <th>Matches</th>
              <th>Total Score</th>
              <th>Win Pts</th>
              <th>Win Rate</th>
              <th>Game-win %</th>
              <th>Top Opponent</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($perGame as $g): ?>
              <?php
                $winRate = $g['matches'] > 0 ? ($g['wins_points'] / $g['matches']) : 0.0;
                $gameWin = $g['matches'] > 0 ? ($g['total_score'] / (4.0 * $g['matches'])) : 0.0;
                $oppName = 'N/A';
                if ($g['most_opp'] !== '') {
                  $meta = $playersMeta[$g['most_opp']] ?? ['name' => $g['most_opp']];
                  $oppName = $meta['name'] . ' (' . (int)$g['most_opp_count'] . ')';
                }
              ?>
              <?php
                $createdAt = (string)($g['created_at'] ?? '');
                $createdLabel = $createdAt !== '' ? date('Y-m-d', strtotime($createdAt)) : '';
              ?>
              <tr>
                <td><?php echo e($g['name']); ?></td>
                <td><?php echo e($createdLabel); ?></td>
                <td><?php echo e($g['status']); ?></td>
                <td><?php echo (int)$g['rounds']; ?></td>
                <td><?php echo (int)$g['pods']; ?></td>
                <td><?php echo (int)$g['matches']; ?></td>
                <td><?php echo (int)$g['total_score']; ?></td>
                <td><?php echo number_format((float)$g['wins_points'], 2); ?></td>
                <td><?php echo number_format((float)$winRate, 3); ?></td>
                <td><?php echo number_format((float)$gameWin, 3); ?></td>
                <td><?php echo e($oppName); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php endif; ?>
