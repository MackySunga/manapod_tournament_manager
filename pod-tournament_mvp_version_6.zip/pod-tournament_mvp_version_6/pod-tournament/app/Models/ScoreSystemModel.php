<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\DataStore;

final class ScoreSystemModel
{
    private DataStore $ds;
    private string $file = 'score_systems.json';

    private array $defaults = [
        'Point System (Limited)',
        'Point System (Unlimited)',
    ];

    public function __construct()
    {
        $this->ds = new DataStore();
    }

    public function all(): array
    {
        $data = $this->ds->load($this->file, ['systems' => []]);
        $systems = array_values(array_filter(array_map('strval', (array)($data['systems'] ?? []))));
        if (empty($systems)) {
            $systems = $this->defaults;
            $this->saveAll($systems);
        }
        return $systems;
    }

    public function add(string $system): bool
    {
        $system = trim($system);
        if ($system === '') return false;

        $systems = $this->all();
        $lower = array_map('strtolower', $systems);
        if (in_array(strtolower($system), $lower, true)) {
            return false;
        }
        $systems[] = $system;
        $this->saveAll($systems);
        return true;
    }

    public function saveAll(array $systems): void
    {
        $systems = array_values(array_filter(array_map('strval', $systems)));
        $this->ds->save($this->file, ['systems' => $systems]);
    }
}
