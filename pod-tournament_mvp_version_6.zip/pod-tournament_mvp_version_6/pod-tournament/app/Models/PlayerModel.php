<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\DataStore;

final class PlayerModel
{
    private DataStore $ds;
    private string $file = 'players.json';

    public function __construct()
    {
        $this->ds = new DataStore();
    }

    public function all(): array
    {
        $data = $this->ds->load($this->file, ['players' => []]);
        return (array)($data['players'] ?? []);
    }

    public function saveAll(array $playersByEmail): void
    {
        $this->ds->save($this->file, ['players' => $playersByEmail]);
    }

    public function delete(string $email): bool
    {
        $email = strtolower(trim($email));
        if ($email === '') return false;

        $all = $this->all();
        if (!isset($all[$email])) {
            return false;
        }
        unset($all[$email]);
        $this->saveAll($all);
        return true;
    }

    public function upsert(string $email, string $name): void
    {
        $email = strtolower(trim($email));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return;

        $name = trim($name);
        if ($name === '') $name = $email;

        $all = $this->all();
        $all[$email] = [
            'email' => $email,
            'name' => $name,
            'created_at' => $all[$email]['created_at'] ?? date('c'),
        ];
        $this->saveAll($all);
    }

    public function count(): int
    {
        return count($this->all());
    }

    public function seedSample(): int
    {
        $sample = [
            ['email'=>'alice@example.com','name'=>'Alice'],
            ['email'=>'bob@example.com','name'=>'Bob'],
            ['email'=>'carla@example.com','name'=>'Carla'],
            ['email'=>'dave@example.com','name'=>'Dave'],
            ['email'=>'erin@example.com','name'=>'Erin'],
            ['email'=>'frank@example.com','name'=>'Frank'],
            ['email'=>'gina@example.com','name'=>'Gina'],
            ['email'=>'hank@example.com','name'=>'Hank'],
            ['email'=>'ivy@example.com','name'=>'Ivy'],
            ['email'=>'jack@example.com','name'=>'Jack'],
            ['email'=>'kira@example.com','name'=>'Kira'],
            ['email'=>'liam@example.com','name'=>'Liam'],
            ['email'=>'maya@example.com','name'=>'Maya'],
            ['email'=>'nate@example.com','name'=>'Nate'],
            ['email'=>'olivia@example.com','name'=>'Olivia'],
            ['email'=>'paul@example.com','name'=>'Paul'],
            ['email'=>'quinn@example.com','name'=>'Quinn'],
            ['email'=>'riley@example.com','name'=>'Riley'],
            ['email'=>'sam@example.com','name'=>'Sam'],
            ['email'=>'tessa@example.com','name'=>'Tessa'],
            ['email'=>'umar@example.com','name'=>'Umar'],
            ['email'=>'vera@example.com','name'=>'Vera'],
            ['email'=>'wade@example.com','name'=>'Wade'],
            ['email'=>'xena@example.com','name'=>'Xena'],
            ['email'=>'yara@example.com','name'=>'Yara'],
            ['email'=>'zoe@example.com','name'=>'Zoe'],
        ];
        foreach ($sample as $s) $this->upsert($s['email'], $s['name']);
        return count($sample);
    }
}
