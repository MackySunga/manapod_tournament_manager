<?php
declare(strict_types=1);

namespace App\Services;

final class DataStore
{
    private function path(string $file): string
    {
        return rtrim(STORAGE_PATH, '/\\') . '/' . $file;
    }

    public function load(string $file, array $default = []): array
    {
        $path = $this->path($file);
        if (!is_file($path)) return $default;

        $raw = file_get_contents($path);
        if ($raw === false || trim($raw) === '') return $default;

        $data = json_decode($raw, true);
        return is_array($data) ? $data : $default;
    }

    public function save(string $file, array $data): void
    {
        $path = $this->path($file);

        $dir = dirname($path);
        if (!is_dir($dir)) mkdir($dir, 0777, true);

        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            throw new \RuntimeException("JSON encode failed for $file");
        }

        $tmp = $path . '.tmp';

        $fp = fopen($tmp, 'wb');
        if (!$fp) throw new \RuntimeException("Cannot write tmp file: $tmp");

        fwrite($fp, $json);
        fclose($fp);

        rename($tmp, $path);
    }
}
