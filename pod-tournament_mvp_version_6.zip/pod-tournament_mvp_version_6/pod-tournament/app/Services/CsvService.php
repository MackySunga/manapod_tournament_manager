<?php
declare(strict_types=1);

namespace App\Services;

final class CsvService
{
    /**
     * Expects CSV columns: email,name,role,password
     * Returns: array of ['email'=>..., 'name'=>..., 'role'=>..., 'password'=>...]
     */
    public function read(string $tmpPath): array
    {
        $rows = [];
        $fh = fopen($tmpPath, 'rb');
        if (!$fh) return $rows;

        $header = fgetcsv($fh);
        if (!is_array($header)) { fclose($fh); return $rows; }

        $map = [];
        foreach ($header as $i => $col) {
            $col = strtolower(trim((string)$col));
            $map[$col] = $i;
        }

        while (($r = fgetcsv($fh)) !== false) {
            $email = strtolower(trim((string)($r[$map['email'] ?? -1] ?? '')));
            $name  = trim((string)($r[$map['name'] ?? -1] ?? ''));
            $role  = strtolower(trim((string)($r[$map['role'] ?? -1] ?? '')));
            $pass  = (string)($r[$map['password'] ?? -1] ?? '');

            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) continue;
            if ($name === '') $name = $email;
            if ($role === '') $role = 'player';

            $rows[] = [
                'email' => $email,
                'name' => $name,
                'role' => $role,
                'password' => $pass,
            ];
        }

        fclose($fh);
        return $rows;
    }
    /**
     * Expects CSV columns: email,name
     * Returns: array of ['email'=>..., 'name'=>...]
     */
    public function parsePlayersCsv(string $tmpPath): array
    {
        $rows = [];
        $fh = fopen($tmpPath, 'rb');
        if (!$fh) return $rows;

        $header = fgetcsv($fh);
        if (!is_array($header)) { fclose($fh); return $rows; }

        $map = [];
        foreach ($header as $i => $col) {
            $col = strtolower(trim((string)$col));
            $map[$col] = $i;
        }

        while (($r = fgetcsv($fh)) !== false) {
            $email = strtolower(trim((string)($r[$map['email'] ?? -1] ?? '')));
            $name  = trim((string)($r[$map['name'] ?? -1] ?? ''));

            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) continue;
            if ($name === '') $name = $email;

            $rows[] = ['email' => $email, 'name' => $name];
        }

        fclose($fh);
        return $rows;
    }

    public function blankTemplateCsv(): string
    {
        return "email,name\nplayer1@example.com,Player One\n";
    }

    public function templateGuideText(): string
    {
        return implode("\n", [
            "CSV Upload Guide",
            "",
            "1) File must be CSV (Comma-Separated Values).",
            "2) Required headers: email,name",
            "3) email must be valid and unique (used as Player ID).",
            "4) name can be blank; system will use the email as fallback.",
            "",
            "Example:",
            "email,name",
            "alice@example.com,Alice",
            "bob@example.com,Bob",
        ]);
    }
}
