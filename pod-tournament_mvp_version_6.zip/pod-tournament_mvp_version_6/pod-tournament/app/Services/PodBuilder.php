<?php
declare(strict_types=1);

namespace App\Services;

final class PodBuilder
{
    /**
     * Build pods for a round.
     *
     * $players: list of player emails in the game
     * $mode:
     *  - ranking_top4
     *  - ranking_highlow
     *  - swiss_pods (recommended)
     *  - true_swiss
     *  - power_pods
     *  - bubble_pods
     *  - random_pods
     *  - top1_low3
     *  - random_limited_repeats
     *  - alpha_no_repeat
     *
     * $historyPairs: associative "a|b" => count, where a<b
     *
     * Returns array of pods: [ ['p1','p2','p3','p4'], ... ] (pods can be size 3,4,5)
     */
    public function buildPods(
        array $players,
        string $mode,
        array $playersMetaByEmail,
        array $rankingOrder,
        array $historyPairs,
        array $statsByEmail
    ): array
    {
        $players = array_values(array_unique(array_map('strtolower', $players)));
        $n = count($players);

        if ($n === 0) return [];

        // Special rule: if total players == 5, one pod of 5.
        if ($n === 5) {
            $pod = $players;
            shuffle($pod);
            return [$pod];
        }

        $ordered = $players;

        if ($mode === 'swiss') {
            $mode = 'swiss_pods';
        }

        if ($mode === 'ranking_top4') {
            // rankingOrder already sorted best->worst; filter to only players in game
            $ordered = array_values(array_filter($rankingOrder, fn($e) => in_array($e, $players, true)));
        } elseif ($mode === 'ranking_highlow') {
            $ordered = array_values(array_filter($rankingOrder, fn($e) => in_array($e, $players, true)));
        } elseif (in_array($mode, ['swiss_pods', 'true_swiss', 'power_pods', 'bubble_pods', 'top1_low3'], true)) {
            $ordered = array_values(array_filter($rankingOrder, fn($e) => in_array($e, $players, true)));
        } elseif ($mode === 'alpha_no_repeat') {
            usort($ordered, function($a, $b) use ($playersMetaByEmail) {
                $na = strtolower((string)($playersMetaByEmail[$a]['name'] ?? $a));
                $nb = strtolower((string)($playersMetaByEmail[$b]['name'] ?? $b));
                return $na <=> $nb;
            });
        } else {
            // random_limited_repeats default
            shuffle($ordered);
        }

        // Initial pod formation (mostly 4s)
        if ($mode === 'ranking_highlow') {
            $pods = $this->podsHighLow($ordered);
        } elseif ($mode === 'swiss_pods') {
            $pods = $this->podsSwiss($ordered, $historyPairs);
        } elseif ($mode === 'true_swiss') {
            $pods = $this->podsSwissByScore($ordered, $historyPairs, $statsByEmail, false);
        } elseif ($mode === 'power_pods') {
            $pods = $this->podsChunk4($ordered);
        } elseif ($mode === 'bubble_pods') {
            $pods = $this->podsSwissByScore($ordered, $historyPairs, $statsByEmail, true);
        } elseif ($mode === 'random_pods') {
            $pods = $this->podsRandomLimitedRepeats($ordered, $historyPairs);
        } elseif ($mode === 'top1_low3') {
            $pods = $this->podsTop1Low3($ordered);
        } elseif ($mode === 'random_limited_repeats') {
            $pods = $this->podsRandomLimitedRepeats($ordered, $historyPairs);
        } elseif ($mode === 'alpha_no_repeat') {
            $pods = $this->podsAlphaNoRepeat($ordered, $historyPairs, $playersMetaByEmail);
        } else {
            $pods = $this->podsChunk4($ordered);
        }

        // Apply remainder rules to convert 1/2 leftovers into 3s (except total=5 already handled)
        $pods = $this->applyRemainderRules($pods);
        return $this->shufflePods($pods);
    }

    public function buildPodsOneVOne(
        array $players,
        int $roundNum,
        array $historyPairs,
        array $rankingOrder,
        array $byeHistory
    ): array
    {
        $players = array_values(array_unique(array_map('strtolower', $players)));
        if (empty($players)) return ['pods' => [], 'bye' => null];

        if ($roundNum === 1) {
            $ordered = $players;
            shuffle($ordered);
        } else {
            $ordered = array_values(array_filter($rankingOrder, fn($e) => in_array($e, $players, true)));
        }

        $byePlayer = null;
        if (count($ordered) % 2 === 1) {
            if ($roundNum === 1) {
                $byePlayer = $ordered[array_rand($ordered)];
            } else {
                $byePlayer = $this->pickByePlayer($ordered, $byeHistory);
            }
            $ordered = array_values(array_filter($ordered, fn($p) => $p !== $byePlayer));
        }

        $pairs = [];
        for ($i = 0; $i < count($ordered); $i += 2) {
            $pairs[] = array_slice($ordered, $i, 2);
        }

        $pairs = $this->reduceRepeatPairs($pairs, $historyPairs);

        if ($byePlayer !== null) {
            $pairs[] = [$byePlayer];
        }

        $pairs = $this->shufflePods($pairs);

        return ['pods' => $pairs, 'bye' => $byePlayer];
    }

    public function buildPodsOneVOneWithBye(
        array $players,
        array $historyPairs,
        array $rankingOrder,
        string $byePlayer
    ): array
    {
        $players = array_values(array_unique(array_map('strtolower', $players)));
        if (empty($players)) return [];

        $byePlayer = strtolower($byePlayer);
        $ordered = array_values(array_filter($rankingOrder, fn($e) => in_array($e, $players, true)));
        if (!in_array($byePlayer, $players, true)) {
            return [];
        }
        $ordered = array_values(array_filter($ordered, fn($p) => $p !== $byePlayer));

        $pairs = [];
        for ($i = 0; $i < count($ordered); $i += 2) {
            $pairs[] = array_slice($ordered, $i, 2);
        }

        $pairs = $this->reduceRepeatPairs($pairs, $historyPairs);
        $pairs[] = [$byePlayer];
        return $this->shufflePods($pairs);
    }

    private function shufflePods(array $pods): array
    {
        foreach ($pods as &$pod) {
            if (count($pod) > 1) {
                $tmp = array_values($pod);
                shuffle($tmp);
                $pod = $tmp;
            }
        }
        unset($pod);
        return $pods;
    }

    private function podsChunk4(array $ordered): array
    {
        $pods = [];
        for ($i=0; $i<count($ordered); $i+=4) {
            $pods[] = array_slice($ordered, $i, 4);
        }
        return $pods;
    }

    private function podsSwiss(array $ordered, array $historyPairs): array
    {
        // Swiss-style: keep ranking order, then fill each pod with players
        // that minimize repeat pairings with the current pod.
        $remaining = array_values($ordered);
        $pods = [];

        while (count($remaining) > 0) {
            $pod = [array_shift($remaining)];
            while (count($pod) < 4 && count($remaining) > 0) {
                $bestIdx = 0;
                $bestPenalty = PHP_INT_MAX;
                foreach ($remaining as $idx => $candidate) {
                    $penalty = 0;
                    foreach ($pod as $p) {
                        $key = $this->pairKey($candidate, $p);
                        $penalty += (int)($historyPairs[$key] ?? 0);
                    }
                    if ($penalty < $bestPenalty) {
                        $bestPenalty = $penalty;
                        $bestIdx = $idx;
                        if ($bestPenalty === 0) break;
                    }
                }
                $pod[] = $remaining[$bestIdx];
                array_splice($remaining, $bestIdx, 1);
            }
            $pods[] = $pod;
        }

        return $pods;
    }

    private function podsSwissByScore(array $ordered, array $historyPairs, array $statsByEmail, bool $strict): array
    {
        $buckets = $this->groupByScore($ordered, $statsByEmail);
        $pods = [];
        $carry = [];

        foreach ($buckets as $bucket) {
            $pool = $strict ? array_values($bucket) : array_values(array_merge($carry, $bucket));
            $carry = [];

            $pods = array_merge($pods, $this->podsSwissFullPods($pool, $historyPairs, $pool));

            if ($strict) {
                if (!empty($pool)) {
                    $pods[] = $pool;
                }
            } else {
                if (!empty($pool)) {
                    $carry = $pool;
                }
            }
        }

        if (!$strict && !empty($carry)) {
            $pods[] = $carry;
        }

        return $pods;
    }

    private function podsSwissFullPods(array $pool, array $historyPairs, array &$carry): array
    {
        $pool = array_values($pool);
        $pods = [];

        while (count($pool) >= 4) {
            $pod = [array_shift($pool)];
            while (count($pod) < 4 && count($pool) > 0) {
                $bestIdx = 0;
                $bestPenalty = PHP_INT_MAX;
                foreach ($pool as $idx => $candidate) {
                    $penalty = 0;
                    foreach ($pod as $p) {
                        $key = $this->pairKey($candidate, $p);
                        $penalty += (int)($historyPairs[$key] ?? 0);
                    }
                    if ($penalty < $bestPenalty) {
                        $bestPenalty = $penalty;
                        $bestIdx = $idx;
                        if ($bestPenalty === 0) break;
                    }
                }
                $pod[] = $pool[$bestIdx];
                array_splice($pool, $bestIdx, 1);
            }
            $pods[] = $pod;
        }

        $carry = $pool;
        return $pods;
    }

    private function podsTop1Low3(array $ordered): array
    {
        $pods = [];
        $hi = 0;
        $lo = count($ordered) - 1;

        while ($hi <= $lo) {
            $pod = [];
            if ($hi <= $lo) {
                $pod[] = $ordered[$hi];
                $hi++;
            }
            for ($i = 0; $i < 3 && $hi <= $lo; $i++) {
                $pod[] = $ordered[$lo];
                $lo--;
            }
            $pods[] = $pod;
        }

        return $pods;
    }

    private function groupByScore(array $ordered, array $statsByEmail): array
    {
        $groups = [];
        foreach ($ordered as $email) {
            $score = (int)($statsByEmail[$email]['total_score'] ?? 0);
            $groups[$score][] = $email;
        }
        krsort($groups);
        return array_values($groups);
    }

    private function podsHighLow(array $ordered): array
    {
        // Build pods mixing top 2 and bottom 2 repeatedly
        $pods = [];
        $lo = 0;
        $hi = count($ordered) - 1;

        while ($lo <= $hi) {
            $pod = [];
            for ($i=0; $i<2 && $lo <= $hi; $i++) $pod[] = $ordered[$lo++];
            for ($i=0; $i<2 && $lo <= $hi; $i++) $pod[] = $ordered[$hi--];
            $pods[] = $pod;
        }
        return $pods;
    }

    private function podsRandomLimitedRepeats(array $ordered, array $historyPairs): array
    {
        // Constraint interpretation:
        // "no more than three players are playing with each other again"
        // -> for a 4-player pod, max 3 repeated PAIRINGS (out of 6).
        $best = $this->podsChunk4($ordered);
        $bestPenalty = PHP_INT_MAX;

        for ($try=0; $try<600; $try++) {
            $cand = $ordered;
            shuffle($cand);

            $pods = $this->podsChunk4($cand);
            $pods = $this->applyRemainderRules($pods);

            $penalty = 0;
            foreach ($pods as $pod) {
                $penalty += $this->repeatPairCount($pod, $historyPairs);
                $max = (count($pod) === 4) ? 3 : ((count($pod) === 3) ? 1 : 6);
                if ($this->repeatPairCount($pod, $historyPairs) > $max) {
                    $penalty += 100; // heavy penalty if violating
                }
            }

            if ($penalty < $bestPenalty) {
                $bestPenalty = $penalty;
                $best = $pods;
                if ($bestPenalty === 0) break;
            }
        }

        return $best;
    }

    private function podsAlphaNoRepeat(array $ordered, array $historyPairs, array $playersMetaByEmail): array
    {
        // Strict attempt: avoid any repeated pair in the same pod
        // If impossible, fallback to "least repeats" greedy swaps.
        $pods = $this->podsChunk4($ordered);
        $pods = $this->applyRemainderRules($pods);

        $ok = true;
        foreach ($pods as $pod) {
            if ($this->repeatPairCount($pod, $historyPairs) > 0) { $ok = false; break; }
        }
        if ($ok) return $pods;

        // Fallback: do swap attempts to reduce repeats
        for ($pass=0; $pass<200; $pass++) {
            $improved = false;
            for ($i=0; $i<count($pods); $i++) {
                for ($j=$i+1; $j<count($pods); $j++) {
                    for ($a=0; $a<count($pods[$i]); $a++) {
                        for ($b=0; $b<count($pods[$j]); $b++) {
                            $before = $this->repeatPairCount($pods[$i], $historyPairs) + $this->repeatPairCount($pods[$j], $historyPairs);

                            $tmp = $pods;
                            $x = $tmp[$i][$a];
                            $y = $tmp[$j][$b];
                            $tmp[$i][$a] = $y;
                            $tmp[$j][$b] = $x;

                            $after = $this->repeatPairCount($tmp[$i], $historyPairs) + $this->repeatPairCount($tmp[$j], $historyPairs);

                            if ($after < $before) {
                                $pods = $tmp;
                                $improved = true;
                            }
                        }
                    }
                }
            }
            if (!$improved) break;
        }

        return $pods;
    }

    private function applyRemainderRules(array $pods): array
    {
        // If last pod has <4 players, apply your rules using pulls from previous pods
        // Note: total=5 already handled earlier.
        $pods = array_values(array_filter($pods, fn($p) => count($p) > 0));

        $lastIdx = count($pods) - 1;
        if ($lastIdx < 0) return [];

        $lastSize = count($pods[$lastIdx]);

        if ($lastSize === 1) {
            // Need to pull one player from two pods -> create three 3-player pods
            if (count($pods) < 3) return $pods; // safety

            $leftover = array_pop($pods)[0];

            $podA = array_pop($pods);
            $podB = array_pop($pods);

            $p1 = array_pop($podA);
            $p2 = array_pop($podB);

            $pods[] = $podB;      // now size 3
            $pods[] = $podA;      // now size 3
            $pods[] = [$leftover, $p1, $p2]; // new size 3
        }
        elseif ($lastSize === 2) {
            // Pull one from one pod -> two 3-player pods
            if (count($pods) < 2) return $pods;

            $leftover = array_pop($pods);

            $podA = array_pop($pods);
            $p1 = array_pop($podA);

            $pods[] = $podA;                 // now size 3
            $pods[] = array_merge($leftover, [$p1]); // now size 3
        }
        elseif ($lastSize === 3) {
            // allowed as is
        }
        elseif ($lastSize === 5) {
            // allowed (only happens if someone forced it)
        }

        return $this->balanceSmallPods($pods);
    }

    private function pickByePlayer(array $ordered, array $byeHistory): string
    {
        $byeHistory = array_change_key_case((array)$byeHistory, CASE_LOWER);
        for ($i = count($ordered) - 1; $i >= 0; $i--) {
            $p = $ordered[$i];
            if (empty($byeHistory[$p])) {
                return $p;
            }
        }
        return $ordered[count($ordered) - 1];
    }

    private function reduceRepeatPairs(array $pairs, array $historyPairs): array
    {
        $pairs = array_values($pairs);
        $count = count($pairs);
        for ($i = 0; $i < $count; $i++) {
            if (count($pairs[$i]) !== 2) continue;
            if ($this->repeatPairCount($pairs[$i], $historyPairs) === 0) continue;
            for ($j = $i + 1; $j < $count; $j++) {
                if (count($pairs[$j]) !== 2) continue;
                $a = $pairs[$i][0];
                $b = $pairs[$i][1];
                $c = $pairs[$j][0];
                $d = $pairs[$j][1];

                $before = $this->repeatPairCount([$a, $b], $historyPairs) + $this->repeatPairCount([$c, $d], $historyPairs);
                $afterSwap = $this->repeatPairCount([$a, $d], $historyPairs) + $this->repeatPairCount([$c, $b], $historyPairs);
                if ($afterSwap < $before) {
                    $pairs[$i][1] = $d;
                    $pairs[$j][1] = $b;
                    break;
                }
            }
        }
        return $pairs;
    }

    private function balanceSmallPods(array $pods): array
    {
        $pods = array_values(array_filter($pods, fn($p) => count($p) > 0));
        $changed = true;
        while ($changed) {
            $changed = false;
            $smallIdx = null;
            foreach ($pods as $i => $pod) {
                if (count($pod) === 2) {
                    $smallIdx = $i;
                    break;
                }
            }
            if ($smallIdx === null) break;

            $donorIdx = null;
            $donorSize = 0;
            foreach ($pods as $i => $pod) {
                $size = count($pod);
                if ($i !== $smallIdx && $size > 3 && $size > $donorSize) {
                    $donorIdx = $i;
                    $donorSize = $size;
                }
            }
            if ($donorIdx !== null) {
                $donor = $pods[$donorIdx];
                $moved = array_pop($donor);
                $pods[$donorIdx] = $donor;
                $pods[$smallIdx][] = $moved;
                $changed = true;
                continue;
            }

            $otherIdx = null;
            foreach ($pods as $i => $pod) {
                if ($i !== $smallIdx && count($pod) === 2) {
                    $otherIdx = $i;
                    break;
                }
            }
            if ($otherIdx !== null) {
                $merged = array_merge($pods[$smallIdx], $pods[$otherIdx]);
                $newPods = [];
                foreach ($pods as $i => $pod) {
                    if ($i === $smallIdx || $i === $otherIdx) continue;
                    $newPods[] = $pod;
                }
                $newPods[] = $merged;
                $pods = $newPods;
                $changed = true;
            }
        }

        return $pods;
    }

    private function repeatPairCount(array $pod, array $historyPairs): int
    {
        $pod = array_values($pod);
        $cnt = 0;
        for ($i=0; $i<count($pod); $i++) {
            for ($j=$i+1; $j<count($pod); $j++) {
                $key = $this->pairKey($pod[$i], $pod[$j]);
                if (($historyPairs[$key] ?? 0) > 0) $cnt++;
            }
        }
        return $cnt;
    }

    private function pairKey(string $a, string $b): string
    {
        return ($a < $b) ? ($a . '|' . $b) : ($b . '|' . $a);
    }
}
