<?php
declare(strict_types=1);

namespace App\Services;

final class StandingsService
{
    /**
     * Computes metrics and standings for a game structure.
     *
     * Metrics implemented (per your list):
     * - Total Score
     * - Total Wins Points (4=>1, 3=>0.75, 2=>0.5)
     * - Total Loss (score==1)
     * - Win rate, Loss rate
     * - Match-win percentage (same as win rate here)
     * - Game-win percentage (totalScore / (4*matches))
     * - Opponents’ win percentage (OWP)
     * - Opponents’ game-win percentage (OGP)
     */
    public function compute(array $game): array
    {
        $players = (array)($game['players'] ?? []);
        $rounds  = (array)($game['rounds'] ?? []);
        $gameMode = (string)($game['game_mode'] ?? 'MULTI PLAYER');
        $isOneVOne = ($gameMode === 'One V One (BO3-SWISS)');

        $stats = [];
        foreach ($players as $email) {
            $stats[$email] = [
                'email' => $email,
                'matches' => 0,
                'total_score' => 0,
                'total_wins_points' => 0.0,
                'total_loss' => 0,
                'opponents' => [], // list (can repeat) to compute averages
            ];
        }

        $winPoints = function(int $score) use ($isOneVOne): float {
            if ($isOneVOne) {
                return match($score) {
                    2 => 1.0,
                    1 => 0.5,
                    default => 0.0,
                };
            }
            return match($score) {
                4 => 1.0,
                3 => 0.75,
                2 => 0.5,
                default => 0.0
            };
        };

        foreach ($rounds as $round) {
            foreach ((array)($round['pods'] ?? []) as $pod) {
                $pList = (array)($pod['players'] ?? []);
                $scores = (array)($pod['scores'] ?? []);

                foreach ($pList as $p) {
                    if (!isset($stats[$p])) continue;

                    $s = $scores[$p] ?? null;
                    if ($s === null) continue; // not scored yet

                    $s = (int)$s;
                    $stats[$p]['matches'] += 1;
                    $stats[$p]['total_score'] += $s;
                    $stats[$p]['total_wins_points'] += $winPoints($s);
                    if ($isOneVOne) {
                        if ($s === 0) $stats[$p]['total_loss'] += 1;
                    } else {
                        if ($s === 1) $stats[$p]['total_loss'] += 1;
                    }

                    // opponents = other players in the pod
                    foreach ($pList as $opp) {
                        if ($opp === $p) continue;
                        $stats[$p]['opponents'][] = $opp;
                    }
                }
            }
        }

        // Base rates
        foreach ($stats as $email => &$st) {
            $m = max(0, (int)$st['matches']);
            $st['win_rate'] = ($m > 0) ? ($st['total_wins_points'] / $m) : 0.0;
            $st['loss_rate'] = ($m > 0) ? ($st['total_loss'] / $m) : 0.0;
            $st['match_win_pct'] = $st['win_rate'];
            $st['game_win_pct']  = ($m > 0) ? ($st['total_score'] / (($isOneVOne ? 2.0 : 4.0) * $m)) : 0.0;
        }
        unset($st);

        // OWP / OGP (averages of opponents)
        foreach ($stats as $email => &$st) {
            $opps = (array)$st['opponents'];
            if (count($opps) === 0) {
                $st['owp'] = 0.0;
                $st['ogp'] = 0.0;
                continue;
            }
            $sumOWP = 0.0;
            $sumOGP = 0.0;
            $c = 0;
            foreach ($opps as $opp) {
                if (!isset($stats[$opp])) continue;
                $sumOWP += (float)$stats[$opp]['match_win_pct'];
                $sumOGP += (float)$stats[$opp]['game_win_pct'];
                $c++;
            }
            $st['owp'] = ($c > 0) ? ($sumOWP / $c) : 0.0;
            $st['ogp'] = ($c > 0) ? ($sumOGP / $c) : 0.0;
        }
        unset($st);

        // Ranking order (per your priority list)
        $ranked = array_values($stats);
        usort($ranked, function($a, $b) {
            // i. Highest Score
            if ($b['total_score'] !== $a['total_score']) return $b['total_score'] <=> $a['total_score'];
            // ii. Total Wins Points
            if ($b['total_wins_points'] !== $a['total_wins_points']) return ($b['total_wins_points'] <=> $a['total_wins_points']);
            // iii. Win Rates
            if ($b['win_rate'] !== $a['win_rate']) return ($b['win_rate'] <=> $a['win_rate']);
            // iv. Match-win percentage
            if ($b['match_win_pct'] !== $a['match_win_pct']) return ($b['match_win_pct'] <=> $a['match_win_pct']);
            // v. Game-win percentage
            if ($b['game_win_pct'] !== $a['game_win_pct']) return ($b['game_win_pct'] <=> $a['game_win_pct']);
            // vi. Opponents’ win percentage (OWP)
            if ($b['owp'] !== $a['owp']) return ($b['owp'] <=> $a['owp']);
            // then stable by email
            return strcmp((string)$a['email'], (string)$b['email']);
        });

        // Alphabetical listing
        $alpha = array_values($stats);
        usort($alpha, fn($a,$b) => strcmp($a['email'], $b['email']));

        return [
            'by_email' => $stats,
            'ranked' => $ranked,
            'alphabetical' => $alpha,
        ];
    }

    /**
     * Build pair-history: counts how many times each pair has been in the same pod in past rounds.
     * Returns "a|b" => count where a<b.
     */
    public function buildPairHistory(array $game): array
    {
        $pairs = [];
        $rounds = (array)($game['rounds'] ?? []);

        foreach ($rounds as $round) {
            foreach ((array)($round['pods'] ?? []) as $pod) {
                $pList = array_values((array)($pod['players'] ?? []));
                for ($i=0; $i<count($pList); $i++) {
                    for ($j=$i+1; $j<count($pList); $j++) {
                        $a = $pList[$i];
                        $b = $pList[$j];
                        $key = ($a < $b) ? ($a.'|'.$b) : ($b.'|'.$a);
                        $pairs[$key] = (int)($pairs[$key] ?? 0) + 1;
                    }
                }
            }
        }
        return $pairs;
    }
}
