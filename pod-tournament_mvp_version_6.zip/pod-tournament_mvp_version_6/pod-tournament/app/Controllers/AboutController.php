<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;

final class AboutController extends Controller
{
    public function index(): void
    {
        $readmePath = BASE_PATH . '/README.md';
        $dedicationPath = BASE_PATH . '/DEDICATION.txt';
        $licensePath = BASE_PATH . '/LICENSE';

        $readme = is_file($readmePath) ? file_get_contents($readmePath) : '';
        $dedication = is_file($dedicationPath) ? file_get_contents($dedicationPath) : '';
        $license = is_file($licensePath) ? file_get_contents($licensePath) : '';

        $this->render('about/index', [
            'user' => Auth::user(),
            'readme' => is_string($readme) ? $readme : '',
            'dedication' => is_string($dedication) ? $dedication : '',
            'license' => is_string($license) ? $license : '',
        ]);
    }
}
