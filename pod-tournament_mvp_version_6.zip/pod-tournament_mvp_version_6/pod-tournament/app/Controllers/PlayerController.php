<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Csrf;
use App\Models\GameModel;
use App\Models\PlayerModel;
use App\Models\DeckModel;
use App\Models\DeckTypeModel;
use App\Services\StandingsService;

final class PlayerController extends Controller
{
    public function home(): void
    {
        Auth::requireLogin();
        $user = Auth::user();

        $games = (new GameModel())->all();
        $myGames = [];
        foreach ($games as $g) {
            if (!($g['is_active'] ?? true)) {
                continue;
            }
            if (in_array($user['email'], (array)($g['players'] ?? []), true)) {
                $myGames[] = $g;
            }
        }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $this->render('player/home', [
            'user' => $user,
            'myGames' => $myGames,
            'playersMeta' => $playersMeta,
        ]);
    }

    public function standing(): void
    {
        Auth::requireLogin();
        $user = Auth::user();

        $id = (string)($_GET['id'] ?? '');
        $game = (new GameModel())->find($id);
        if (!$game) { flash_set('error','Game not found.'); redirect('player/home'); }

        if (!($game['is_active'] ?? true) && ($user['role'] ?? '') !== 'admin') {
            http_response_code(403);
            exit('Not allowed.');
        }

        if (!in_array($user['email'], (array)($game['players'] ?? []), true) && ($user['role'] ?? '') !== 'admin') {
            http_response_code(403);
            exit('Not allowed.');
        }

        $pm = new PlayerModel();
        $playersMeta = $pm->all();

        $standings = (new StandingsService())->compute($game);

        $this->render('player/standing', [
            'user' => $user,
            'game' => $game,
            'playersMeta' => $playersMeta,
            'standings' => $standings,
        ]);
    }

    public function myStats(): void
    {
        Auth::requireLogin();
        $user = Auth::user();
        $email = (string)($user['email'] ?? '');

        $games = (new GameModel())->all();
        $myGames = [];
        foreach ($games as $g) {
            if (in_array($email, (array)($g['players'] ?? []), true)) {
                $myGames[] = $g;
            }
        }

        $overall = [
            'games' => count($myGames),
            'rounds' => 0,
            'pods' => 0,
            'matches' => 0,
            'total_score' => 0,
            'wins_points' => 0.0,
            'losses' => 0,
            'score_entries' => 0,
            'opp_counts' => [],
        ];
        $perGame = [];

        $winPoints = function(int $score): float {
            return match($score) {
                4 => 1.0,
                3 => 0.75,
                2 => 0.5,
                default => 0.0,
            };
        };

        foreach ($myGames as $g) {
            $rounds = (array)($g['rounds'] ?? []);
            $roundsPlayed = [];
            $podsPlayed = 0;
            $matches = 0;
            $totalScore = 0;
            $winsPoints = 0.0;
            $losses = 0;
            $scoreEntries = 0;
            $oppCounts = [];

            foreach ($rounds as $round) {
                foreach ((array)($round['pods'] ?? []) as $pod) {
                    $players = array_values((array)($pod['players'] ?? []));
                    if (!in_array($email, $players, true)) {
                        continue;
                    }

                    $podsPlayed++;
                    $roundsPlayed[(string)($round['number'] ?? '')] = true;

                    $score = $pod['scores'][$email] ?? null;
                    if ($score !== null) {
                        $score = (int)$score;
                        $matches++;
                        $scoreEntries++;
                        $totalScore += $score;
                        $winsPoints += $winPoints($score);
                        if ($score === 1) {
                            $losses++;
                        }
                    }

                    foreach ($players as $opp) {
                        if ($opp === $email) continue;
                        $oppCounts[$opp] = (int)($oppCounts[$opp] ?? 0) + 1;
                    }
                }
            }

            $mostOpp = '';
            $mostOppCount = 0;
            if (!empty($oppCounts)) {
                arsort($oppCounts);
                $mostOpp = (string)key($oppCounts);
                $mostOppCount = (int)current($oppCounts);
            }

            $roundCount = count($roundsPlayed);
            $perGame[] = [
                'id' => $g['id'] ?? '',
                'name' => $g['name'] ?? 'Game',
                'status' => $g['status'] ?? '',
                'created_at' => $g['created_at'] ?? '',
                'rounds' => $roundCount,
                'pods' => $podsPlayed,
                'matches' => $matches,
                'total_score' => $totalScore,
                'wins_points' => $winsPoints,
                'losses' => $losses,
                'score_entries' => $scoreEntries,
                'most_opp' => $mostOpp,
                'most_opp_count' => $mostOppCount,
            ];

            $overall['rounds'] += $roundCount;
            $overall['pods'] += $podsPlayed;
            $overall['matches'] += $matches;
            $overall['total_score'] += $totalScore;
            $overall['wins_points'] += $winsPoints;
            $overall['losses'] += $losses;
            $overall['score_entries'] += $scoreEntries;
            foreach ($oppCounts as $opp => $cnt) {
                $overall['opp_counts'][$opp] = (int)($overall['opp_counts'][$opp] ?? 0) + (int)$cnt;
            }
        }

        $overallMostOpp = '';
        $overallMostOppCount = 0;
        if (!empty($overall['opp_counts'])) {
            arsort($overall['opp_counts']);
            $overallMostOpp = (string)key($overall['opp_counts']);
            $overallMostOppCount = (int)current($overall['opp_counts']);
        }

        $overall['win_rate'] = $overall['matches'] > 0 ? ($overall['wins_points'] / $overall['matches']) : 0.0;
        $overall['game_win_pct'] = $overall['matches'] > 0 ? ($overall['total_score'] / (4.0 * $overall['matches'])) : 0.0;
        $overall['avg_score_entry'] = $overall['score_entries'] > 0 ? ($overall['total_score'] / $overall['score_entries']) : 0.0;
        $overall['most_opp'] = $overallMostOpp;
        $overall['most_opp_count'] = $overallMostOppCount;

        $playersMeta = (new PlayerModel())->all();

        $this->render('player/mystats', [
            'user' => $user,
            'playersMeta' => $playersMeta,
            'overall' => $overall,
            'perGame' => $perGame,
        ]);
    }

    public function myDeck(): void
    {
        Auth::requireLogin();
        $user = Auth::user();

        $types = (new DeckTypeModel())->all();
        $decks = (new DeckModel())->listByUser((string)($user['email'] ?? ''));

        $this->render('player/mydeck', [
            'user' => $user,
            'csrf' => Csrf::token(),
            'types' => $types,
            'decks' => $decks,
            'deckCount' => count($decks),
        ]);
    }

    public function addDeck(): void
    {
        Auth::requireLogin();
        Csrf::check();
        $user = Auth::user();
        $email = (string)($user['email'] ?? '');

        $type = trim((string)($_POST['deck_type'] ?? ''));
        $name = trim((string)($_POST['deck_name'] ?? ''));
        $link = trim((string)($_POST['deck_link'] ?? ''));
        $commander = trim((string)($_POST['commander_name'] ?? ''));

        $existing = (new DeckModel())->listByUser($email);
        if (count($existing) >= 10) {
            flash_set('error', 'Deck limit reached (10).');
            redirect('player/myDeck');
        }

        if ($type === '' || $name === '') {
            flash_set('error', 'Deck type and deck name are required.');
            redirect('player/myDeck');
        }

        $types = (new DeckTypeModel())->all();
        $lower = array_map('strtolower', $types);
        if (!in_array(strtolower($type), $lower, true)) {
            flash_set('error', 'Invalid deck type selected.');
            redirect('player/myDeck');
        }

        if (stripos($type, 'commander') === false) {
            $commander = '';
        }

        (new DeckModel())->add([
            'user_email' => strtolower($email),
            'deck_type' => $type,
            'deck_name' => $name,
            'deck_link' => $link,
            'commander_name' => $commander,
            'created_at' => date('c'),
        ]);

        flash_set('success', 'Deck saved.');
        redirect('player/myDeck');
    }
}
