<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\GameModel;
use App\Models\PlayerModel;

final class DisplayController extends Controller
{
    public function round(): void
    {
        $gameId = (string)($_GET['id'] ?? '');
        $roundNum = (int)($_GET['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) {
            http_response_code(404);
            echo 'Game not found.';
            return;
        }

        $rounds = (array)($game['rounds'] ?? []);
        $round = $rounds[$roundNum - 1] ?? null;
        if (!$round) {
            http_response_code(404);
            echo 'Round not found.';
            return;
        }

        $playersMeta = (new PlayerModel())->all();
        $viewer = (string)($_GET['viewer'] ?? '');
        $isPlayerView = ($viewer === 'player');

        $data = [
            'game' => $game,
            'round' => $round,
            'roundNum' => $roundNum,
            'playersMeta' => $playersMeta,
            'serverNow' => time(),
            'isPlayerView' => $isPlayerView,
        ];
        extract($data, EXTR_SKIP);
        require VIEW_PATH . '/display/round.php';
    }

    public function roundData(): void
    {
        $gameId = (string)($_GET['id'] ?? '');
        $roundNum = (int)($_GET['round'] ?? 1);

        $gm = new GameModel();
        $game = $gm->find($gameId);
        if (!$game) {
            http_response_code(404);
            echo json_encode(['error' => 'Game not found.']);
            return;
        }

        $rounds = (array)($game['rounds'] ?? []);
        $round = $rounds[$roundNum - 1] ?? null;
        if (!$round) {
            http_response_code(404);
            echo json_encode(['error' => 'Round not found.']);
            return;
        }

        $playersMeta = (new PlayerModel())->all();

        $pods = (array)($round['pods'] ?? []);
        $podsCount = count($pods);
        $podsSaved = 0;
        $podsLocked = 0;
        $scoreSystem = (string)($game['score_system'] ?? 'Point System (Limited)');
        $gameMode = (string)($game['game_mode'] ?? 'MULTI PLAYER');
        $isOneVOne = ($gameMode === 'One V One (BO3-SWISS)');
        $isUnlimited = ($scoreSystem === 'Point System (Unlimited)');
        $podsStatus = [];
        foreach ($pods as $idx => $pod) {
            $saved = !empty($pod['saved']);
            $locked = !empty($pod['locked']);
            $isBye = !empty($pod['bye']) || count((array)($pod['players'] ?? [])) === 1;
            $scores = (array)($pod['scores'] ?? []);
            $players = (array)($pod['players'] ?? []);
            $topPlayer = null;
            if ($locked && !empty($players)) {
                $bestScore = null;
                $minScore = null;
                foreach ($players as $email) {
                    $val = $scores[$email] ?? null;
                    if ($val === null) continue;
                    $val = (int)$val;
                    if ($bestScore === null || $val > $bestScore) {
                        $bestScore = $val;
                        $topPlayer = $email;
                    }
                    if ($minScore === null || $val < $minScore) {
                        $minScore = $val;
                    }
                }
                if ($bestScore !== null && $minScore !== null) {
                    if ($isOneVOne) {
                        $tie = ($bestScore === $minScore);
                    } elseif ($isUnlimited) {
                        $tie = ($bestScore === $minScore);
                    } else {
                        $tie = ($bestScore <= 2);
                    }
                    if ($tie) {
                        $topPlayer = null;
                    }
                }
            }
            if ($saved) $podsSaved++;
            if ($locked) $podsLocked++;
            $podsStatus[] = [
                'index' => $idx,
                'saved' => $saved,
                'locked' => $locked,
                'bye' => $isBye,
                'top_player' => $topPlayer,
            ];
        }

        $results = [];
        if (!empty($round['completed'])) {
            $gameForStandings = $game;
            $gameForStandings['rounds'] = array_slice($rounds, 0, $roundNum);
            $standings = (new \App\Services\StandingsService())->compute($gameForStandings);
            $rows = $standings['ranked'] ?? [];
            foreach ($rows as $i => $r) {
                $meta = $playersMeta[$r['email']] ?? ['name' => $r['email']];
                $results[] = [
                    'rank' => $i + 1,
                    'name' => (string)($meta['name'] ?? $r['email']),
                    'score' => (int)$r['total_score'],
                ];
            }
        }

        header('Content-Type: application/json');
        echo json_encode([
            'serverNow' => time(),
            'game' => [
                'status' => (string)($game['status'] ?? ''),
                'sponsor_banner' => (string)($game['sponsor_banner'] ?? ''),
                'display_background' => (string)($game['display_background'] ?? ''),
            ],
            'round' => [
                'number' => (int)($round['number'] ?? $roundNum),
                'pairing_mode' => (string)($round['pairing_mode'] ?? ''),
                'display_background' => (string)($round['display_background'] ?? ''),
                'time_limit_minutes' => (int)($round['time_limit_minutes'] ?? 0),
                'timer_locked' => !empty($round['timer_locked']),
                'timer_start' => $round['timer_start'] ?? null,
                'timer_end' => $round['timer_end'] ?? null,
                'timer_running' => !empty($round['timer_running']),
                'completed' => !empty($round['completed']),
                'display_show_pods' => !empty($round['display_show_pods']),
                'display_show_results' => !empty($round['display_show_results']),
                'pods_total' => $podsCount,
                'pods_saved' => $podsSaved,
                'pods_locked' => $podsLocked,
                'pods_status' => $podsStatus,
                'results' => $results,
            ],
        ]);
    }
}
